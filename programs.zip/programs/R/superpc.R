# it fails when threshold=val_par2=0.9: "Error in rowMeans(x) : 'x' must be an array of at least two dimensions"
require(superpc,quietly=T)
fn=names(pr[,-i_output]);data=list(x=t(pr[,-i_output]),y=pr[,i_output],featurenames=fn)
superpc.model=superpc.train(data,type='regression')
data.test=list(x=t(pv[,-i_output]),y=pv[,i_output],featurenames=fn)
sr=superpc.predict(superpc.model,data,data.test,threshold=val_par2,n.components=val_par1)$v.pred.1df
rm(fn,data,superpc.model,data.test)