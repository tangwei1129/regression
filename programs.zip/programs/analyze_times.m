clear all
clc
addpath('matlab')

ngroup=4;

model_list={'elm_kernel','svr','elm','nnls','svmRadial','rpart','lm','gbm','bdk','avNNet','ctree2','widekernelpls','enet','plsRglm','extraTrees','glmboost','pcaNNet','icr','rqnc','relaxo','foba','penalized','spls','ppr','superpc','dnn','gaussprPoly','gaussprLinear','rqlasso','pcr','kknn','RRF','krlsRadial','kernelpls','gam','lars','glmnet','simpls','earth','M5','mlpWeightDecay','ridge','gaussprRadial','lasso','evtree','rf','rlm','BstLm','bayesglm','rvmRadial','rbf','cforest','cubist','glmStepAIC','blackboost','qrf','grnn','SBC','partDSA','treebag','bag','mlpWeightDecayML','brnn','bagEarth','bartMachine','gamboost','bstTree','randomGLM','spikeslab','dlkeras','Boruta','xgbLinear','enpls.fs','nodeHarvest','bstSm','xgbTree','qrnn'};
model_list2={'kelm','svr','elm','nnls','svmRad','rpart','lm','gbm','bdk','avNNet','ctree2','wkpls','enet','plsRglm','extraTrees','glmboost','pcaNNet','icr','rqnc','relaxo','foba','penalized','spls','ppr','superpc','dnn','gprPol','gprLin','rqlasso','pcr','kknn','RRF','krlsRad','kpls','gam','lars','glmnet','simpls','earth','M5','mlpWD','ridge','gprRad','lasso','evtree','rf','rlm','BstLm','bayesglm','rvmRad','rbf','cforest','cubist','glmSAIC','blackboost','qrf','grnn','SBC','partDSA','treebag','bag','mlpWDml','brnn','bagEarth','bMachine','gamboost','bstTree','rndGLM','spikeslab','dlkeras','Boruta','xgbLinear','enpls.fs','nodeHarvest','bstSm','xgbTree','qrnn'};
nmodel=numel(model_list);

implem_list=cell(1,nmodel);
for i=1:nmodel
    implem_list{i}=get_implem(model_list{i});
end

global_dataset_list={};ndata=0;time=[];error_flag=[];
n_time_errors=zeros(1,nmodel);ndata=0;
for group=1:ngroup
    if group==1    % 20 datasets in group 1
        dataset_list={'slump','slump_flow','gps_trajectory','csm1415','stock_abs',...
            'stock_annual','stock_excess','stock_rel','stock_systematic','stock_total',...
            'student_mat','forestfires','student_por','park_speech','geo_lat','geo_long',...
            'geo_music_lat','geo_music_long','airfoil','com_crime_unnorm'};
    elseif group==2   % 23 datasets in group 2
        dataset_list={'daily_demand','slump_comp','servo','automobile','com_hd',...
            'yacht_hydro','auto_mpg','housing','facebook_metrics','stock_exchange',...
            'bike_day','energy_cool','energy_heat','compress_stren','air_quality_CO',...
            'air_quality_NMHC','air_quality_NO2','air_quality_NOx','air_quality_O3',...
            'com_crime','gas_dynamic_CO','gas_dynamic_methane','SML2010'};
    elseif group==3   % 33 datasets in group 3
        dataset_list={'park_motor_UPDRS','park_total_UPDRS','appliances_energy',...
            'pm25_beijing_dongsihuan','pm25_shenyang_us_post','pm25_guangzhou_5th_middle_school',...
            'pm25_shanghai_jingan','pm25_shenyang_taiyuanji','pm25_chengdu_caotangsi',...
            'pm25_shanghai_xuhui','pm25_chengdu_shahepu','pm25_shenyang_xiaoheyan',...
            'pm25_beijing_nongzhanguan','pm25_beijing_dongsi','pm25_chengdu_us_post',...
            'pm25_shanghai_us_post','pm25_guangzhou_city_station','pm25_guangzhou_us_post',...
            'online_news','facebook_comment','beijing_pm25','physico_protein',...
            'pm25_beijing_us_post','KEGG_relation','blog_feedback','cuff_less',...
            'video_transcode','dynamic_features','3Droad','year_prediction',...
            'buzz_twitter','greenhouse_net','household_consume'};
    elseif group==4  % 7 datasets in group 4
        dataset_list={'combined_cycle','cond_turbine','UJ_lat','UJ_long',...
            'bike_hour','CT_slices','KEGG_reaction'};
    end
    ndata_group=numel(dataset_list);
    for i=1:ndata_group
        ndata=ndata+1;global_dataset_list{ndata}=dataset_list{i};
    end
    nf=sprintf('../results/REPORTS/dataset_group%i/table_time_group%i.dat',group,group);
    [time_group error_flag_group]=read_result_table(nf,model_list,dataset_list);
    time=[time time_group];error_flag=[error_flag error_flag_group];
    for i=1:nmodel
        model=model_list{i};
        cmd=sprintf('grep '' %s '' ../results/REPORTS/dataset_group%i/errors_group%i.txt | grep walltime | wc -l',...
            model,group,group);
        [~,output]=system(cmd);nerr=str2double(output);
        n_time_errors(i)=n_time_errors(i)+nerr;
    end
end
maxtime=48*3600;  %maxtime=maximum allowed time (48 hours, 172800 sec.)
time(isnan(time))=maxtime;

time_rank=friedman_rank(time,'ascend');
nf='../results/REPORTS/global/table_times.tex';f=open_file(nf,'w');
fprintf(f,'\\begin{tabular}{|c|c|c|c||c|c|c|c||c|c|c|c|}\n');fprintf(f,'\\hline\n');
fprintf(f,'%5s & %10s & %5s & %5s & %5s & %10s & %5s & %5s & %5s & %10s & %5s & %5s \\\\ \\hline \\hline \n','Pos',...
    'Model','Rank','\%TE','Pos.','Model','Rank','\%TE','Pos.','Model','Rank','\%TE');
nrows=ceil(nmodel/3);j1=1;j2=j1+nrows;j3=j2+nrows;
[~,ind]=sort(time_rank);
for i=1:nrows
    k1=ind(j1);k2=ind(j2);s1='';s2='';s3='';
    if n_time_errors(k1)>0
        s1=sprintf('%5.1f',100*n_time_errors(k1)/ndata);
    end
    if n_time_errors(k2)>0
        s2=sprintf('%5.1f',100*n_time_errors(k2)/ndata);
    end
    if j3<=nmodel
        k3=ind(j3);
        if n_time_errors(k3)>0
            s3=sprintf('%5.1f',100*n_time_errors(k3)/ndata);
        end
        fprintf(f,'%5i & %10s & %5.1f & %5s & %5i & %10s & %5.1f & %5s & %5i & %10s & %5.1f & %5s \\\\ \\hline \n',...
            j1,model_list2{k1},time_rank(k1),s1,j2,model_list2{k2},time_rank(k2),s2,j3,model_list2{k3},time_rank(k3),s3);
    else
        fprintf(f,'%5i & %10s & %5.1f & %5s & %5i & %10s & %5.1f & %5s & %5s & %10s & %5s & %5s \\\\ \\hline \n',...
            j1,model_list2{k1},time_rank(k1),s1,j2,model_list2{k2},time_rank(k2),s2,'','','','');
    end
    j1=j1+1;j2=j2+1;j3=j3+1;
end
fprintf(f,'\\end{tabular}\n');fclose(f);

% times of the best regressors against the product np*ni
npni=zeros(1,ndata);
for i=1:ndata
    data=global_dataset_list{i};nf=sprintf('../data/%s/%s.txt',data,data);
    f=open_file(nf,'r');
    fscanf(f,'%s',1);np=fscanf(f,'%i',1);
    fscanf(f,'%s',1);ni=fscanf(f,'%i',1);
    npni(i)=np*ni;fclose(f);
end
[~,i]=sort(npni);clf;
i_cubist=find(strcmp(model_list,'cubist'));loglog(npni(i),time(i_cubist,i),'b.-');hold on;
i_M5=find(strcmp(model_list,'M5'));loglog(npni(i),time(i_M5,i),'r.-')
i_lars=find(strcmp(model_list,'lars'));loglog(npni(i),time(i_lars,i),'g.-')
i_bstSm=find(strcmp(model_list,'bstSm'));loglog(npni(i),time(i_bstSm,i),'c.-')
legend({'cubist','M5','lars','bstSm'},'location','southeast','fontsize',18)
xlabel('#patterns * #inputs','fontsize',18);ylabel('Time (s.)','fontsize',18);
axis([5e2 7e7 7e-3 4e5])
print('-depsc','../results/REPORTS/global/times_best_regressors.eps')
