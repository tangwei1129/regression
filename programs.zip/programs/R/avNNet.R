require(caret,quietly=TRUE)
avNNet.model=avNNet(pr[,-i_output],pr[,i_output],linout=TRUE,repeats=5,size=val_par1,decay=val_par2,trace=FALSE,MaxNWts=1000*ceiling(val_par1*(ni + 1)/1000))
sr=matrix(predict(avNNet.model,pv[,-i_output]))
rm(avNNet.model) 