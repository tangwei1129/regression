#hai que axustar en evtree.control os parámetros minbucket, minsplit, ntree, etc. para datasets pequenos: os erros que da este regresor son por datos pequenos
#minsplit must be at lease twice minbucket
require(evtree,quietly=T)
evtree.model=evtree(output ~ ., data=pr,control=evtree.control(alpha=val_par1,minbucket=2,minsplit=4,ntrees=10))
sr=predict(evtree.model,pv[,-i_output])
if(sd(sr)==0) stop('constant predicted output')
rm(evtree.model)
