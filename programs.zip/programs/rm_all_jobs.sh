#!/bin/bash
file=jobs.txt

qstat | grep -v " C "|cut -d. -f1 > $file
while read job_id
do
	echo 'removing' $job_id
	qdel $job_id
done < $file

rm -f $file