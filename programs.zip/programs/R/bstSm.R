require(bst,quietly=T)
bstSm.model=bst(pr[,-i_output],pr[,i_output],ctrl=bst_control(mstop=val_par1),learner='sm')
sr=predict(bstSm.model,pv[,-i_output])
rm(bstSm.model)