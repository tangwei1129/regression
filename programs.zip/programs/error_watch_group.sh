#!/bin/bash
clear

group=1
resubmit_memory_jobs=0

#list of all the models (78) sorted by increasing times on the smallest dataset (daily_demand)
model_list=(elm_kernel svr elm nnls svmRadial rpart lm gbm bdk glm avNNet ctree2 widekernelpls enet plsRglm extraTrees glmboost pcaNNet icr rqnc relaxo foba penalized spls ppr superpc dnn gaussprPoly gaussprLinear rqlasso pcr kknn RRF krlsRadial kernelpls gam lars glmnet simpls earth M5 mlpWeightDecay ridge gaussprRadial lasso evtree rf rlm BstLm bayesglm rvmRadial rbf cforest cubist glmStepAIC blackboost qrf grnn SBC partDSA treebag bag mlpWeightDecayML brnn bagEarth bartMachine gamboost bstTree randomGLM spikeslab dlkeras Boruta xgbLinear enpls.fs nodeHarvest bstSm xgbTree qrnn)

# model_list=()

n_model=${#model_list[@]}

# datasets sorted by increasing number of patterns
if [ $group == 1 ]; then  # group 1
	dataset_list=(slump slump_flow gps_trajectory csm1415 stock_abs stock_annual stock_excess stock_rel stock_systematic stock_total student_mat forestfires student_por park_speech geo_lat geo_long geo_music_lat geo_music_long airfoil com_crime_unnorm)
	echo 'group 1'
fi
if [ $group == 2 ]; then  # group 2
	dataset_list=(daily_demand slump_comp servo automobile com_hd yacht_hydro auto_mpg housing facebook_metrics stock_exchange bike_day energy_cool energy_heat compress_stren air_quality_CO air_quality_NMHC air_quality_NO2 air_quality_NOx air_quality_O3 com_crime gas_dynamic_CO gas_dynamic_methane SML2010)
	echo 'group 2'
fi
if [ $group == 3 ]; then  # group 3
	dataset_list=(park_motor_UPDRS park_total_UPDRS appliances_energy pm25_beijing_dongsihuan pm25_shenyang_us_post pm25_guangzhou_5th_middle_school pm25_shanghai_jingan pm25_shenyang_taiyuanji pm25_chengdu_caotangsi pm25_shanghai_xuhui pm25_chengdu_shahepu pm25_shenyang_xiaoheyan pm25_beijing_nongzhanguan pm25_beijing_dongsi pm25_chengdu_us_post pm25_shanghai_us_post pm25_guangzhou_city_station pm25_guangzhou_us_post online_news facebook_comment beijing_pm25 physico_protein pm25_beijing_us_post KEGG_relation blog_feedback cuff_less video_transcode dynamic_features 3Droad year_prediction buzz_twitter greenhouse_net household_consume)
	echo 'group 3'
fi
if [ $group == 4 ]; then  # group 4
	dataset_list=(combined_cycle cond_turbine UJ_lat UJ_long bike_hour CT_slices KEGG_reaction)
	echo 'group 4'
fi


# dataset_list=()

n_dataset=${#dataset_list[@]}


file2=../results/REPORTS/dataset_group${group}/errors_group${group}.txt
echo 'ERRORS BY MODEL' > $file2

let n_err_total=0
let i_model=0

for model in ${model_list[*]}; do
	let i_model=i_model+1
	if [ $model == 'svr' ]; then
		implem='C'; args_model='2 C 20 16384 8192 4096 2048 1024 512 256 128 64 32 16 8 4 2 1 0.5 0.25 0.125 0.0625 0.0312 gamma 25 256 128 64 32 16 8 4 2 1 0.5 0.25 0.125 0.0625 0.03125 0.01562 0.00781 0.00391 0.00195  0.00098 0.00049 0.00024 0.00012 0.00006 0.00003 1.5e-5'
	elif [ $model == 'grnn' ]; then
		implem='matlab'; args_model='1 spread 14 0.001 0.005 0.01 0.05 0.1 0.3 0.5 0.7 0.9 1 1.3 1.5 1.7 2'
	elif [ $model == 'elm_kernel' ]; then
		implem='matlab'; args_model='2 C 20 16384 8192 4096 2048 1024 512 256 128 64 32 16 8 4 2 1 0.5 0.25 0.125 0.0625 0.0312 gamma 25 256 128 64 32 16 8 4 2 1 0.5 0.25 0.125 0.0625 0.03125 0.01562 0.00781 0.00391 0.00195  0.00098 0.00049 0.00024 0.00012 0.00006 0.00003 1.5e-5'
	elif [ $model == 'dlkeras' ]; then
		implem='python'; args_model='3 nh1 2 50 75 nh2 2 50 75 nh3 2 50 75'
	else
		implem='R'
	fi		
	echo -n $i_model '/' $n_model $model': '
	echo $model':' >> $file2
	
	let n_err=0
	let n_ok=0
	let n_run_again=0

	for dataset in ${dataset_list[*]}; do
 		file=../results/${dataset}/${model}_${implem}/results_${model}_${implem}_${dataset}.dat
 		if [ ! -e $file ]; then  # there is no file results_model_implem_dataset.dat
			echo -n '   ' $model $dataset '' >> $file2
			process=`qstat -f | grep ${model}_${dataset}`
			if [ -n "${process}" ]; then  # checks if process is running
				echo 'running' >> $file2
				let n_ok=n_ok+1
				continue
			fi
			let n_err=n_err+1
			file3=outputs/${dataset}/${model}_${implem}_${dataset}.err
			line1=`grep walltime $file3 2> /dev/null`; 
			if [ -n "${line1}" ]; then
				echo 'walltime' >> $file2
				continue
			fi
			line2=`grep vmem $file3 2> /dev/null`
			line3=`grep Abortado $file3 2> /dev/null`
			file4=../results/${dataset}/${model}_${implem}/output_${model}_${implem}_${dataset}.dat
			file5=../results/${dataset}/${model}_${implem}/err_${model}_${dataset}.dat
			line4=`grep alloc $file4 2> /dev/null`
			if [ "${implem}" == 'matlab' ]; then
				line5=`grep "Out of memory" $file4 2> /dev/null`
			fi
			if [ "${implem}" == 'R' ]; then
				line5=`grep "no se puede ubicar un vector de tamaño" $file4 2> /dev/null`
				line6=`grep "Error in cor" $file4 2> /dev/null`
				line7=`grep "no se puede ubicar un vector de tamaño" $file5 2> /dev/null`
				line8=`grep "pila sink esta llena" $file5 2> /dev/null`
			fi
			if [[ -n "${line2}" || -n "${line3}" || -n "${line4}" || -n "${line5}" || -n "${line6}" || -n "${line7}" || -n "${line8}" ]]; then
				echo -n 'memory ' >> $file2
				file6=scripts/${dataset}/${model}_${dataset}.sh
				ppn=`grep "ppn" $file6 | cut -d= -f3 | cut -d, -f1`
				if [ "${ppn}" -ne '64' ]; then
					ppn2=`expr 2 \* ${ppn}`
					if [ "${resubmit_memory_jobs}" == '1' ]; then
						fich=scripts/${dataset}/${model}_${dataset}										
						sed s/DATASET/${dataset}/g job_regression.sh > ${fich}_1.sh
						sed s/MODEL/${model}/g ${fich}_1.sh > ${fich}_2.sh
						sed s/IMPLEM/${implem}/g ${fich}_2.sh > ${fich}_3.sh
						sed s/ARGS/"'${args_model}'"/g ${fich}_3.sh > ${fich}_4.sh
						sed s/PPN/${ppn2}/g ${fich}_4.sh > $file5
						rm -f ${fich}_*.sh
						qsub $file5 > /dev/null
						echo ' resubmitted' $model $dataset 'with ppn=' $ppn2
						echo 'resubmitted with ppn=' $ppn2 >> $file2
						continue
					fi
					echo 'to be resubmitted with ppn=' $ppn2 >> $file2
					let n_run_again=n_run_again+1
					continue
				fi
				echo '64GB' >> $file2
				continue
			fi
			echo 'error in all test partitions' >> $file2
			continue
 		fi #end of if there is no file results_model_implem_dataset.dat
        mse=`grep avg_rmse ${file} | cut -d' ' -f2`
        if [ -n "${mse}" ]; then
			let n_ok=n_ok+1
			continue
		fi
		echo -n '   ' $model $dataset '' >> $file2
		process=`qstat -f | grep ${model}_${dataset}`
		if [ -n "${process}" ]; then  # checks if process is running
			echo 'running' >> $file2
			let n_ok=n_ok+1
			continue
		fi
		let n_err=n_err+1
		file3=outputs/${dataset}/${model}_${implem}_${dataset}.err
		line1=`grep walltime $file3 2> /dev/null`; 
		if [ -n "${line1}" ]; then
			echo 'walltime' >> $file2
			continue
		fi
		line2=`grep vmem $file3 2> /dev/null`
		line3=`grep Abortado $file3 2> /dev/null`
		file4=../results/${dataset}/${model}_${implem}/output_${model}_${implem}_${dataset}.dat
		file5=../results/${dataset}/${model}_${implem}/err_${model}_${dataset}.dat
		line4=`grep alloc $file4 2> /dev/null`
		if [ "${implem}" == 'matlab' ]; then
			line5=`grep "Out of memory" $file4 2> /dev/null`
		fi
		if [ "${implem}" == 'R' ]; then
			line5=`grep "no se puede ubicar un vector de tamaño" $file4 2> /dev/null`
			line6=`grep "Error in cor" $file4 2> /dev/null`
			line7=`grep OutOfMemoryError ../results/${dataset}/${model}_${implem}/err_${model}_${dataset}.dat 2> /dev/null`
			line8=`grep "no se puede ubicar un vector de tamaño" $file5 2> /dev/null`
			line9=`grep "pila sink esta llena" $file5 2> /dev/null`
		fi

		if [[ -n "${line2}" || -n "${line3}" || -n "${line4}" || -n "${line5}" || -n "${line6}" || -n "${line7}" || -n "${line8}" || -n "${line9}" ]]; then
			echo -n 'memory ' >> $file2
			file5=scripts/${dataset}/${model}_${dataset}.sh
			if [ ! -e $file5 ]; then
				echo 'script does not exist' >> $file2
				let n_run_again=n_run_again+1
				continue
			fi
			ppn=`grep "ppn" $file5 | cut -d= -f3 | cut -d, -f1`
			if [ "${ppn}" -ne '64' ]; then
				ppn2=`expr 2 \* ${ppn}`
				if [ "${resubmit_memory_jobs}" == '1' ]; then
					fich=scripts/${dataset}/${model}_${dataset}										
					sed s/DATASET/${dataset}/g job_regression.sh > ${fich}_1.sh
					sed s/MODEL/${model}/g ${fich}_1.sh > ${fich}_2.sh
					sed s/IMPLEM/${implem}/g ${fich}_2.sh > ${fich}_3.sh
					sed s/ARGS/"'${args_model}'"/g ${fich}_3.sh > ${fich}_4.sh
					sed s/PPN/${ppn2}/g ${fich}_4.sh > $file5
					rm -f ${fich}_*.sh
					qsub $file5 > /dev/null
					echo ' resubmitted' $model $dataset 'with ppn=' $ppn2
					echo 'resubmitted with ppn=' $ppn2 >> $file2
					continue
				fi
				echo 'to be resubmitted with ppn=' $ppn2 >> $file2
				let n_run_again=n_run_again+1
				continue
			fi
			echo '64GB' >> $file2
			continue
		fi
		line7=`grep "error in some test partitions" $file`
		if [ -n "${line7}" ]; then
			echo 'error in some test partitions' >> $file2
			continue
		fi
		line8=`grep "error in all test partitions" $file`
		if [ -n "${line8}" ]; then
			echo 'error in all test partitions' >> $file2
			continue
		fi
		line9=`grep "Regressor failed for all the hyper-parameter values" $file4 2> /dev/null`
		if [ -n "${line9}" ]; then
			echo 'regressor failed for all the hyper-parameter values' >> $file2
			continue
		fi
		echo 'unknown' >> $file2
		let n_run_again=n_run_again+1
	done
	
	let n_err_total=n_err_total+n_err
	let n_run_again_total=n_run_again_total+n_run_again
 	echo $n_err 'errors' $n_ok 'OK /'${n_dataset} 'total: run again' ${n_run_again} 'processes, total=' $n_run_again_total
	echo $model ':' $n_err 'errors' $n_ok 'OK /'${n_dataset} 'total: run again ' ${n_run_again} 'processes' >> $file2
	echo '----------------------------------' >> $file2		
done

echo 'total errors=' $n_err_total 'n_run_again_total=' $n_run_again_total
echo 'total errors=' $n_err_total 'n_run_again_total=' $n_run_again_total >> $file2	
