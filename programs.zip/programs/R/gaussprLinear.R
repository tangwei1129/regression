require(kernlab,quietly=TRUE)
sink('/dev/null')
gaussprLinear.model=gausspr(output ~ . ,data=pr,kernel='vanilladot')
sr=predict(gaussprLinear.model,pv)
while(sink.number()>0) { sink(NULL) }
if(any(is.na(sr))) stop('error: gaussprLinear.predict gives NA!')
rm(gaussprLinear.model)
