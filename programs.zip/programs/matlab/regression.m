function regression(varargin)
try
    global dataset
    warning off all
    initialize
    
    % sintonización de parámetros
    if n_par > 0
        switch n_par
        case 1
            best_rmse=inf;best_par1=val1(1);par2_val=0;best_par2=0;
            fprintf(f, '%20s\t%20s\t%20s\n', par1_name,'mse','best_rmse');
            for i = 1:n_val1
                par1_val = val1(i);
                for k = 1:ntrials
                    u = xr(k,:); pe = x(:,u); de = d(u); u = xv(k,:); pv = x(:,u); dv = d(u);
                    sr = feval(model, pe, de, pv, dv, par1_val, 0);
                    rmse(k)=sqrt(sum((dv-sr).^2)/npv);iexp = iexp + 1;
                    if 1==interactive
                      fprintf(2,'%5.1f%%\r', 100*iexp/nexp);
                    end
                end
                avg_rmse=mean(rmse);
                if avg_rmse < best_rmse
                    best_rmse=avg_rmse;best_par1=par1_val;
                end
                fprintf(f,'%20g\t%20.5f\t%20g\n',par1_val,avg_rmse,best_rmse);
            end
            fprintf(f,'%s_mellor= %g best_rmse=%g\n',par1_name,best_par1,best_rmse);
        case 2
            best_rmse=inf;best_par1 = val1(1); best_par2 = val2(1);
            fprintf(f, '%20s\t%20s\t%20s\t%20s\n', par1_name, par2_name,'mse','best_rmse');
            for i = 1:n_val1
                par1_val = val1(i);
                for j = 1:n_val2
                    par2_val = val2(j);
                    for k = 1:ntrials
                        u = xr(k,:); pe = x(:,u); de=d(u); u = xv(k,:); pv = x(:,u); dv = d(u);
                        sr = feval(model, pe, de, pv, dv, par1_val, par2_val, 0);
                        rmse(k)=sqrt(sum((dv-sr).^2)/npv);iexp = iexp + 1;
                        if 1==interactive
                          fprintf(2,'%5.1f%%\r', 100*iexp/nexp);
                        end
                    end
                    avg_rmse=mean(rmse);
                    if avg_rmse < best_rmse
                        best_rmse=avg_rmse;best_par1=par1_val;best_par2=par2_val;
                    end
                    fprintf(f,'%20g\t%20g\t%20g\t%20g\n',par1_val,par2_val,avg_rmse,best_rmse);
                end
            end
            fprintf(f,'%s_mellor= %g %s_mellor= %g best_rmse=%g\n',par1_name,best_par1,par2_name,...
                best_par2,best_rmse);
        case 3
            best_rmse=inf;best_par1=val1(1);best_par2 = val2(1); best_par3 = val3(1);
            fprintf(f, '%20s\t%20s\t%20s\t20s\t20s\n',par1_name,par2_name,par3_name,'mse','best_rmse');
            for i = 1:n_val1
                par1_val = val1(i);
                for j = 1:n_val2
                    par2_val = val2(j);
                    for l = 1:n_val3
                        par3_val = val3(l);
                        for k = 1:ntrials
                            u = xr(k,:); pe = x(:,u); de = d(u); u = xv(k,:); pv = x(:,u); dv = d(u);
                            sr = feval(model, pe, de, pv, dv,par1_val,par2_val,par3_val);
                            rmse(k)=sqrt(sum((dv-sr).^2)/npv);iexp=iexp+1;
                            if 1==interactive
                                fprintf(2,'%5.1f%%\r', 100*iexp/nexp);
                            end
                        end
                        avg_rmse=mean(rmse);
                        if avg_rmse < best_rmse
                            best_rmse=avg_rmse;best_par1=par1_val;best_par2=par2_val;best_par3=par3_val;
                        end
                        fprintf(f,'%20g\t%20g\t%20g\t%20g\t20g\n', par1_val,par2_val,par3_val,avg_rmse,best_rmse);
                    end
                end
            end
            fprintf(f,'%s_mellor= %g %s_mellor= %g %s_mellor= %g best_rmse= %g\n',par1_name,best_par1, ...
              par2_name,best_par2,par3_name,best_par3,best_rmse);
        end
    end
    
    % teste
    tic
    nf=sprintf('%s/trials_%s_%s.dat',resultsdir,model,dataset);
    ft=open_file(nf,'w');   % file trials_model_dataset.csv
    nf=sprintf('%s/plot_%s_%s.dat',resultsdir,model,dataset);
    fg=open_file(nf,'w');   % file plot_model_dataset.csv
    r2=zeros(1,ntrials);mae=zeros(1,ntrials);
    for i=1:ntrials
        t=xr(i,:);pe=x(:,t);de=d(t); t=xt(i,:);pt=x(:,t);dt=d(t);
        sr = feval(model, pe, de, pt, dt, best_par1, best_par2, best_par3);
        for j=1:numel(sr)
            fprintf(fg,'%f %f\n',dt(j),sr(j));
        end
        [r2(i) rmse(i) mae(i)]=evaluate_test(dt,sr);
        fprintf(ft,'%10i %10g %10g %10g\n',i,r2(i),rmse(i),mae(i));
        iexp=iexp+1;
        if 1==interactive
            fprintf(2,'%5.1f%%\r', 100*iexp/nexp);
        end
    end
    fclose(ft);fclose(fg);dt=toc/ntrials;
    fprintf(f,'avg_r2= %g std= %g\n',mean(r2),std(r2));
    fprintf(f,'avg_rmse= %g std= %g\n',mean(rmse),std(rmse));
    fprintf(f,'avg_mae= %g std= %g\n',mean(mae),std(mae));
    fprintf(f,'time= %g s.\n',dt);
    fclose(f);
    % file model_dataset.csv
    nf=sprintf('%s/%s_%s.csv',resultsdir,model,dataset);
    f=open_file(nf,'w');fprintf(f,'%g %g %g %g\n',mean(r2),mean(rmse),mean(mae),dt); fclose(f);
catch excepcion
%     fprintf('matlab: excepción: problema= %s model= %s\n', dataset, model)
    fprintf('id= %s: %s\n', excepcion.identifier, excepcion.message) 
	fprintf(getReport(excepcion,'extended'));
end
quit