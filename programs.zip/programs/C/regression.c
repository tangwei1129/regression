#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <error.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <sys/time.h>


// #define DEBUG_DATA_READING
// #define DEBUG_PARTITION_READING
// #define DEBUG_ARGUMENT_READING
#define N_VAL_PAR_MAX 30
#define N_PAR_MAX 2
#define TRAIN_PERC 70.
#define VALID_PERC 20.


extern void  ini_model(int);
extern void  train(float **, float *, int *, int, float, float);
extern void  validate(float **, float *, int *, int,float *,float *);
extern void  end_model(int);


struct timeval  t_ini;
float  elapsed_time;
FILE  *f;
FILE  *fg;
FILE  *fm;
float  **x1;
float  val1[N_VAL_PAR_MAX];
float  val2[N_VAL_PAR_MAX];
float  avg_r2;
float  std_r2;
float  avg_rmse;
float  std_rmse;
float  avg_mae;
float  std_mae;
float  *r2;
float  *rmse;
float  *mae;
float  best_rmse;
float  best_par1;
float  best_par2;
long int  br;       // bytes reservados
float  *d;
float  *sd;
float  *sr;
int  **xe;
int  **xv;
int  **xt;
int  ntrials;
int  np;
int  ni;
int  indv;  // there are indicator variables?
int  npr; // no. training patterns
int  npv;// no. validation patterns
int  npt; // no. test patterns
int  iexp;
int  npar;
int  n_val1;
int  n_val2;
int  nexp;
int  interactive;
int  sint=sizeof(int);
int  spint=sizeof(int*);
int  sfloat=sizeof(float);
int  spfloat=sizeof(float*);
int  sdouble=sizeof(double);
char  model[100];
char  tipo[100];
char  par1_name[100];
char  par2_name[100];
char  basedir[200];
char  resultsdir[200];
char  dataset[100];
char  f_data[200];
char  f_partitions[200];
char  f_res[200];
char  f_plot[200];


void ini_time() {
	gettimeofday(&t_ini, NULL);
}


void end_time() {
	struct timeval t_fin;
	time_t  dif_seg, dif_useg;

	gettimeofday(&t_fin, NULL);
	dif_seg = t_fin.tv_sec - t_ini.tv_sec;
	dif_useg = t_fin.tv_usec - t_ini.tv_usec;
	if(dif_useg < 0) {
		dif_seg--; dif_useg += 1e6;
	}
//  fprintf(f, "# tempo= %02ih %02im %02is %03lims\n", p->tm_hour, p->tm_min, p->tm_sec, dif_useg/1000);
	elapsed_time=dif_seg+1e-6*dif_useg;
}


void *allocate(int n, size_t tam,const char *msg) {
	void *p=calloc(n,tam);
	if(! p) {
		fprintf(stderr,"error allocating memory: %s\n",msg);
		exit(1);
	}
	br+=n*tam;
	return p;
}


void deallocate(void *p,int n,size_t tam) {
	free(p);
	br-=n*tam;  // reduces the br counter by the array size
}


void *realloc_mem(void *p,int n1,int n2,size_t tam,const char *msg) {
	void *q=realloc(p,n2*tam);
	if(! q) {
		fprintf(stderr,"error realloc: %s\n",msg);
		exit(1);
	}
	br+=(n2-n1)*tam;
	return q;
}



void read_args(int argc, char *argv[]) {
	int  i, j=0;
   
/*  for(i = 1; i < argc; i++) {
	printf("arg %i: %s\n", i, argv[i]);
  }*/
	strcpy(model, argv[j++]);
	strcpy(basedir, argv[j++]);
	strcpy(resultsdir, argv[j++]);
	strcpy(dataset, argv[j++]);
	sprintf(f_data, "%s/data/%s/%s_R.dat", basedir, dataset,dataset);
	sprintf(f_res, "%s/results_%s_C_%s.dat",resultsdir,model,dataset);
	sprintf(f_plot, "%s/plot_%s_%s.dat",resultsdir,model,dataset);
	
	npar = atoi(argv[j++]);
	if(npar > 0) {
		if(npar > N_PAR_MAX) error(1, errno, "error: npar= %i > %i\n", npar, N_PAR_MAX);
		strcpy(par1_name, argv[j++]); strcpy(par2_name, "ningun");
		n_val1 = atoi(argv[j++]);
		if(n_val1 > N_VAL_PAR_MAX) error(1, errno, "error: n_val1= %i > %i\n", n_val1, N_VAL_PAR_MAX);
		for(i = 0; i < n_val1; i++) val1[i] = atof(argv[j++]);
		#ifdef DEBUG_ARGUMENT_READING
		printf("par %s: %i values: ", par1_name, n_val1);
		for(i = 0; i < n_val1; i++) printf("%g ", val1[i]);
		printf("\n");
		#endif
		if(2 == npar) {
			strcpy(par2_name, argv[j++]);
			n_val2 = atoi(argv[j++]);
			if(n_val2 > N_VAL_PAR_MAX) error(1, errno, "erro: n_val2= %i > %i\n", n_val2, N_VAL_PAR_MAX);
			for(i = 0; i < n_val2; i++) val2[i] = atof(argv[j++]);

			#ifdef DEBUG_ARGUMENT_READING
			printf("par %s: %i values: ", par2_name, n_val2);
			for(i = 0; i < n_val2; i++) printf("%g ", val2[i]);
			printf("\n");
			#endif	  
		}
	} else {
		strcpy(par1_name, "nome"); strcpy(par2_name, "none"); 
	}
	interactive = atoi(argv[j]);
	#ifdef DEBUG_ARGUMENT_READING
	exit(0);
	#endif
}


FILE *open_file(char *file, const char *perm) {
	FILE  *f=fopen(file,perm);
	if(!f) {
		fprintf(stderr, "open_file: error fopen %s: %s\n", file, strerror(errno));
		exit(1);
	}
	return(f);
}



void read_dataset_info() {
	FILE  *pf;
	char  fich[200], s[100];
	
	sprintf(fich, "%s/data/%s/%s.txt", basedir, dataset, dataset);
	pf=open_file(fich, "r");
	fscanf(pf, "%s %i", s, &np);
	fscanf(pf, "%s %i", s, &ni);
	fclose(pf);
	
	ntrials=(np<=10000 ? 500 : 10);
}


void read_patterns() {
	FILE  *pf;
	int  i, j, k;
	char  cad[100];


	x1 = (float**)allocate(np,spfloat,"read_patterns:x1");
	for(i=0;i<np;i++) x1[i]=(float*)allocate(ni,sfloat,"read_patterns:x1[i]");
	d=(float*)allocate(np,sfloat,"read_patterns:d");
	pf=open_file(f_data, "r");
	for(i = 0; i < ni; i++) fscanf(pf, "%s", cad);
	fscanf(pf, "%s\n", cad);
	for(i = 0; i < np; i++) {
		fscanf(pf, "%i ", &k);
		for(j = 0; j < ni; j++) {
			fscanf(pf, "%g ", &x1[i][j]);
			#ifdef DEBUG_DATA_READING
			if(j < 5) printf("%g ", x1[i][j]);
			#endif
		}
		fscanf(pf, "%g\n", &d[i]);
		#ifdef DEBUG_DATA_READING
		printf("output= %g\n", d[i]);
		if(i == 2) exit(0);
		#endif
	}
	fclose(pf);
}


void read_partitions() {
	FILE  *pf;
	int  i,j,t;


	xe=(int**)allocate(ntrials,spint,"read_partitions:xe");
	xv=(int**)allocate(ntrials,spint,"read_partitions:xv");
	xt=(int**)allocate(ntrials,spint,"read_partitions:xt");
	
	sprintf(f_partitions,"%s/data/%s/%s_partitions.dat",basedir,dataset,dataset);
	pf=open_file(f_partitions, "r");
	
	npr=TRAIN_PERC*np/100;  // no. train patterns
	npv=VALID_PERC*np/100;  // no. validation patterns
	npt=np-npr-npv;  // no. test patterns

	for(i=0;i<ntrials;i++) {
		xe[i]=(int*)allocate(npr,sint,"read_partitions:xe[i]");
		xv[i]=(int*)allocate(npv,sint,"read_partitions:xv[i]");
		xt[i]=(int*)allocate(npt,sint,"read_partitions:xt[i]");
	}
	
	for(i = 0; i < ntrials; i++) {
		#ifdef DEBUG_PARTITION_READING
		printf("TRIAL %i: train: ", i);
		#endif
		for(j = 0; j < npr; j++) {
			fscanf(pf, "%i", &t);xe[i][j]=t-1;
			#ifdef DEBUG_PARTITION_READING
			if(j < 3) printf("%i ", xe[i][j]);
			#endif
		}
		fscanf(pf, "\n");
		#ifdef DEBUG_PARTITION_READING
		printf("\nvalidation: ");
		#endif
		for(j = 0; j < npv; j++) {
			fscanf(pf, "%i", &t); xv[i][j]=t-1;
			#ifdef DEBUG_PARTITION_READING
			if(j < 3) printf("%i ", xv[i][j]);
			#endif
		}
		fscanf(pf, "\n");
		#ifdef DEBUG_PARTITION_READING
		printf("\ntest: ");
		#endif
		for(j = 0; j < npt; j++) {
			fscanf(pf, "%i", &t); xt[i][j]=t-1;
			#ifdef DEBUG_PARTITION_READING
			if(j < 3) printf("%i ", xt[i][j]);
			#endif
		}
		fscanf(pf, "\n");
		#ifdef DEBUG_PARTITION_READING
		if(i==2) exit(0);
		#endif
	}
	fclose(pf);
}


void initialize() {
	read_dataset_info();
	read_patterns();
	read_partitions();

	r2=(float*)allocate(ntrials,sfloat,"initialize:r2");
	rmse=(float*)allocate(ntrials,sfloat,"initialize:rmse");
	mae=(float*)allocate(ntrials,sfloat,"initialize:mae");
	
	if(0 == npar)
		nexp = ntrials;
	else if(1 == npar)
		nexp = n_val1*ntrials + ntrials;
	else if(2 == npar)
		nexp = n_val1*n_val2*ntrials + ntrials;
	iexp = 0;

	f=open_file(f_res, "w");
	fprintf(f, "# processing %s with %s file= %s ...\n", dataset, model, f_data); fflush(f);
	if(1==npar)
		fprintf(f, "#%20s\t%20s\t%20s\t%20s\n", "progress(%)",par1_name,"mse","best_rmse"); 
	else if(2==npar)
		fprintf(f, "#%20s\t%20s\t%20s\t%20s\t%20s\n", "progress(%)",par1_name, par2_name,"mse","best_rmse");
	fflush(f);	
}


void ini_tuning() {
	sd=(float*)allocate(npv,sfloat,"ini_tuning:sd");
	sr=(float*)allocate(npv,sfloat,"ini_tuning:sr");
	ini_model(npr);	
    best_rmse=1E10;
}


float root_mean_squared_error(float *x,float *y,int n) {
	float  rmse,t;
	int  i;
	
	for(i=rmse=0;i<n;i++) {
		t=x[i]-y[i];rmse+=t*t;
	}
	rmse=sqrt(rmse/n);
	
	return(rmse);
}


// ivp1= índex of value of par1; ivp2= índex of value of par2
void eval_par_values(int ivp1, int ivp2) {
	float  valp1 = val1[ivp1], valp2 = val2[ivp2],rmse;
	int  i;

	for(i=avg_rmse=0; i < ntrials; i++) {
		train(x1, d, xe[i], npr, valp1, valp2);
		validate(x1,d,xv[i],npv,sd,sr);
		rmse=root_mean_squared_error(sd,sr,npv);avg_rmse+=rmse;iexp++;
		if(interactive) fprintf(stderr, "%5.1f%%\r", 100.*iexp/nexp);
	}
	avg_rmse/=ntrials;
	if(avg_rmse < best_rmse) {
		best_rmse=avg_rmse;best_par1=valp1;best_par2=valp2;
	}
	fprintf(f, "%20.5f\t%20.5f\t%20.10f\t%20.5f\t %20.5f\n", 100.*iexp/nexp,valp1, valp2, avg_rmse,best_rmse); fflush(f);
}



void end_tuning() {	
	int  i;
	
	fprintf(f, "#%s_mellor= %g ", par1_name, best_par1);
	if(2 == npar) fprintf(f, "%s_mellor= %g ", par2_name, best_par2);
	fprintf(f,"best_rmse= %.5f\n", best_rmse);fflush(f);
	deallocate(sd,npv,sfloat);deallocate(sr,npv,sfloat);
	for(i=0;i<ntrials;i++) deallocate(xv[i],npv,sint);
	deallocate(xv,ntrials,spint);
}



void ini_test() {
	char  nf[200];
	
	
	fg=open_file(f_plot,"w");
	sd=(float*)allocate(npt,sfloat,"ini_test:sd");
	sr=(float*)allocate(npt,sfloat,"ini_test:sr");
	sprintf(nf,"%s/trials_%s_%s.dat",resultsdir,model,dataset);fm=open_file(nf,"w");

	ini_time();
}


void free_mem() {
	int  i;
	
	for(i=0;i<np;i++) deallocate(x1[i],ni,sfloat);
	deallocate(x1,np,spfloat);deallocate(d,np,sfloat);
	for(i=0;i<ntrials;i++) {
		deallocate(xe[i],npr,sint);deallocate(xt[i],npt,sint);
	}
	deallocate(xe,ntrials,spint);deallocate(xt,ntrials,spint);
	deallocate(sd,npt,sfloat);deallocate(sr,npt,sfloat);
	deallocate(r2,ntrials,sfloat);
	deallocate(rmse,ntrials,sfloat);
	deallocate(mae,ntrials,sfloat);
	if(br) fprintf(stderr,"WARNING: %ld bytes of memory are not freed\n",br);
}


void evaluate(float *x,float *y,int n,float *pr2,float *prmse,float *pmae) {
	float  rmse,mae,dif,dx,dy,num,a,b,xm,ym;
	int  i;
	
	for(i=xm=ym=0;i<n;i++) {
		xm+=x[i];ym+=y[i];
	}
	
	for(i=rmse=mae=num=a=b=0,xm=xm/n,ym=ym/n;i<n;i++) {
		dif=x[i]-y[i];rmse+=dif*dif;mae+=fabs(dif);
		dx=x[i]-xm;a+=dx*dx;
		dy=y[i]-ym;b+=dy*dy;
		num+=dx*dy;
	}
	*prmse=sqrt(rmse/n);*pmae=mae/n;
	*pr2=num/sqrt(a*b);
}

void end_test() {
	float  t;
	int  i;
	char  nf[200];
	
	end_model(npr);
	
	for(i=avg_r2=avg_rmse=avg_mae=0;i<ntrials;i++) {
		avg_r2+=r2[i];avg_rmse+=rmse[i];avg_mae+=mae[i];
	}
	for(i=std_r2=std_rmse=std_mae=0,avg_r2/=ntrials,avg_rmse/=ntrials,avg_mae/=ntrials;i<ntrials;i++) {
		t=rmse[i]-avg_rmse;std_rmse+=t*t;
	}
	std_r2=sqrt(std_r2/ntrials);std_rmse=sqrt(std_rmse/ntrials);std_mae=sqrt(std_mae/ntrials);
	
	fprintf(f, "avg_r2= %g std= %g\n",avg_r2,std_r2);
	fprintf(f, "avg_rmse= %g std= %g\n",avg_rmse,std_rmse);
	fprintf(f, "avg_mae= %g std= %g\n",avg_mae,std_mae);
	end_time();elapsed_time=elapsed_time/ntrials;
	fprintf(f, "time= %f s.\n", elapsed_time);
	fclose(f);
	
	sprintf(nf,"%s/%s_%s.csv",resultsdir,model,dataset);
	fm=open_file(nf,"w");
	fprintf(fm,"%g %g %g %g\n",avg_r2,avg_rmse,avg_mae,elapsed_time);
	fclose(fm);
	
	fclose(fg);	
	free_mem();
}


int main(int argc, char *argv[]) {
	int  i,j;

	read_args(argc, argv);
	initialize();

	if(npar > 0) {  // parameter tuning
		ini_tuning();
		if(1 == npar)
			for(i = 0; i < n_val1; i++) eval_par_values(i, 0);
		else if(2 == npar)
			for(i = 0; i < n_val1; i++)
				for(j = 0; j < n_val2; j++) eval_par_values(i, j);
		else {
			fprintf(stderr, "erro: npar= %i > 2\n", npar); exit(1);
		}
		end_tuning();
	}

	ini_test();
	for(i=0;i<ntrials;i++) {
		train(x1,d,xe[i],npr,best_par1,best_par2);
		validate(x1,d,xt[i],npt,sd,sr);
		for(j=0;j<npt;j++) fprintf(fg,"%f %f\n",sd[j],sr[j]);
		evaluate(sd,sr,npt,&r2[i],&rmse[i],&mae[i]);iexp++;
		fprintf(fm,"%10i %10g %10g %10g\n",i,r2[i],rmse[i],mae[i]);
		if(interactive) fprintf(stderr, "%5.1f%%\r", 100.*iexp/nexp);
	}
	end_test();
	
	return(0);
}