require(kernlab,quietly=T)
svmRadial.model=ksvm(output ~ .,data=pr,type='eps-svr',kernel='rbfdot',C=val_par2,kpar=list(sigma=val_par1))
sr=predict(svmRadial.model,pv)
rm(svmRadial.model)
