require(plsRglm,quietly=T)
sink('/dev/null')
lm.model=lm(output~.,data=pr);indices=which(is.finite(lm.model$coefficients[-1]))
plsRglm.model=plsRglm(dataY=pr[,i_output],dataX=pr[,indices],modele='pls-glm-gaussian',nt=val_par1,alpha.pvals.expli=val_par2)
while(sink.number()>0) { sink(NULL) }
sr=predict(plsRglm.model,pv[,indices])
rm(plsRglm.model)
