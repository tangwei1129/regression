require(MASS,quietly=T)
if(val_par1==1) {
	psi=psi.huber
} else {
	if(val_par1==2) {
		psi=psi.hampel
	} else {
		psi=psi.bisquare
	}
}
lm.model=lm(output~.,data=pr);indices=which(is.finite(lm.model$coefficients[-1]))
rlm.model=rlm(output ~ . ,data=pr[,c(indices,i_output)],maxit=100,psi=psi)  #add argument psi
sr=predict(rlm.model,pv[,indices]);sr[is.na(sr)]=0
rm(lm.model,indices,rlm.model)
