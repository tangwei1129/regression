require(mboost,quietly=TRUE)
gamboost.model=gamboost(output ~ ., data=pr,control=boost_control(mstop=val_par1),baselearner='btree') #con baselearner='bbs' (spline) da erros en 20 problemas
sr=predict(gamboost.model,pv[,-i_output])
rm(pcaNNet.model)

