require(pls,quietly=T)
pcr.model=pcr(output ~ ., data=pr,ncomp=val_par1)
sr=predict(pcr.model,comps=1:val_par1,pv)
rm(pcr.model)
