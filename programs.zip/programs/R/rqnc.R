require(rqPen,quietly=T)
tx=as.matrix(pr[,-i_output]);ty=as.matrix(pr[,i_output])
penalty=switch(val_par2,'MCP','SCAD');
rqnc.model=rq.nc.fit(tx,ty,lambda=val_par1,penalty=penalty)
rm(tx,ty,penalty)
tx=as.matrix(pv[,-i_output]);sr=predict(rqnc.model,tx)
if(sd(sr)==0) stop('constant predicted output')
rm(tx,rqnc.model)

