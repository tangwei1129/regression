args = commandArgs(trailingOnly = TRUE)

# n_args = length(args)
# for (i in 1:n_args) {
#   print(args[i])
# }

j=1
basedir = args[j]; j=j+1
resultsdir = args[j]; j=j+1
dataset = args[j]; j=j+1
model = args[j]; j=j+1
f_patterns= sprintf("%s/data/%s/%s_R.dat", basedir, dataset, dataset)
f_plot=sprintf("%s/plot_%s_%s.dat", resultsdir, model, dataset)
f_res=sprintf("%s/results_%s_R_%s.dat", resultsdir, model, dataset)
system(sprintf('rm -f %s 2>/dev/null',f_plot))
write(sprintf("running model %s dataset %s file= %s ...", model, dataset, f_patterns),file=f_res)
interactive= as.integer(args[j]); j=j+1
libR= args[j]
# cat(sprintf('libR=%s',libR))
if(! is.na(libR)) {
  .libPaths(libR)  # includes libR in the library path list
}

# reads data set information
f = sprintf("%s/data/%s/%s.txt", basedir, dataset, dataset)
t=scan(f,what=' ',quiet=T)
np=as.integer(t[2])
ni= as.integer(t[4])

if(np<=10000) {
	ntrials=500
} else {
	ntrials=10
}
error_flag=logical(ntrials)

#data reading: read.table converts strings in factors by default
x=read.table(f_patterns); i_output=length(x)

#generates values for tunable parameters
library(caret,quietly=T)
if(model=='bagEarth' | model=='earth') library(earth)
if(model=='rpart') library(rpart)
if(model=='glmnet') library(glmnet)
v=read.table('values.txt');nv=nrow(v);models=rownames(v);found=FALSE;n=ncol(x)
for(i in 1:nv) {
	if(model==models[i]) {
		npar=v[i,1];n_val1=v[i,2];n_val2=v[i,3];n_val3=v[i,4];n_val4=v[i,5];found=TRUE;rm(v)
		break
	}
}
if(found==FALSE) { stop(sprintf('%s not found in file values.txt',model)) }

# if(dataset=='electricity_hourly' & model=='relaxo') {
# 	npar=2;par1_name='phi';val1=c(0.1,0.233,0.37,0.5,0.63,0.77,0.9);n_val1=length(val1);
# 	par2_name='lambda';val2=c(1.63567,4.24088,10.9955);n_val2=length(val2) 
# }

if(npar>0) {
	t1=getModelInfo(model)[[1]]$grid(x[,-n],x[,n],n_val1,'grid')
	par1_name=names(t1)[1];val1=unique(t1[,1]);n_val1=min(n_val1,length(val1));val1=val1[1:n_val1];rm(t1)
	if(npar>1) {
		t2=getModelInfo(model)[[1]]$grid(x[,-n],x[,n],n_val2,'grid')
		par2_name=names(t2)[2];	val2=unique(t2[,2]);n_val2=min(n_val2,length(val2));val2=val2[1:n_val2];rm(t2)
		if(npar>2) {
			t3=getModelInfo(model)[[1]]$grid(x[,-n],x[,n],n_val3,'grid')
			par3_name=names(t3)[3];val3=unique(t3[,3]);n_val3=min(n_val3,length(val3));val3=val3[1:n_val3];rm(t3)
			if(npar>3) {
				t4=getModelInfo(model)[[1]]$grid(x[,-n],x[,n],n_val4,'grid')
				par4_name=names(t4)[4];val4=unique(t4[,4]);n_val4=min(n_val4,length(val4));val4=val4[1:n_val4];rm(t4)
			}
		}
	}
}

# some models require correct values for tunable hyperparameters
if(model=='ridge') {npar=1;par1_name='lambda';n_val1=5;val1=c(0.01,0.03,0.05,0.07,0.1) }
if(model=='rlm') { npar=1;par1_name='psi';n_val1=3;val1=c(1,2,3) }
if(model=='mlpWeightDecay') {npar=2;par1_name='size';n_val1=5;val1=seq(1,19,2);par2_name='decay';n_val2=5;val2=c(0,0.1,0.042,0.01778,0.007498) }
if(model=='mlpWeightDecayML') {
	npar=4;par1_name='layer1';n_val1=3;val1=c(5,10,15);par2_name='layer2';n_val2=3;val2=c(5,10,15);
	par3_name='layer3';n_val3=3;val3=c(5,10,15);par4_name='decay';n_val4=5;val4=c(0,0.1,0.042,0.01778,0.007498)
}
if(model=='krlsRadial') { val1=0.1 }
if(model=='icr') { npar=1;par1_name='n.comp';val1=1:(n-1);n_val1=length(val1) }
if(model=='bdk') { 
	npar=3; par1_name='xdim';val1=c(8,12,17);n_val1=length(val1) 
	par2_name='ydim';val2=c(8,12,17);n_val2=length(val2);par3_name='xweight';val3=c(0.5,0.75,0.9);n_val3=length(val3)
}
if(model=='rqlasso' || model=='rqnc' || model=='qrnn') perf_measure='qerror'

#prints tunable hyperparameter values
if(npar>0) {
	cat(sprintf('#%s: %i values: ',par1_name,n_val1),file=f_res,append=T)
	for(i in 1:n_val1) cat(sprintf(' %g',val1[i]),file=f_res,append=T);cat('\n',file=f_res,append=T)
	if(npar>1) {
		cat(sprintf('#%s: %i values: ',par2_name,n_val2),file=f_res,append=T)
		for(i in 1:n_val2) cat(sprintf(' %g ',val2[i]),file=f_res,append=T);cat('\n',file=f_res,append=T)
	}
	if(npar>2) {
		cat(sprintf('#%s: %i values: ',par3_name,n_val3),file=f_res,append=T)
		for(i in 1:n_val3) cat(sprintf(' %g ',val3[i]),file=f_res,append=T);cat('\n',file=f_res,append=T)
	}
	if(npar>3) {
		cat(sprintf('#%s: %i values: ',par4_name,n_val4),file=f_res,append=T)
		for(i in 1:n_val4) cat(sprintf(' %g ',val4[i]),file=f_res,append=T);cat('\n',file=f_res,append=T)
	}
}

train_perc=70
valid_perc=20

npr=floor(train_perc*np/100)
npv=floor(valid_perc*np/100)
npt=np-npr-npv

#reading partitions
f_partitions= sprintf("%s/data/%s/%s_partitions.dat", basedir, dataset, dataset)
t=scan(f_partitions, comment.char = "#", quiet= TRUE)
xr=matrix(nrow=ntrials,ncol=npr);xv=matrix(nrow=ntrials,ncol=npv);xt=matrix(nrow=ntrials,ncol=npt)
for (i in 1:ntrials) {
	ini=(i-1)*np+1;fin=ini+npr-1;xr[i,]=t[ini:fin]
	ini=fin+1;fin=ini+npv-1;xv[i,]=t[ini:fin]
	ini=fin+1;fin=ini+npt-1;xt[i,]=t[ini:fin]
}

ferr=sprintf("%s/err_%s_%s.dat",resultsdir,model,dataset)
tryCatch({ file.remove(ferr) },warning=function(cond) { })

