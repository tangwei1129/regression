#!/bin/bash
# consultar taboa en: https://wiki.citius.usc.es/es:centro:servizos:hpc
#PBS -l nodes=1:ppn=1,walltime=48:00:00
#PBS -N xgbTree_online_news
#PBS -e outputs/online_news/xgbTree_R_online_news.err
#PBS -o outputs/online_news/xgbTree_R_online_news.out
#PBS -m n -M manuel.fernandez.delgado@usc.es

basedir=$HOME/artigos/comparacion_regresores/experiments
datadir=$basedir/data
programsdir=$basedir/programs
resultsdir=$basedir/results
cd $programsdir

interactive=0
dataset=online_news
model=xgbTree
implem=R
args_model=''

resultsdir=/scratch/manuel.fernandez.delgado/comparacion_regresores/results/${dataset}/${model}_${implem}
mkdir -p $resultsdir

export PATH=$PATH:.
export TERM=xterm
memory=`expr 2 \* 1 / 4`


mkdir ${programsdir}/scripts/${dataset} 2> /dev/null
mkdir ${programsdir}/outputs/${dataset} 2> /dev/null
copydir=${basedir}/old_results/${dataset}/${model}_${implem}
mkdir $copydir 2> /dev/null
mv $resultsdir/*.* $copydir 2> /dev/null
> outputs/${model}_${implem}_${dataset}.err


f_log=${resultsdir}/output_${model}_${implem}_${dataset}.dat; rm -f $f_log 2> /dev/null


## C ########################################################
if [ $implem = "C" ]; then
	cd C; make -B $model; $model $basedir $resultsdir $dataset $args_model $interactive
## MATLAB ###################################################
elif [ $implem = "matlab" ]; then
	module load matlab; cd matlab
	matlab -nodisplay -nosplash -nojvm -singleCompThread -r "regression $basedir $resultsdir $dataset $model $args_model $interactive" -logfile $f_log > /dev/null
## R ########################################################
elif [ $implem = "R" ]; then
	module load R; module load jdk;
	export _JAVA_OPTIONS=-Xmx${memory}G  #required bartMachine and extraTrees
	cd R; export R_LIBS_SITE="~/libR"
	R -q --no-save --slave --file="regression.R" --args $basedir $resultsdir $dataset $model $args_model $interactive $R_LIBS_SITE > $f_log 2>&1
## WEKA #####################################################
elif [ $implem = "weka" ]; then
	export WEKAINSTALL=$HOME/weka-3-6-8
	export CLASSPATH=$WEKAINSTALL/weka.jar:$WEKAINSTALL/libsvm.jar:$WEKAINSTALL/liblinear-1.7-with-deps.jar:.
	module load jdk; export _JAVA_OPTIONS=-Xmx${memory}G
	cd weka; javac Regression.java
	java -Xmx2048m Regression $basedir $resultsdir $dataset $model $interactive $args_model > ${f_log}
	unset CLASSPATH
elif [ $implem = "python" ]; then
	cd python;python regression.py $basedir $resultsdir $dataset $model $interactive $args_model > ${f_log}
fi

cd $programsdir

#  	module load matlab
#  	matlab -nodisplay -nodesktop -nosplash -r "makeplot $basedir $dataset $model $implem" > /dev/null 2>&1

cp $resultsdir/* ${basedir}/results/${dataset}/${model}_${implem}