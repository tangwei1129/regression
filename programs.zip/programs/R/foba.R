require(foba,quietly=T)
lm.model=lm(output~.,pr);indices=which(is.finite(lm.model$coefficients[-1]))
foba.model=foba(pr[,indices],pr[,i_output],type='foba',lambda=val_par1)
sr=predict(foba.model,pv[,indices],k=val_par2)$fit
rm(lm.model,indices,foba.model)
