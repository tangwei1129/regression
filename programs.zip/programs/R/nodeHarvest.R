# se da "Error in 1:nrow(tree) : argument of length 0", é por poucos patróns: usar opcións nodes=X e nodesize=Y con X,Y baixos (X<~=nº patróns)
require(nodeHarvest,quietly=T)
if(val_par2==1) {
	mode='mean'
} else {
	mode='outbag'
}
lm.model=lm(output~.,pr);indices=which(is.finite(lm.model$coefficients[-1]))
nodeHarvest.model=nodeHarvest(pr[,indices],pr[,i_output],maxinter=val_par1,mode=mode,silent=T,nodesize=3,nodes=10)
sr=predict(nodeHarvest.model,pv[,indices])
rm(lm.model,indices,nodeHarvest.model)

