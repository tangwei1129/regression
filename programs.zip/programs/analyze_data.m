clear all
clc
addpath('./matlab');

dataset={'3Droad','airfoil','air_quality_CO','air_quality_NMHC','air_quality_NO2',...
    'air_quality_NOx','air_quality_O3','appliances_energy','automobile','auto_mpg',...
    'beijing_pm25','bike_day','bike_hour','blog_feedback','buzz_twitter',...
    'combined_cycle','com_crime','com_crime_unnorm','com_hd','compress_stren',...
    'cond_turbine','csm1415','CT_slices','cuff_less','daily_demand',...
    'dynamic_features','energy_cool','energy_heat',...
    'facebook_comment','facebook_metrics','forestfires',...
    'gas_dynamic_CO','gas_dynamic_methane','geo_lat','geo_long',...
    'geo_music_lat','geo_music_long','gps_trajectory','greenhouse_net',...
    'household_consume','housing','KEGG_reaction','KEGG_relation','online_news',...
    'park_motor_UPDRS','park_speech','park_total_UPDRS','physico_protein',...
    'pm25_beijing_dongsi','pm25_beijing_dongsihuan','pm25_beijing_nongzhanguan',...
    'pm25_beijing_us_post','pm25_chengdu_caotangsi','pm25_chengdu_shahepu',...
    'pm25_chengdu_us_post','pm25_guangzhou_5th_middle_school',...
    'pm25_guangzhou_city_station','pm25_guangzhou_us_post','pm25_shanghai_jingan',...
    'pm25_shanghai_us_post','pm25_shanghai_xuhui','pm25_shenyang_taiyuanji',...
    'pm25_shenyang_us_post','pm25_shenyang_xiaoheyan','servo','slump','slump_comp',...
    'slump_flow','SML2010','stock_abs','stock_annual','stock_excess',...
    'stock_exchange','stock_rel','stock_systematic','stock_total','student_mat',...
    'student_por','UJ_lat','UJ_long','video_transcode','yacht_hydro','year_prediction'};
ndata=numel(dataset);

model={'lm','glm','dnn','Boruta','dlkeras','elm_kernel','enpls.fs','bstSm','grnn',...
    'blackboost','glmnet','earth','rpart','bagEarth','kernelpls','simpls','rlm',...
    'ridge','nnls','lars','pcr','avNNet','lasso','ppr','glmStepAIC','krlsRadial',...
    'xgbTree','foba','rf','superpc','gam','gaussprLinear','gaussprRadial','rvmRadial',...
    'svr','kknn','rqlasso','treebag','bayesglm','spls','gaussprPoly','cforest',...
    'cubist','nodeHarvest','gbm','qrf','rqnc','RRF','penalized','icr','relaxo',...
    'extraTrees','bag','M5','rbf','SBC','glmboost','elm','spikeslab','svmRadial',...
    'pcaNNet','ctree2','plsRglm','bdk','brnn','xgbLinear','gamboost','mlpWeightDecay',...
    'randomGLM','partDSA','bartMachine','evtree','BstLm','bstTree','mlpWeightDecayML',...
    'qrnn','widekernelpls','enet'};
nmodel=numel(model);

implem=cell(1,nmodel);
for i=1:nmodel
    implem{i}='R';
end
implem{strcmp(model,'svr')}='C';
implem{strcmp(model,'grnn')}='matlab';
implem{strcmp(model,'elm_kernel')}='matlab';
implem{strcmp(model,'dlkeras')}='python';

np=zeros(1,ndata);ni=zeros(1,ndata);
fprintf('reading np and ni ...\n');nspc=6;fprintf(repmat(' ',1,nspc));str=repmat('\b',1,nspc);
for i=1:ndata
    data=dataset{i};nf=sprintf('../data/%s/%s.txt',data,data);
    f=fopen(nf,'r');
    if -1==f
        error('fopen %s',nf);
    end
    fscanf(f,'%s',1);np(i)=fscanf(f,'%i',1);
    fscanf(f,'%s',1);ni(i)=fscanf(f,'%i',1);
    fclose(f);
    fprintf(str);fprintf('%5.1f%%',100*i/ndata)
end
fprintf('\n')

% dataset2={'bike_hour','combined_cycle','cond_turbine','CT_slices','KEGG_reaction','UJ_lat','UJ_long'};
% ndata2=numel(dataset2);np2=zeros(1,ndata2);
% for i=1:ndata2
%     for j=1:ndata
%         if strcmp(dataset2{i},dataset{j})
%             np2(i)=np(j);
%         end
%     end
% end
% [~,i]=sort(np2);
% for j=1:ndata2
%     k=i(j);
% %     fprintf('%s %i\n',dataset2{k},np2(k))
%     fprintf('%s ',dataset2{k})
% end

% plot of number of patterns and inputs
clf; loglog(ni,np,'bs','markerfacecolor','b');grid on
xlabel('Number of inputs');ylabel('Number of patterns');
print('-depsc','../results/REPORTS/datasets_plot.eps')



% stores datasets sorted by increasing np
[~,i]=sort(np);f=fopen('../data/datasets_sorted_npatterns.txt','w');
for j=1:ndata
    k=i(j);fprintf(f,'%s %i\n',dataset{k},np(k));
end
fclose(f);

% plot of number of patterns and inputs
clf; semilogy(np(i),'.');grid on
xlabel('Dataset');ylabel('Number of patterns');
axis([0 ndata+1 50 3e6])
print('-depsc','../results/REPORTS/number_of_patterns.eps')

% reads r2, rmse errors and times of lm
r2_lm=zeros(1,ndata);rmse_lm=zeros(1,ndata);time_lm=zeros(1,ndata);
fprintf('reading R^2, RMSE and time ...\n');nspc=6;fprintf(repmat(' ',1,nspc));str=repmat('\b',1,nspc);
for i=1:ndata
    data=dataset{i};
    nf=sprintf('../results/%s/lm_R/lm_%s.csv',data,data);f=fopen(nf,'r');
    r2_lm(i)=fscanf(f,'%g',1);rmse_lm(i)=fscanf(f,'%g',1);
    fscanf(f,'%g',1);time_lm(i)=fscanf(f,'%g',1);
    fclose(f);
    fprintf(str);fprintf('%5.1f%%',100*i/ndata)
end
fprintf('\n')

% plot of R2 of lm sorted
[~,i]=sort(r2_lm);plot(r2_lm(i),'.');grid on
xlabel('Dataset (sorted by R^2)');ylabel('R^2 of lm');
axis([0 ndata+1 0 max(r2_lm)])
print('-depsc','../results/REPORTS/r2_lm.eps')

% stores r2_lm for each dataset, sorted by decreasing r2_lm
nf='../results/REPORTS/r2_lm_sorted.txt';f=fopen(nf,'w');
[~,i]=sort(r2_lm,'descend');
fprintf(f,'%3s\t%40s\t%10s\t%10s\n','No.','regressor','R^2','#patterns');
for j=1:ndata
    k=i(j);fprintf(f,'%3i\t%40s\t%10f\t%10i\n',j,dataset{k},r2_lm(k),np(k));
end
fclose(f);

% mostra datasets en cada grupo
nf='../results/REPORTS/dataset_groups.txt';f=fopen(nf,'w');
% grupo 1
ind=find(np<5000 & r2_lm<0.6);n=numel(ind);
fprintf(f,'grupo 1: NPvR2v: %i datasets: ',n);
fprintf(f,'%s ',dataset{ind});fprintf(f,'\n');
% grupo 2
ind=find(np<5000 & r2_lm>=0.6);n=numel(ind);
fprintf(f,'grupo 2: NPvR2^: %i datasets: ',n);
fprintf(f,'%s ',dataset{ind});fprintf(f,'\n');
% grupo 3
ind=find(np>=5000 & r2_lm<0.6);n=numel(ind);
fprintf(f,'grupo 3: NP^R2v: %i datasets: ',n);
fprintf(f,'%s ',dataset{ind});fprintf(f,'\n');
% grupo 2
ind=find(np>=5000 & r2_lm>=0.6);n=numel(ind);
fprintf(f,'grupo 4: NP^R2^: %i datasets: ',n);
fprintf(f,'%s ',dataset{ind});fprintf(f,'\n');

% plot of R2 of lm against number of patterns
[~,i]=sort(np);clf;semilogx(np(i),r2_lm(i),'.','markersize',20);hold on
plot([10 max(np)],[0.6 0.6],':k')
plot([5000 5000],[0 1.02],':k')
% set(gca,'YGrid','on')
xlabel('#patterns','fontsize',18);ylabel('R^2_{lm}','fontsize',18);
axis([10 3e6 0 1.02])
print('-depsc','../results/REPORTS/r2_lm_vs_np.eps')

% plot of RMSE of lm against number of patterns
[~,i]=sort(np);clf;loglog(np(i),rmse_lm(i),'.');%grid on
xlabel('Dataset (sorted by population)');ylabel('RMSE of lm');
% axis([0 ndata+1 min(rmse_lm) max(rmse_lm)])
print('-depsc','../results/REPORTS/rmse_lm_vs_np.eps')

% plot of times of lm against number of patterns
clf;loglog(np(i),time_lm(i),'.')
xlabel('Dataset (sorted by population)');ylabel('Time (in sec.) spent by lm');
axis([50 3e6 5e-2 3e3])
print('-depsc','../results/REPORTS/time_lm_vs_np.eps')

% reads times of all the regressors on the smallest dataset (daily_demand)
time=zeros(1,nmodel);error=zeros(1,nmodel);
fprintf('reading regressor times ...\n');nspc=6;fprintf(repmat(' ',1,nspc));str=repmat('\b',1,nspc);
for i=1:nmodel
    nf=sprintf('../results/daily_demand/%s_%s/%s_daily_demand.csv',model{i},implem{i},model{i});%f=fopen(nf,'r');
    f=fopen(nf,'r');
    if -1~=f
        fscanf(f,'%g',3);time(i)=fscanf(f,'%g',1);
        fclose(f);
    else
        error(i)=1;
    end
    fprintf(str);fprintf('%5.1f%%',100*i/ndata)
end
fprintf('\n')

fprintf('found %i errors: ',sum(error));
ind=find(error);fprintf('%s ',model{ind});fprintf('\n')

% plot of times spent by all the regressors on the smallest dataset
time2=time;time2(ind)=[];
model2=model;model2(ind)=[];
[~,i]=sort(time2);clf; semilogy(time2(i),'.-')
xlabel('Regressor');ylabel('Time (in sec.) for dataset daily_demand');
% xlabel_inclin(model(i),8e-4,100,25,8)
axis([0 numel(time)+1 8e-4 100]);grid on
print('-depsc','../results/REPORTS/time_smallest_dataset.eps')

% stores time for each regressor sorted decreasingly
nf='../results/REPORTS/time_regressors_daily_demand_sorted.txt';f=fopen(nf,'w');
fprintf(f,'%3s\t%20s\t%10s\n','No.','regressor','time');
for j=1:numel(time2)
    k=i(j);fprintf(f,'%3i\t%20s\t%10f\n',j,model2{k},time2(k));
%     fprintf('%s ',model2{k});
end
fprintf(f,'did not finish: ');fprintf(f,'%s ',model{ind});fprintf(f,'\n');
fclose(f);

