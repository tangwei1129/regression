function xlabel_inclin(etiq,ymin,ymax,inclin,fs)

n=length(etiq);
%%%%%%%%%%%%%%%
Xt = 1:n;Xl = [1 n];
set(gca,'XTick',Xt,'XLim',Xl);

% axis([1 n ymin ymax])
axis([0 n+1 ymin ymax])
ax = axis; % Current axis limits
axis(axis); % Set the axis limit modes (e.g. XLimMode) to manual
Yl = ax(3:4); % Y-axis limits
t = text(Xt,Yl(1)*ones(1,length(Xt)), etiq);
set(t,'FontSize',fs,'fontname', 'Helvetica','HorizontalAlignment','right','VerticalAlignment','top', 'Rotation',inclin);

set(gca,'XTickLabel',{' '})

for i = 1:length(t)
    ext(i,:) = get(t(i),'Extent');
end

% Determine the lowest point. The X-label will be
% placed so that the top is aligned with this point.
LowYPoint = min(ext(:,2));

% Place the axis label at this point
XMidPoint = Xl(1)+abs(diff(Xl))/2;
tl = text(XMidPoint,LowYPoint,'', 'VerticalAlignment','top', 'HorizontalAlignment','center');

end