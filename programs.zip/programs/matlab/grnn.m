function sr=grnn(pe, de, pv, ~, spread, ~, ~)
net = newgrnn(pe, de, spread);
sr = sim(net, pv);
end