require(relaxo,quietly=TRUE)
tx=scale(pr[,-i_output]);ty=scale(pr[,i_output])
sr_center=attr(ty,'scaled:center')[1];sr_scale=attr(ty,'scaled:scale')[1]
relaxo.model=relaxo(tx,ty,phi=c(0,val_par1,1),keep.data=F);rm(tx,ty)
tx=scale(pv[,-i_output])
sr=predict(relaxo.model,newX=tx,phi=val_par1,lambda=min(val_par2,max(relaxo.model$lambda)))
if(sd(sr)==0) stop('constant predicted output')
sr=sr_center+sr_scale*sr  #re-scales the output
rm(tx,relaxo.model)
