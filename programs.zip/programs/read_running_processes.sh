#!/bin/bash
clear

echo 'RUNNING PROCESS LIST:'
process_id_list=`qstat -a|grep fern|cut -d. -f1`
for process_id in ${process_id_list[*]}; do
	process_name=`qstat -f $process_id |grep Job_Name|cut -d= -f2|cut -d' ' -f2`
	process_state=`qstat -f $process_id |grep job_state|cut -d= -f2|cut -d' ' -f2`
	echo $process_name $process_id $process_state
done
