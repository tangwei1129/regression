require(KRLS,quietly=T)
sink('/dev/null')
lm.model=lm(output~.,pr);indices=which(is.na(lm.model$coefficients[-1]))
krlsRadial.model=krls(pr[,-c(indices,i_output)],pr[,i_output],whichkernel='gaussian',sigma=val_par2)
sr=predict(krlsRadial.model,pv[,-c(indices,i_output)])$fit
if(sd(sr)==0) stop('constant predicted output')
while(sink.number()>0) { sink(NULL) }
rm(krlsRadial.model)
