#!/bin/bash
fmodels=models2.txt
cut -d' ' -f1-2 models.txt > $fmodels
fdatasets=datasets.txt

while read dataset
do
	while read model implem
	do
		echo 'removing results' $dataset $model
		rm -f ../results/${dataset}/${model}_${implem}/*
	done < $fmodels
done < $fdatasets