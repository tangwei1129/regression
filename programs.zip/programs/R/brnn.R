require(brnn,quietly=T)
#  	sink('/dev/null')
brnn.model=brnn(output ~ ., data=pr,normalize=FALSE,neurons=val_par1)
#  	while(sink.number()>0) { sink(NULL) }
sr=predict(brnn.model,pv)
rm(brnn.model)