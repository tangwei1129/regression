#!/bin/bash

###########################
# user-defined variables
###########################
dataset='daily_demand'
model='superpc'
implem='R'
# args_model='1 spread 14 0.001 0.005 0.01 0.05 0.1 0.3 0.5 0.7 0.9 1 1.3 1.5 1.7 2' #grnn
# args_model='2 C 20 16384 8192 4096 2048 1024 512 256 128 64 32 16 8 4 2 1 0.5 0.25 0.125 0.0625 0.0312 gamma 25 256 128 64 32 16 8 4 2 1 0.5 0.25 0.125 0.0625 0.03125 0.01562 0.00781 0.00391 0.00195  0.00098 0.00049 0.00024 0.00012 0.00006 0.00003 1.5e-5'  #svr e elm_kernel
# args_model='3 nh1 2 50 75 nh2 2 50 75 nh3 2 50 75'  #dlkeras
interactive=1
basedir=$HOME/artigos/comparacion_regresores/copy_experiments
###########################

clear

programsdir=${basedir}/programs
resultsdir=${basedir}/results/${dataset}/${model}_${implem}
mkdir -p $resultsdir

export PATH=$PATH:.
export WEKAINSTALL=./weka
export _JAVA_OPTIONS=-Xmx8G

echo "running" $model $implem $dataset

# f_res=${resultsdir}/results_${model}_${implem}_${dataset}.dat
f_log=${resultsdir}/output_${model}_${implem}_${dataset}.dat
rm -f $f_log 2>/dev/null

### C ########################################################
if [ $implem = "C" ]; then
	cd C; make -B $model; $model $basedir $resultsdir $dataset $args_model $interactive		
### MATLAB ###################################################
elif [ $implem = "matlab" ]; then
	if [ $HOSTNAME != 'ctdesk209' ]; then
		module load matlab
	fi
	cd matlab
	matlab -nosplash -nodisplay -nodesktop -singleCompThread -r "regression $basedir $resultsdir $dataset $model $args_model $interactive" # -logfile $f_log > /dev/null
### R ########################################################
elif [ $implem = "R" ]; then
	if [ $HOSTNAME != 'ctdesk209' ]; then
		module load R;module load jdk
	fi	
 	cd R; #export R_LIBS_SITE="~/libR"  #jdk is used for package rJava
	R -q --no-save --slave --file="regression.R" --args $basedir $resultsdir $dataset $model $interactive $R_LIBS_SITE #2> $f_log
### WEKA #####################################################
elif [ $implem = "weka" ]; then
	module load jdk;export CLASSPATH=$WEKAINSTALL/weka-3.6.8.jar:.;cd weka;rm -f Regression.class; javac Regression.java
	java -Xmx2048m Regression $basedir $dataset $model $f_res $interactive $args_model #> ${f_log}
	unset CLASSPATH
### PYTHON #####################################################
elif [ $implem = "python" ]; then
	cd python;python regression.py $basedir $resultsdir $dataset $model $interactive $args_model #> ${f_log}
fi

cd ${programsdir}

#  	module load matlab
#  	matlab -nodisplay -nodesktop -nosplash -r "makeplot $basedir $dataset $model $implem" > /dev/null 2>&1
# cp $resultsdir/* ${basedir}/results/${dataset}/${model}_${implem}

echo "run_model_dataset.sh" $model $dataset 'finished'
