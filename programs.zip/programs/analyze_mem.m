clear all
clc
addpath('matlab')

ngroup=4;

model_list={'elm_kernel','svr','elm','nnls','svmRadial','rpart','lm','gbm','bdk','avNNet','ctree2','widekernelpls','enet','plsRglm','extraTrees','glmboost','pcaNNet','icr','rqnc','relaxo','foba','penalized','spls','ppr','superpc','dnn','gaussprPoly','gaussprLinear','rqlasso','pcr','kknn','RRF','krlsRadial','kernelpls','gam','lars','glmnet','simpls','earth','M5','mlpWeightDecay','ridge','gaussprRadial','lasso','evtree','rf','rlm','BstLm','bayesglm','rvmRadial','rbf','cforest','cubist','glmStepAIC','blackboost','qrf','grnn','SBC','partDSA','treebag','bag','mlpWeightDecayML','brnn','bagEarth','bartMachine','gamboost','bstTree','randomGLM','spikeslab','dlkeras','Boruta','xgbLinear','enpls.fs','nodeHarvest','bstSm','xgbTree','qrnn'};
model_list2={'kelm','svr','elm','nnls','svmRad','rpart','lm','gbm','bdk','avNNet','ctree2','wkpls','enet','plsRglm','extraTrees','glmboost','pcaNNet','icr','rqnc','relaxo','foba','penalized','spls','ppr','superpc','dnn','gprPol','gprLin','rqlasso','pcr','kknn','RRF','krlsRad','kpls','gam','lars','glmnet','simpls','earth','M5','mlpWD','ridge','gprRad','lasso','evtree','rf','rlm','BstLm','bayesglm','rvmRad','rbf','cforest','cubist','glmSAIC','blackboost','qrf','grnn','SBC','partDSA','treebag','bag','mlpWDml','brnn','bagEarth','bMachine','gamboost','bstTree','rndGLM','spikeslab','dlkeras','Boruta','xgbLinear','enpls.fs','nodeHarvest','bstSm','xgbTree','qrnn'};
nmodel=numel(model_list);

implem_list=cell(1,nmodel);
for i=1:nmodel
    implem_list{i}=get_implem(model_list{i});
end

global_dataset_list={};
mem=[];n_mem_errors=zeros(1,nmodel);nspc=7;
fprintf(repmat(' ',1,nspc));str=repmat('\b',1,nspc);
ndata=84;iexp=1;nexp=ndata*nmodel;ndata=0;
for group=1:ngroup
    if group==1    % 20 datasets in group 1
        dataset_list={'slump','slump_flow','gps_trajectory','csm1415','stock_abs',...
            'stock_annual','stock_excess','stock_rel','stock_systematic','stock_total',...
            'student_mat','forestfires','student_por','park_speech','geo_lat','geo_long',...
            'geo_music_lat','geo_music_long','airfoil','com_crime_unnorm'};
    elseif group==2   % 23 datasets in group 2
        dataset_list={'daily_demand','slump_comp','servo','automobile','com_hd',...
            'yacht_hydro','auto_mpg','housing','facebook_metrics','stock_exchange',...
            'bike_day','energy_cool','energy_heat','compress_stren','air_quality_CO',...
            'air_quality_NMHC','air_quality_NO2','air_quality_NOx','air_quality_O3',...
            'com_crime','gas_dynamic_CO','gas_dynamic_methane','SML2010'};
    elseif group==3   % 33 datasets in group 3
        dataset_list={'park_motor_UPDRS','park_total_UPDRS','appliances_energy',...
            'pm25_beijing_dongsihuan','pm25_shenyang_us_post','pm25_guangzhou_5th_middle_school',...
            'pm25_shanghai_jingan','pm25_shenyang_taiyuanji','pm25_chengdu_caotangsi',...
            'pm25_shanghai_xuhui','pm25_chengdu_shahepu','pm25_shenyang_xiaoheyan',...
            'pm25_beijing_nongzhanguan','pm25_beijing_dongsi','pm25_chengdu_us_post',...
            'pm25_shanghai_us_post','pm25_guangzhou_city_station','pm25_guangzhou_us_post',...
            'online_news','facebook_comment','beijing_pm25','physico_protein',...
            'pm25_beijing_us_post','KEGG_relation','blog_feedback','cuff_less',...
            'video_transcode','dynamic_features','3Droad','year_prediction',...
            'buzz_twitter','greenhouse_net','household_consume'};
    elseif group==4  % 7 datasets in group 4
        dataset_list={'combined_cycle','cond_turbine','UJ_lat','UJ_long',...
            'bike_hour','CT_slices','KEGG_reaction'};
    end
    ndata_group=numel(dataset_list);
    for i=1:ndata_group
        ndata=ndata+1;global_dataset_list{ndata}=dataset_list{i};
    end    
%     [mem_group ~]=read_result_table('mem',model_list,dataset_list,group);
    mem_group=zeros(nmodel,ndata_group);
    for i=1:nmodel
        model=model_list{i};
        cmd=sprintf('grep '' %s '' ../results/REPORTS/dataset_group%i/errors_group%i.txt | grep memory | wc -l',...
            model,group,group);
        [~,output]=system(cmd);nerr=str2double(output);
        n_mem_errors(i)=n_mem_errors(i)+nerr;
        for j=1:numel(dataset_list)
            cmd=sprintf('grep ppn scripts/%s/%s_%s.sh |cut -d= -f3|cut -d, -f1',...
                dataset_list{j},model,dataset_list{j});
            [~,output]=system(cmd);
            output(output=='''')='';
            mem_group(i,j)=2*str2double(output);
            fprintf(str);fprintf('%6.2f%%',100*iexp/nexp);iexp=iexp+1;
        end
    end
    mem=[mem mem_group];
end
fprintf('\n')

% TEX table with memory consumptions
nf='../results/REPORTS/global/table_memory.tex';f=open_file(nf,'w');
fprintf(f,'\\begin{tabular}{|c|c|c|c|c|c|c|c|c||c|c|}\n');fprintf(f,'\\hline\n');
fprintf(f,'& & \\multicolumn{7}{c||}{\\#datasets for each memory size} & & \\\\ \\hline\n');
fprintf(f,'%4s & %20s & %5s & %5s & %5s & %5s & %5s & %5s & %5s & %10s & %10s \\\\ \\hline \\hline \n',...
    'Pos.','Model','2GB','4GB','8GB','16GB','32GB','64GB','128GB','Mem.','\%ME');
u=sum(mem,2);[~,ind]=sort(u,'descend');avg_mem=mean(mem,2);
val_mem=[2 4 8 16 32 64 128];nval_mem=numel(val_mem);data=zeros(nmodel,nval_mem);
for i=1:nmodel
    j=ind(i);mem2=mem(j,:);
    fprintf(f,'%4i & %20s ',i,model_list2{j});
    for k=1:nval_mem
        t=sum(mem2==val_mem(k));data(j,k)=t;
        if t==0
            fprintf(f,'& %5s ','');
        else
            fprintf(f,'& %5i ',t);
        end
    end
    fprintf(f,'& %10.1f ',avg_mem(j));
    if n_mem_errors(j)>0
        fprintf(f,'& %10.2f \\\\ \\hline \n',100*n_mem_errors(j)/ndata);
    else
        fprintf(f,'& %10s \\\\ \\hline \n','');
    end
end
fprintf(f,'\\end{tabular}\n');
fclose(f);


% memory of the best regressors against the product np*ni
npni=zeros(1,ndata);
for i=1:ndata
    data=global_dataset_list{i};nf=sprintf('../data/%s/%s.txt',data,data);
    f=open_file(nf,'r');
    fscanf(f,'%s',1);np=fscanf(f,'%i',1);
    fscanf(f,'%s',1);ni=fscanf(f,'%i',1);
    npni(i)=np*ni;fclose(f);
end
[~,i]=sort(npni);clf;
i_cubist=find(strcmp(model_list,'cubist'));semilogx(npni(i),log2(mem(i_cubist,i)),'b.-');hold on;
i_M5=find(strcmp(model_list,'M5'));semilogx(npni(i),log2(mem(i_M5,i)),'r.-')
i_nnls=find(strcmp(model_list,'dlkeras'));semilogx(npni(i),log2(mem(i_nnls,i)),'g.-')
i_randomGLM=find(strcmp(model_list,'randomGLM'));semilogx(npni(i),log2(mem(i_randomGLM,i)),'c.-')
legend({'cubist','M5','dlkeras','rndGLM'},'location','northwest','fontsize',18)
xlabel('#patterns * #inputs','fontsize',19);ylabel('Memory (GB)','fontsize',18);
axis([5e2 7e7 0.5 7.5])
set(gca,'yticklabel',{'2','4','8','16','32','64','128'})
print('-depsc','../results/REPORTS/global/memory_best_regressors.eps')