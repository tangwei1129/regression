require(earth,quietly=TRUE)
# versión descartando entradas constantes
# lm.model=lm(output~.,pr);indices=which(is.finite(lm.model$coefficients[-1]))
# earth.model=earth(pr[,-c(indices,i_output)],pr[,i_output],nprune=val_par1,Scale.y=F)
# sr=predict(earth.model,pv[,-c(indices,i_output)])
earth.model=earth(pr[,-i_output],pr[,i_output],nprune=val_par1)
sr=predict(earth.model,pv[,-i_output])
rm(earth.model)
