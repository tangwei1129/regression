require(spls,quietly=T)
lm.model=lm(output~.,pr);indices=which(is.finite(lm.model$coefficients[-1]))
tx=as.matrix(pr[,indices]);ty=as.matrix(pr[,i_output]);npred=ncol(tx)
if(val_par1>npred) val_par1=npred
spls.model=spls(tx,ty,K=val_par1,eta=val_par2)
rm(tx,ty)
tx=as.matrix(pv[,indices]);sr=predict(spls.model,tx,type='fit')
rm(tx,spls.model)

