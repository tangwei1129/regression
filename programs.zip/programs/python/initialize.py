nargs=len(argv)

#for i in range(nargs):
	#print(argv[i])
#exit(0)

j=1
basedir=argv[j];j=j+1
resultsdir=argv[j];j=j+1
dataset=argv[j];j=j+1
model=argv[j];j=j+1
f_res=resultsdir+'/results_'+model+'_python_'+dataset+'.dat'
try:
	fr=open(f_res,'w')
except IOError:
	print 'error opening %s' % f_res; exit

f_plot=resultsdir+'/plot_'+model+'_'+dataset+'.dat';
try:
	fg=open(f_plot,'w')
except IOError:
	print 'error opening %s' % f_plot; exit

interactive=int(argv[j]);j=j+1
npar=int(argv[j]); j=j+1
if npar<0 and npar>3:
	print('npar = %i != 0,1,2,3', npar);exit
if npar>0:
	par1_name=argv[j];j=j+1
	n_val1=int(argv[j]);j=j+1
	val1=zeros(n_val1)
	for i in range(n_val1):
		val1[i]=float(argv[j]);j=j+1
	if npar>1:
		par2_name=argv[j];j=j+1 
		n_val2=int(argv[j]);j=j+1
		val2=zeros(n_val2)
		for i in range(n_val2):
			val2[i]=float(argv[j]);j=j+1
		if npar>2:
			par3_name=argv[j];j=j+1 
			n_val3=int(argv[j]);j=j+1
			val3=zeros(n_val3)
			for i in range(n_val3):
				val3[i]=float(argv[j]);j=j+1

# show arguments
# print('basedir= %s dataset= %s clasif= %s npar= %i\n' % basedir, dataset, clasif, npar)
# print('f_res= %s\n' % f_res)
# if(npar):
#   print('par= %s n_val= %i: ' % par1_name, n_val1)
#   for i in range(n_val1):
# 		print('%g ' % val1[i])
#   print('\n')
#   if 2==npar:
# 		print('par= %s n_val= %i: ' % par2_name, n_val2)
# 	for i in range(n_val2):
# 	  print('%g ' % val2[i])
# 	print('\n')
# print('interactivo= %i\n' % interactivo)


# reads data set information
nf=basedir+'/data/'+dataset+'/'+dataset+'.txt';
try:
	f=open(nf)
	l=f.readline();t=l.rsplit();np=int(t[1])
	l=f.readline();t=l.rsplit();ni=int(t[1])
	f.close()
except IOError:
	print('error opening %s' % nf);exit

if np<=10000:
	ntrials=500
else:
	ntrials=10

#data reading
f_patterns=basedir+'/data/'+dataset+'/'+dataset+'_R.dat';x=zeros([np,ni+1])
try:
	f=open(f_patterns)
	f.readline()
	for i in range(np):
		l=f.readline();t=l.rsplit()
		for j in range(ni+1):
			x[i,j]=float(t[j+1])
		x[i,ni]=float(t[-1])		
	f.close()
except IOError:
	print('error opening %s' % f_patterns);exit

i_output=ni
train_perc=70;valid_perc=20
npr=int(train_perc*np/100)
npv=int(valid_perc*np/100)
npt=np-npr-npv

#reading partitions
f_partitions=basedir+'/data/'+dataset+'/'+dataset+'_partitions.dat'
xr=zeros([ntrials,npr],'int');xv=zeros([ntrials,npv],'int');xt=zeros([ntrials,npt],'int')
try:
	f=open(f_partitions);
	for i in range(ntrials):
		l=f.readline();t=l.rsplit();
		xr[i,:]=t[:npr];
		fin=npr+npv;xv[i,:]=t[npr:fin];
		xt[i,:]=t[fin:];
	f.close()
	xr=xr-1;xv=xv-1;xt=xt-1
except IOError:
	print('error opening %s' % f_partitions);exit
