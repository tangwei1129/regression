require(caret,quietly=T)
pcaNNet.model=pcaNNet(output ~ ., data=pr,size=val_par1,decay=val_par2,trace=FALSE,MaxNWts=10000,linout=T)
sr=predict(pcaNNet.model,pv)
rm(pcaNNet.model)
