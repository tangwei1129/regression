require(RSNNS,quietly=T)
mlpWeightDecayML.model=mlp(pr[,-i_output],pr[,i_output],size=c(val_par1,val_par2,val_par3),learnFunc='BackpropWeightDecay', updateFuncParams=val_par4,outputActFunc='Act_Identity')
sr=predict(mlpWeightDecayML.model,pv[,-i_output])
rm(mlpWeightDecayML.model)