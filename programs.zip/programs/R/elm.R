require(elmNN,quietly=TRUE)
if(val_par2==1) {
	af='sin'
} else {
	if(val_par2==2) {
		af='radbas'
	} else {
		if(val_par2==3) {
			af='purelin'
		} else {
			af='tansig'
		}
	}
}
elm.model=elmtrain.formula(output ~ . ,data=pr,nhid=val_par1,actfun=af)
sr=predict(elm.model,pv)
rm(elm.model)
