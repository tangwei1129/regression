clear all
clc

dataset={'daily_demand','slump','slump_comp','slump_flow','gps_trajectory','servo','automobile','com_hd','csm1415','stock_abs','stock_annual','stock_excess','stock_rel','stock_systematic','stock_total','yacht_hydro','student_mat','auto_mpg','housing','facebook_metrics','forestfires','stock_exchange','student_por','bike_day','energy_cool','energy_heat','compress_stren','park_speech','geo_lat','geo_long','geo_music_lat','geo_music_long','air_quality_CO','air_quality_NMHC','air_quality_NO2','air_quality_NOx','air_quality_O3','airfoil','com_crime','gas_dynamic_CO','gas_dynamic_methane','com_crime_unnorm','SML2010','park_motor_UPDRS','park_total_UPDRS','combined_cycle','cond_turbine','UJ_lat','UJ_long','bike_hour','appliances_energy','pm25_beijing_dongsihuan','pm25_shenyang_us_post','pm25_guangzhou_5th_middle_school','pm25_shanghai_jingan','pm25_shenyang_taiyuanji','pm25_chengdu_caotangsi','pm25_shanghai_xuhui','pm25_chengdu_shahepu','pm25_shenyang_xiaoheyan','pm25_beijing_nongzhanguan','pm25_beijing_dongsi','pm25_chengdu_us_post','pm25_shanghai_us_post','pm25_guangzhou_city_station','pm25_guangzhou_us_post','online_news','facebook_comment','beijing_pm25','physico_protein','pm25_beijing_us_post','KEGG_relation','CT_slices','blog_feedback','cuff_less','KEGG_reaction','video_transcode','dynamic_features','3Droad','year_prediction','buzz_twitter','greenhouse_net','household_consume'};
ndata=numel(dataset);

% % best Psi function on rlm
% funcion=zeros(1,ndata);
% for i=1:ndata
%     d=dataset{i};
%     nf=sprintf('../results/%s/rlm_R/results_rlm_R_%s.dat',d,d);
%     command=sprintf('grep best_psi %s | cut -d'' '' -f2',nf);
%     [~,t]=system(command);funcion(i)=str2double(t);
% end
% fprintf('Huber: %.2f%% Hampel= %.2f%% Tukey= %.2f%%\n',100*sum(funcion==1)/ndata,...
%     100*sum(funcion==2)/ndata,100*sum(funcion==3)/ndata);

% %lambda1 and lambda2 in penalized
% lambda1=zeros(1,ndata);lambda2=zeros(1,ndata);
% for i=1:ndata
%     d=dataset{i};
%     nf=sprintf('../results/%s/penalized_R/results_penalized_R_%s.dat',d,d);
%     command=sprintf('grep best_lambda1 %s | cut -d'' '' -f2',nf);
%     [~,t]=system(command);lambda1(i)=str2double(t);
%     command=sprintf('grep best_lambda1 %s | cut -d'' '' -f4',nf);
%     [~,t]=system(command);lambda2(i)=str2double(t);
% end

% %lambda and fraction in enet
% lambda=zeros(1,ndata);fraction=zeros(1,ndata);
% for i=1:ndata
%     d=dataset{i};
%     nf=sprintf('../results/%s/enet_R/results_enet_R_%s.dat',d,d);
%     command=sprintf('grep best_lambda %s | cut -d'' '' -f2',nf);
%     [~,t]=system(command);lambda(i)=str2double(t);
%     command=sprintf('grep best_lambda %s | cut -d'' '' -f4',nf);
%     [~,t]=system(command);fraction(i)=str2double(t);
% end

% %alpha and lambda in glmnet
% alpha=zeros(1,ndata);lambda=zeros(1,ndata);
% for i=1:ndata
%     d=dataset{i};
%     nf=sprintf('../results/%s/glmnet_R/results_glmnet_R_%s.dat',d,d);
%     command=sprintf('grep best_alpha %s | cut -d'' '' -f2',nf);
%     [~,t]=system(command);alpha(i)=str2double(t);
%     command=sprintf('grep best_lambda %s | cut -d'' '' -f4',nf);
%     [~,t]=system(command);lambda(i)=str2double(t);
% end

% %selec in gam
% selec=zeros(1,ndata);
% for i=1:ndata
%     d=dataset{i};
%     nf=sprintf('../results/%s/gam_R/results_gam_R_%s.dat',d,d);
%     command=sprintf('grep best_selec %s | cut -d'' '' -f2',nf);
%     [~,t]=system(command);selec(i)=str2double(t);
% end

% %mstop in gamboost
% mstop=zeros(1,ndata);
% for i=1:ndata
%     d=dataset{i};
%     nf=sprintf('../results/%s/gamboost_R/results_gamboost_R_%s.dat',d,d);
%     command=sprintf('grep best_mstop %s | cut -d'' '' -f2',nf);
%     [~,t]=system(command);mstop(i)=str2double(t);
% end

% %nprune in earth
% nprune=zeros(1,ndata);
% for i=1:ndata
%     d=dataset{i};
%     nf=sprintf('../results/%s/earth_R/results_earth_R_%s.dat',d,d);
%     command=sprintf('grep best_nprune %s | cut -d'' '' -f2',nf);
%     [~,t]=system(command);nprune(i)=str2double(t);
% end

% %nterms in ppr
% nterms=zeros(1,ndata);
% for i=1:ndata
%     d=dataset{i};
%     nf=sprintf('../results/%s/ppr_R/results_ppr_R_%s.dat',d,d);
%     command=sprintf('grep best_nterms %s | cut -d'' '' -f2',nf);
%     [~,t]=system(command);nterms(i)=str2double(t);
% end
% 
% %phi and lambda in relaxo
% phi=zeros(1,ndata);lambda=zeros(1,ndata);
% for i=1:ndata
%     d=dataset{i};
%     nf=sprintf('../results/%s/relaxo_R/results_relaxo_R_%s.dat',d,d);
%     command=sprintf('grep best_phi %s | cut -d'' '' -f2',nf);
%     [~,t]=system(command);phi(i)=str2double(t);
%     command=sprintf('grep best_lambda %s | cut -d'' '' -f4',nf);
%     [~,t]=system(command);lambda(i)=str2double(t);
% end
% 
% %fraction in lars
% fraction=zeros(1,ndata);
% for i=1:ndata
%     d=dataset{i};
%     nf=sprintf('../results/%s/lars_R/results_lars_R_%s.dat',d,d);
%     command=sprintf('grep best_fraction %s | cut -d'' '' -f2',nf);
%     [~,t]=system(command);fraction(i)=str2double(t);
% end
% 
% %lambda in ridge
% lambda=zeros(1,ndata);
% for i=1:ndata
%     d=dataset{i};
%     nf=sprintf('../results/%s/ridge_R/results_ridge_R_%s.dat',d,d);
%     command=sprintf('grep best_lambda %s | cut -d'' '' -f2',nf);
%     [~,t]=system(command);lambda(i)=str2double(t);
% end
% 
% %vars in spikeslab
% vars=zeros(1,ndata);
% for i=1:ndata
%     d=dataset{i};
%     nf=sprintf('../results/%s/spikeslab_R/results_spikeslab_R_%s.dat',d,d);
%     command=sprintf('grep best_vars %s | cut -d'' '' -f2',nf);
%     [~,t]=system(command);vars(i)=str2double(t);
% end
% % t=unique(vars);
% % for i=1:numel(t)
% %     j=t(i);fprintf('%i: %i\n',j,sum(vars==j));
% % end
% 
% %lambda in foba
% lambda=zeros(1,ndata);
% for i=1:ndata
%     d=dataset{i};
%     nf=sprintf('../results/%s/foba_R/results_foba_R_%s.dat',d,d);
%     command=sprintf('grep best_lambda %s | cut -d'' '' -f2',nf);
%     [~,t]=system(command);lambda(i)=str2double(t);
% end
% 
% %neurons in brnn
% neurons=zeros(1,ndata);
% for i=1:ndata
%     d=dataset{i};
%     nf=sprintf('../results/%s/brnn_R/results_brnn_R_%s.dat',d,d);
%     command=sprintf('grep best_neurons %s | cut -d'' '' -f2',nf);
%     [~,t]=system(command);neurons(i)=str2double(t);
% end
% 
% %lambda in rqlasso
% lambda=zeros(1,ndata);
% for i=1:ndata
%     d=dataset{i};
%     nf=sprintf('../results/%s/rqlasso_R/results_rqlasso_R_%s.dat',d,d);
%     command=sprintf('grep best_lambda %s | cut -d'' '' -f2',nf);
%     [~,t]=system(command);lambda(i)=str2double(t);
% end
% 
% %lambda in rqnc
% lambda=zeros(1,ndata);
% for i=1:ndata
%     d=dataset{i};
%     nf=sprintf('../results/%s/rqnc_R/results_rqnc_R_%s.dat',d,d);
%     command=sprintf('grep best_lambda %s | cut -d'' '' -f2',nf);
%     [~,t]=system(command);lambda(i)=str2double(t);
% end
% 
% %neurons in qrnn
% neurons=zeros(1,ndata);
% for i=1:ndata
%     d=dataset{i};
%     nf=sprintf('../results/%s/qrnn_R/results_qrnn_R_%s.dat',d,d);
%     command=sprintf('grep best_n.hidden %s | cut -d'' '' -f2',nf);
%     [~,t]=system(command);neurons(i)=str2double(t);
% end
% 
% %neighbors in kknn
% neighbors=zeros(1,ndata);
% for i=1:ndata
%     d=dataset{i};
%     nf=sprintf('../results/%s/kknn_R/results_kknn_R_%s.dat',d,d);
%     command=sprintf('grep best_kmax %s | cut -d'' '' -f2',nf);
%     [~,t]=system(command);neighbors(i)=str2double(t);
% end
% 
% %maxinter in nodeHarvest
% maxinter=zeros(1,ndata);
% for i=1:ndata
%     d=dataset{i};
%     nf=sprintf('../results/%s/nodeHarvest_R/results_nodeHarvest_R_%s.dat',d,d);
%     command=sprintf('grep best_maxinter %s | cut -d'' '' -f2',nf);
%     [~,t]=system(command);maxinter(i)=str2double(t);
% end
% 
% %maxdepth in ctree2
% maxdepth=zeros(1,ndata);
% for i=1:ndata
%     d=dataset{i};
%     nf=sprintf('../results/%s/ctree2_R/results_ctree2_R_%s.dat',d,d);
%     command=sprintf('grep best_maxdepth %s | cut -d'' '' -f2',nf);
%     [~,t]=system(command);maxdepth(i)=str2double(t);
% end
% 
% %cutoff in partDSA
% cutoff=zeros(1,ndata);
% for i=1:ndata
%     d=dataset{i};
%     nf=sprintf('../results/%s/partDSA_R/results_partDSA_R_%s.dat',d,d);
%     command=sprintf('grep best_cut %s | cut -d'' '' -f2',nf);
%     [~,t]=system(command);cutoff(i)=str2double(t);
% end
% 
% %neighbors and committees in cubist
% neighbors=zeros(1,ndata);committees=zeros(1,ndata);
% for i=1:ndata
%     d=dataset{i};
%     nf=sprintf('../results/%s/cubist_R/results_cubist_R_%s.dat',d,d);
%     command=sprintf('grep best_neighbors %s | cut -d'' '' -f2',nf);
%     [~,t]=system(command);neighbors(i)=str2double(t);
%     command=sprintf('grep best_neighbors %s | cut -d'' '' -f4',nf);
%     [~,t]=system(command);committees(i)=str2double(t);
% end
% 
% %r.a in SBC
% ra=zeros(1,ndata);
% for i=1:ndata
%     d=dataset{i};
%     nf=sprintf('../results/%s/SBC_R/results_SBC_R_%s.dat',d,d);
%     command=sprintf('grep best_r.a %s | cut -d'' '' -f2',nf);
%     [~,t]=system(command);ra(i)=str2double(t);
% end
% 
% %mtry in rf
% mtry=zeros(1,ndata);
% for i=1:ndata
%     d=dataset{i};
%     nf=sprintf('../results/%s/rf_R/results_rf_R_%s.dat',d,d);
%     command=sprintf('grep best_mtry %s | cut -d'' '' -f2',nf);
%     [~,t]=system(command);mtry(i)=str2double(t);
%     command=sprintf('grep ''#mtry'' %s',nf);
%     [~,output]=system(command);
%     fprintf('%s: %s',d,output);
% end
% 
% %coefReg in RRF
% coefReg=zeros(1,ndata);
% for i=1:ndata
%     d=dataset{i};
%     nf=sprintf('../results/%s/RRF_R/results_RRF_R_%s.dat',d,d);
%     command=sprintf('grep best_coefReg %s | cut -d'' '' -f4',nf);
%     [~,t]=system(command);coefReg(i)=str2double(t);
% end
% 
% %numRandomCuts in extraTrees
% numRandomCuts=zeros(1,ndata);
% for i=1:ndata
%     d=dataset{i};
%     nf=sprintf('../results/%s/extraTrees_R/results_extraTrees_R_%s.dat',d,d);
%     command=sprintf('grep best_numRandomCuts %s | cut -d'' '' -f4',nf);
%     [~,t]=system(command);numRandomCuts(i)=str2double(t);
% end
% 
% %nprune in bagEarth
% nprune=zeros(1,ndata);
% for i=1:ndata
%     d=dataset{i};
%     nf=sprintf('../results/%s/bagEarth_R/results_bagEarth_R_%s.dat',d,d);
%     command=sprintf('grep best_nprune %s | cut -d'' '' -f2',nf);
%     [~,t]=system(command);nprune(i)=str2double(t);
% end
% 
% %maxInteractionOrder in randomGLM
% maxInteractionOrder=zeros(1,ndata);
% for i=1:ndata
%     d=dataset{i};
%     nf=sprintf('../results/%s/randomGLM_R/results_randomGLM_R_%s.dat',d,d);
%     command=sprintf('grep best_maxInteractionOrder %s | cut -d'' '' -f2',nf);
%     [~,t]=system(command);maxInteractionOrder(i)=str2double(t);
% end
% 
% %maxdepth in bstTree
% maxdepth=zeros(1,ndata);
% for i=1:ndata
%     d=dataset{i};
%     nf=sprintf('../results/%s/bstTree_R/results_bstTree_R_%s.dat',d,d);
%     command=sprintf('grep best_maxdepth %s | cut -d'' '' -f4',nf);
%     [~,t]=system(command);maxdepth(i)=str2double(t);
% end
% 
% %interaction_depth in gbm
% interaction_depth=zeros(1,ndata);n_trees=zeros(1,ndata);
% for i=1:ndata
%     d=dataset{i};
%     nf=sprintf('../results/%s/gbm_R/results_gbm_R_%s.dat',d,d);
%     command=sprintf('grep best_interaction.depth %s | cut -d'' '' -f2',nf);
%     [~,t]=system(command);interaction_depth(i)=str2double(t);
%     command=sprintf('grep best_n.trees %s | cut -d'' '' -f4',nf);
%     [~,t]=system(command);n_trees(i)=str2double(t);
% end
% 
% %maxdepth in blackboost
% maxdepth=zeros(1,ndata);
% for i=1:ndata
%     d=dataset{i};
%     nf=sprintf('../results/%s/blackboost_R/results_blackboost_R_%s.dat',d,d);
%     command=sprintf('grep best_maxdepth %s | cut -d'' '' -f2',nf);
%     [~,t]=system(command);maxdepth(i)=str2double(t);
% end
% 
% %max_depth, nrounds and eta in xgbTree
% max_depth=zeros(1,ndata);nrounds=zeros(1,ndata);eta=zeros(1,ndata);
% for i=1:ndata
%     d=dataset{i};
%     nf=sprintf('../results/%s/xgbTree_R/results_xgbTree_R_%s.dat',d,d);
%     command=sprintf('grep best_max_depth %s | cut -d'' '' -f2',nf);
%     [~,t]=system(command);max_depth(i)=str2double(t);
%     command=sprintf('grep best_nrounds %s | cut -d'' '' -f4',nf);
%     [~,t]=system(command);nrounds(i)=str2double(t);
%     command=sprintf('grep best_eta %s | cut -d'' '' -f6',nf);
%     [~,t]=system(command);eta(i)=str2double(t);
% end
% 
% %lambda in xgbLinear
% lambda=zeros(1,ndata);
% for i=1:ndata
%     d=dataset{i};
%     nf=sprintf('../results/%s/xgbLinear_R/results_xgbLinear_R_%s.dat',d,d);
%     command=sprintf('grep best_lambda %s | cut -d'' '' -f2',nf);
%     [~,t]=system(command);lambda(i)=str2double(t);
% end
% 
% %k in spls
% k=zeros(1,ndata);eta=zeros(1,ndata);
% for i=1:ndata
%     d=dataset{i};
%     nf=sprintf('../results/%s/spls_R/results_spls_R_%s.dat',d,d);
%     command=sprintf('grep best_K %s | cut -d'' '' -f2',nf);
%     [~,t]=system(command);k(i)=str2double(t);
%     command=sprintf('grep best_eta %s | cut -d'' '' -f4',nf);
%     [~,t]=system(command);eta(i)=str2double(t);
% end
% 
% %nt and alpha.pvals.expli in plsRglm
% nt=zeros(1,ndata);alpha=zeros(1,ndata);
% for i=1:ndata
%     d=dataset{i};
%     nf=sprintf('../results/%s/plsRglm_R/results_plsRglm_R_%s.dat',d,d);
%     command=sprintf('grep best_nt %s | cut -d'' '' -f2',nf);
%     [~,t]=system(command);nt(i)=str2double(t);
%     command=sprintf('grep best_alpha.pvals.expli %s | cut -d'' '' -f4',nf);
%     [~,t]=system(command);alpha(i)=str2double(t);
% end
% 
% %ncomp in pcr
% ncomp=zeros(1,ndata);
% for i=1:ndata
%     d=dataset{i};
%     nf=sprintf('../results/%s/pcr_R/results_pcr_R_%s.dat',d,d);
%     command=sprintf('grep best_ncomp %s | cut -d'' '' -f2',nf);
%     [~,t]=system(command);ncomp(i)=str2double(t);
% end
% 
%n.comp in icr
ncomp=zeros(1,ndata);
for i=1:ndata
    d=dataset{i};
    nf=sprintf('../results/%s/icr_R/results_icr_R_%s.dat',d,d);
    command=sprintf('grep best_n.comp %s | cut -d'' '' -f2',nf);
    [~,t]=system(command);ncomp(i)=str2double(t);
end
% 
% %n.components in superpc
% ncomp=zeros(1,ndata);threshold=zeros(1,ndata);
% for i=1:ndata
%     d=dataset{i};
%     nf=sprintf('../results/%s/superpc_R/results_superpc_R_%s.dat',d,d);
%     command=sprintf('grep best_n.components %s | cut -d'' '' -f2',nf);
%     [~,t]=system(command);ncomp(i)=str2double(t);
%     command=sprintf('grep best_threshold %s | cut -d'' '' -f4',nf);
%     [~,t]=system(command);threshold(i)=str2double(t);
% end
% 
% %k and alpha in bartMachine
% k=zeros(1,ndata);alpha=zeros(1,ndata);
% for i=1:ndata
%     d=dataset{i};
%     nf=sprintf('../results/%s/bartMachine_R/results_bartMachine_R_%s.dat',d,d);
%     command=sprintf('grep best_k %s | cut -d'' '' -f4',nf);
%     [~,t]=system(command);k(i)=str2double(t);
%     command=sprintf('grep best_alpha %s | cut -d'' '' -f6',nf);
%     [~,t]=system(command);alpha(i)=str2double(t);
% end
% 
% %size in avNNet
% size=zeros(1,ndata);
% for i=1:ndata
%     d=dataset{i};
%     nf=sprintf('../results/%s/avNNet_R/results_avNNet_R_%s.dat',d,d);
%     command=sprintf('grep best_size %s | cut -d'' '' -f2',nf);
%     [~,t]=system(command);size(i)=str2double(t);
% end
% 
% %size in rbf
% size1=zeros(1,ndata);
% for i=1:ndata
%     d=dataset{i};
%     nf=sprintf('../results/%s/rbf_R/results_rbf_R_%s.dat',d,d);
%     command=sprintf('grep best_size %s | cut -d'' '' -f2',nf);
%     [~,t]=system(command);size1(i)=str2double(t);
% end
% 
% %spread in grnn
% spread1=zeros(1,ndata);
% for i=1:ndata
%     d=dataset{i};
%     nf=sprintf('../results/%s/grnn_matlab/results_grnn_matlab_%s.dat',d,d);
%     command=sprintf('grep spread_mellor %s | cut -d'' '' -f2',nf);
%     [~,t]=system(command);spread1(i)=str2double(t);
% end
% 
% %nhid in elm
% nhid=zeros(1,ndata);actfun=zeros(1,ndata);
% for i=1:ndata
%     d=dataset{i};
%     nf=sprintf('../results/%s/elm_R/results_elm_R_%s.dat',d,d);
%     command=sprintf('grep best_nhid %s | cut -d'' '' -f2',nf);
%     [~,t]=system(command);nhid(i)=str2double(t);
%     command=sprintf('grep best_actfun %s | cut -d'' '' -f4',nf);
%     [~,t]=system(command);actfun(i)=str2double(t);
% end
% 
% %size in pcaNNet
% size1=zeros(1,ndata);
% for i=1:ndata
%     d=dataset{i};
%     nf=sprintf('../results/%s/pcaNNet_R/results_pcaNNet_R_%s.dat',d,d);
%     command=sprintf('grep best_size %s | cut -d'' '' -f2',nf);
%     [~,t]=system(command);size1(i)=str2double(t);
% end
% 
% %xdim, ydim and xweight in bdk
% xdim=zeros(1,ndata);ydim=zeros(1,ndata);xweight=zeros(1,ndata);
% for i=1:ndata
%     d=dataset{i};
%     nf=sprintf('../results/%s/bdk_R/results_bdk_R_%s.dat',d,d);
%     command=sprintf('grep best_xdim %s | cut -d'' '' -f2',nf);
%     [~,t]=system(command);xdim(i)=str2double(t);
%     command=sprintf('grep best_ydim %s | cut -d'' '' -f4',nf);
%     [~,t]=system(command);ydim(i)=str2double(t);
%     command=sprintf('grep best_xweight %s | cut -d'' '' -f6',nf);
%     [~,t]=system(command);xweight(i)=str2double(t);
% end
% 
% %C and sigma in svmRadial
% C=zeros(1,ndata);sigma=zeros(1,ndata);
% for i=1:ndata
%     d=dataset{i};
%     nf=sprintf('../results/%s/svmRadial_R/results_svmRadial_R_%s.dat',d,d);
%     command=sprintf('grep best_sigma %s | cut -d'' '' -f2',nf);
%     [~,t]=system(command);sigma(i)=str2double(t);
%     command=sprintf('grep best_tau %s | cut -d'' '' -f4',nf);
%     [~,t]=system(command);C(i)=str2double(t);
% end
% %ncomp in pls, simpls, kernelpls and widekernelpls
% ncomp=zeros(1,ndata);model='widekernelpls';
% for i=1:ndata
%     d=dataset{i};
%     nf=sprintf('../results/%s/%s_R/results_%s_R_%s.dat',d,model,model,d);
%     command=sprintf('grep best_ncomp %s | cut -d'' '' -f2',nf);
%     [~,output]=system(command);ncomp(i)=str2double(output);
%     command=sprintf('grep ''#ncomp'' %s',nf);
%     [~,output]=system(command);
% %     fprintf('%s: %s',d,output);
% end
% %alpha in evtree
% for i=1:ndata
%     d=dataset{i};
%     nf=sprintf('../results/%s/evtree_R/results_evtree_R_%s.dat',d,d);
%     command=sprintf('grep ''#alpha'' %s',nf);
%     [~,output]=system(command);
%     fprintf('%s: %s',d,output);
% end
% %size and decay in mlpWeightDecay
% for i=1:ndata
%     d=dataset{i};
%     nf=sprintf('../results/%s/mlpWeightDecay_R/results_mlpWeightDecay_R_%s.dat',d,d);
%     command=sprintf('grep ''#decay'' %s',nf);
%     [~,output]=system(command);
%     fprintf('%s: %s',d,output);
% end
% %layer1,2,3 and decay in mlpWeightDecayML
% for i=1:ndata
%     d=dataset{i};
%     nf=sprintf('../results/%s/mlpWeightDecayML_R/results_mlpWeightDecayML_R_%s.dat',d,d);
%     command=sprintf('grep ''#decay'' %s',nf);
%     [~,output]=system(command);
%     fprintf('%s: %s',d,output);
% end
