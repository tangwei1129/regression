#!/bin/bash

basedir=$HOME/artigos/comparacion_regresores/experiments
datadir=$basedir/data
programsdir=$basedir/programs
resultsdir=$basedir/results
cd $programsdir
f_log=history.log
max_queued=300
wait_time=2

mkdir $programsdir/scripts $resultsdir $programsdir/outputs 2> /dev/null

# complete list of 84 datasets sorted by number of patterns (equivalently, by increasing size)
dataset_list=(daily_demand slump slump_comp slump_flow gps_trajectory servo automobile com_hd csm1415 stock_abs stock_annual stock_excess stock_rel stock_systematic stock_total yacht_hydro student_mat auto_mpg housing facebook_metrics forestfires stock_exchange student_por bike_day energy_cool energy_heat compress_stren park_speech geo_lat geo_long geo_music_lat geo_music_long air_quality_CO air_quality_NMHC air_quality_NO2 air_quality_NOx air_quality_O3 airfoil com_crime gas_dynamic_CO gas_dynamic_methane com_crime_unnorm SML2010 park_motor_UPDRS park_total_UPDRS combined_cycle cond_turbine UJ_lat UJ_long bike_hour appliances_energy pm25_beijing_dongsihuan pm25_shenyang_us_post pm25_guangzhou_5th_middle_school pm25_shanghai_jingan pm25_shenyang_taiyuanji pm25_chengdu_caotangsi pm25_shanghai_xuhui pm25_chengdu_shahepu pm25_shenyang_xiaoheyan pm25_beijing_nongzhanguan pm25_beijing_dongsi pm25_chengdu_us_post pm25_shanghai_us_post pm25_guangzhou_city_station pm25_guangzhou_us_post online_news facebook_comment beijing_pm25 physico_protein pm25_beijing_us_post KEGG_relation CT_slices blog_feedback cuff_less KEGG_reaction video_transcode dynamic_features 3Droad year_prediction buzz_twitter greenhouse_net household_consume)

# grupo 1: NPvR2v: 21 datasets: 
# dataset_list=(slump slump_flow gps_trajectory csm1415 stock_abs stock_annual stock_excess stock_rel stock_systematic stock_total student_mat forestfires student_por park_speech geo_lat geo_long geo_music_lat geo_music_long airfoil gas_drift com_crime_unnorm)
# grupo 2: NPvR2^: 23 datasets: 
# dataset_list=(daily_demand slump_comp servo automobile com_hd yacht_hydro auto_mpg housing facebook_metrics stock_exchange bike_day energy_cool energy_heat compress_stren air_quality_CO air_quality_NMHC air_quality_NO2 air_quality_NOx air_quality_O3 com_crime gas_dynamic_CO gas_dynamic_methane SML2010)
# grupo 3: NP^R2v: 33 datasets: 
# dataset_list=(park_motor_UPDRS park_total_UPDRS appliances_energy pm25_beijing_dongsihuan pm25_shenyang_us_post pm25_guangzhou_5th_middle_school pm25_shanghai_jingan pm25_shenyang_taiyuanji pm25_chengdu_caotangsi pm25_shanghai_xuhui pm25_chengdu_shahepu pm25_shenyang_xiaoheyan pm25_beijing_nongzhanguan pm25_beijing_dongsi pm25_chengdu_us_post pm25_shanghai_us_post pm25_guangzhou_city_station pm25_guangzhou_us_post online_news facebook_comment beijing_pm25 physico_protein pm25_beijing_us_post KEGG_relation blog_feedback cuff_less video_transcode dynamic_features 3Droad year_prediction buzz_twitter greenhouse_net household_consume)
# grupo 4: NP^R2^: 7 datasets: 
# dataset_list=(combined_cycle cond_turbine UJ_lat UJ_long bike_hour CT_slices KEGG_reaction)

# dataset_list=()

n_dataset=${#dataset_list[@]}
# echo 'n_dataset=' $n_dataset


# complete list of 78 models sorted by increasing times in the smallest dataset (daily_demand)
model_list=(elm_kernel rvmRadial glmboost nnls spikeslab rpart lm nodeHarvest plsRglm glm avNNet pcaNNet mlpWeightDecayML qrnn ctree2 relaxo SBC svmRadial penalized qrf icr xgbTree RRF bayesglm ppr rf dnn spls gam kknn pcr svr rqnc krlsRadial kernelpls superpc lars glmnet simpls earth bag gamboost ridge gaussprLinear lasso bartMachine foba rlm evtree treebag gaussprRadial M5 gaussprPoly cforest glmStepAIC blackboost gbm grnn rbf randomGLM rqlasso extraTrees bstTree bdk bagEarth partDSA xgbLinear BstLm mlpWeightDecay elm dlkeras Boruta brnn enpls.fs cubist bstSm xgbTree qrnn)

# model_list=()

n_model=${#model_list[@]}
# echo 'n_model=' $n_model

increase_memory=0

n_exp=`expr $n_dataset \* $n_model`
index_exp=0
echo -n "" > $f_log

for model in ${model_list[*]}; do
	
	if [ $model == 'svr' ]; then
		implem='C';args_model='2 C 5 0.125 0.5 1 4 16 gamma 5 4 1 0.125 0.01562 0.00391' #for group 3
# 		args_model='2 C 20 0.0312 0.0625 0.125 0.25 0.5 1 2 4 8 16 32 64 128 256 512 1024 2048 4096 8192 16384 gamma  25  256 128 64 32 16 8 4 2 1 0.5 0.25 0.125 0.0625 0.03125 0.01562 0.00781 0.00391 0.00195  0.00098 0.00049 0.00024 0.00012 0.00006 0.00003 1.5e-5'
	elif [ $model == 'grnn' ]; then
		implem='matlab';args_model='1 spread 14 0.001 0.005 0.01 0.05 0.1 0.3 0.5 0.7 0.9 1 1.3 1.5 1.7 2'
	elif [ $model == 'elm_kernel' ]; then
		implem='matlab';args_model='2 C 5 0.125 0.5 1 4 16 gamma 5 4 1 0.125 0.01562 0.00391'  #for group 3
# 		args_model='2 C 20 16384 8192 4096 2048 1024 512 256 128 64 32 16 8 4 2 1 0.5 0.25 0.125 0.0625 0.0312 gamma 25 256 128 64 32 16 8 4 2 1 0.5 0.25 0.125 0.0625 0.03125 0.01562 0.00781 0.00391 0.00195  0.00098 0.00049 0.00024 0.00012 0.00006 0.00003 1.5e-5'
	elif [ $model == 'dlkeras' ]; then
		implem='python';args_model='3 nh1 2 50 75 nh2 2 50 75 nh3 2 50 75'
	else
		implem='R';args_model=''
	fi
	
	for dataset in  ${dataset_list[*]}; do
 		mkdir $programsdir/scripts/${dataset} $programsdir/outputs/${dataset} 2> /dev/null
		
# 		f_res=${resultsdir}/${dataset}/${model}_${implem}/results_${model}_${implem}_${dataset}.dat
# 		line=`grep final_mse $f_res 2> /dev/null`
# 		mse=`echo ${line} | cut -d' ' -f2 | tail -1`
# 		if [ ! -z $mse ]; then
# 			let index_exp=index_exp+1
# 			echo $model $dataset $index_exp '/' $n_exp 'already exists' >> $f_log
#  			continue
# 		fi
		
# 		job_list=`qstat -a|grep np|cut -d. -f1`; already_running=0
# 		job_name2=${model}_${dataset}; #	echo '<'$job_name2'>'
# 		for job in ${job_list[*]}; do
# 			line=`qstat -f $job | grep Job_Name`; #echo $line
# 			job_name=`echo ${line} | cut -d' ' -f3`; #	echo '<'$job_name'>'
# 			if [ "$job_name2"  == "$job_name" ]; then
# 				already_running=1
# 				break
# 			fi
# 		done		
# 		if [ ${already_running} == 1 ]; then
# 			let index_exp=index_exp+1
# 			echo $job_name2 $index_exp '/' $n_exp 'already running' >> $f_log
# 			continue
# 		fi

# 		mkdir -p ${resultsdir}/${dataset}/${model}_${implem}/copy 2> /dev/null
# 		mv ${resultsdir}/${dataset}/${model}_${implem}/*.* ${resultsdir}/${dataset}/${model}_${implem}/copy 2> /dev/null
# 		rm -f $programsdir/outputs/${dataset}/${model}_${implem}_${dataset}.* 2> /dev/null
			
 		file2=scripts/${dataset}/${model}_${dataset}.sh
 		ppn=`grep ppn $file2 2> /dev/null | cut -d= -f3|cut -d, -f1` 		
		if [ -z "${ppn}" ]; then
			ppn=1
		fi

		if [ $increase_memory == 1 ]; then
			let ppn=2*ppn
		fi

		while [ 1 ]; do
			n_queued=`qstat -a | grep np | wc -l`
			if [ "$n_queued" -lt "$max_queued" ]; then  
				break
			else
				sleep 10
			fi
		done

		echo "" >> $f_log
		echo "trying to submit" $dataset $model $implem $index_exp '/' $n_exp "to queue ..." >> $f_log
		
 		fich=$programsdir/scripts/${dataset}/${model}_${dataset}
 		 		 		
		sed s/DATASET/${dataset}/g job_regression.sh > ${fich}_1.sh
		sed s/MODEL/${model}/g ${fich}_1.sh > ${fich}_2.sh
		sed s/IMPLEM/${implem}/g ${fich}_2.sh > ${fich}_3.sh
		sed s/ARGS/"'${args_model}'"/g ${fich}_3.sh > ${fich}_4.sh
   		sed s/PPN/${ppn}/g ${fich}_4.sh > ${fich}.sh
		rm -f ${fich}_*.sh
		
		echo $index_exp '/' $n_exp
		let index_exp=index_exp+1
		
		continue
								
		# ver https://wiki.citius.usc.es/es:centro:servizos:hpc para ver las colas: np1,np2,np4,np8,np16,np32,np64
		qsub ${fich}.sh >> $f_log 2>&1
		
		error=$?
		while [ "0" != "$error" ]; do
			sleep 300
			qsub ${fich}.sh >> $f_log 2>&1
			error=$?
		done
		
		if [ "0" == "$error" ]; then   # o envío á cola tivo éxito
			let index_exp=index_exp+1
			echo $dataset $model $implem $index_exp '/' $n_exp "SUBMITTED TO QUEUE" >> $f_log
   			echo $dataset $model $implem $index_exp '/' $n_exp "SUBMITTED TO QUEUE"
			sleep $wait_time
		fi
		
#    		break
			
	done
  
#    	break
  
done

echo 'FINISHED!' >> $f_log
