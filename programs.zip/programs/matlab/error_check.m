function error_flag=error_check(model,implem,data)
    nf=sprintf('../results/%s/%s_%s/results_%s_%s_%s.dat',data,model,implem,model,implem,data);
    if ~exist(nf,'file')
        error_flag=1;return
    end
    cmd=sprintf('grep avg_rmse %s 2> /dev/null',nf);error_flag=0;
    [~, output]=system(cmd);
    if strcmp(output,'')
        error_flag=1;
    end
end