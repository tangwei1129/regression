require(Boruta,quietly=T)
require(randomForest,quietly=T)
sa=getSelectedAttributes(Boruta(output ~ ., data=pr))
if(length(sa)>2) {
	rf.model=randomForest(pr[,sa],pr[,i_output],mtry=val_par1,na.action =na.omit)
	sr=predict(rf.model,pv[,sa])
} else {
	rf.model=randomForest(pr[,-i_output],pr[,i_output],mtry=val_par1,na.action =na.omit)
	sr=predict(rf.model,pv[,-i_output])
}
rm(sa,rf.model)
