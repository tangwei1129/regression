#!/bin/bash

time=`expr 2 \* 60`

while [ 1 ]; do
	n_finished=`qstat -a|grep " C " | wc -l`
	echo -n `date` : ''
	if [ $n_finished != 0 ]; then
		finished=`qstat -a|grep " C "|cut -d. -f1 `
		for job in $finished; do
			name=`qstat -f $job | grep Job_Name|cut -d= -f2|cut -d' ' -f2`
			echo $job $name 'finished'
			echo -e '\a' > /dev/pts/2
		done
	else
		echo ''
	fi
	echo '------------------------------'
	sleep $time
done