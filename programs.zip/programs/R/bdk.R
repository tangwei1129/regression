require(kohonen,quietly=T)
tx=as.matrix(scale(pr[,-i_output]));tx[is.na(tx)]=0
ty=as.matrix(pr[,i_output]);ty[is.na(ty)]=0;
val_par1=max(3,val_par1);val1[i]=val_par1
val_par2=max(3,val_par2);val2[j]=val_par2
if(val_par1*val_par2>npr) { t=floor(sqrt(npr));val_par1=t;val1[i]=t;val_par2=t;val2[j]=t }
# print(val_par1);print(val_par2);print('---')
bdk.model=bdk(tx,ty,grid=somgrid(val_par1,val_par2,'hexagonal'),xweight=val_par3)
rm(tx,ty);tv=as.matrix(scale(pv[,-i_output]));tv[is.na(tv)]=0
sr=predict(bdk.model,newdata=tv)$prediction
rm(tv,bdk.model)
