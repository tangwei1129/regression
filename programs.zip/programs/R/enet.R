require(elasticnet,quietly=T)
lm.model=lm(output~.,pr);indices=which(is.na(lm.model$coefficients[-1]))
tx=as.matrix(pr[,-c(indices,i_output)]);ty=as.matrix(pr[,i_output])
enet.model=enet(tx,ty,lambda=val_par1)
rm(tx);tx=as.matrix(pv[,-c(indices,i_output)])
sr=predict(enet.model,tx,s=val_par2,type='fit',mode='fraction')$fit
rm(lm.model,tx,ty,indices,enet.model)
