function [r2 rmse mae]=read_trials(model,implem,dataset,ntrials)
nf=sprintf('../results/%s/%s_%s/trials_rmse_%s.dat',dataset,model,implem,model);
f=open_file(nf,'r');fscanf(f,'%s',4);
r2=zeros(1,ntrials);rmse=zeros(1,ntrials);mae=zeros(1,ntrials);
for i=1:ntrials
    fscanf(f,'%i',1);r2(i)=fscanf(f,'%g',1);
    rmse(i)=fscanf(f,'%g',1);mae(i)=fscanf(f,'%g',1);
end
fclose(f);    
end