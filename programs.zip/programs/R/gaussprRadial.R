require(kernlab,quietly=TRUE)
sink('/dev/null')
gaussprRadial.model=gausspr(output ~ . ,data=pr,kernel='rbfdot')
sr=predict(gaussprRadial.model,pv)
while(sink.number()>0) { sink(NULL) }
if(sd(sr)==0) stop('constant predicted output')
rm(gaussprRadial.model)

