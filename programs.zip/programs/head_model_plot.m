clear all
clc

addpath('matlab')

dataset_list={'daily_demand','slump','slump_comp','slump_flow','gps_trajectory','servo','automobile','com_hd','csm1415','stock_abs','stock_annual','stock_excess','stock_rel','stock_systematic','stock_total','yacht_hydro','student_mat','auto_mpg','housing','facebook_metrics','forestfires','stock_exchange','student_por','bike_day','energy_cool','energy_heat','compress_stren','park_speech','geo_lat','geo_long','geo_music_lat','geo_music_long','air_quality_CO','air_quality_NMHC','air_quality_NO2','air_quality_NOx','air_quality_O3','airfoil','com_crime','gas_drift','gas_dynamic_CO','gas_dynamic_methane','com_crime_unnorm','SML2010','park_motor_UPDRS','park_total_UPDRS','combined_cycle','cond_turbine','UJ_lat','UJ_long','bike_hour','appliances_energy','pm25_beijing_dongsihuan','pm25_shenyang_us_post','pm25_guangzhou_5th_middle_school','pm25_shanghai_jingan','pm25_shenyang_taiyuanji','pm25_chengdu_caotangsi','pm25_shanghai_xuhui','pm25_chengdu_shahepu','pm25_shenyang_xiaoheyan','pm25_beijing_nongzhanguan','pm25_beijing_dongsi','pm25_chengdu_us_post','pm25_shanghai_us_post','pm25_guangzhou_city_station','pm25_guangzhou_us_post','online_news','facebook_comment','beijing_pm25','physico_protein','pm25_beijing_us_post','KEGG_relation','CT_slices','blog_feedback','cuff_less','KEGG_reaction','video_transcode','dynamic_features','3Droad','year_prediction','buzz_twitter','greenhouse_net','household_consume'};
ndata=numel(dataset_list);
model_list={'elm_kernel','rvmRadial','glmboost','nnls','spikeslab','rpart','lm','nodeHarvest','plsRglm','glm','avNNet','pcaNNet','mlpWeightDecayML','qrnn','ctree2','relaxo','SBC','svmRadial','penalized','qrf','icr','xgbTree','RRF','bayesglm','ppr','rf','dnn','spls','gam','kknn','pcr','svr','rqnc','krlsRadial','kernelpls','superpc','lars','glmnet','simpls','earth','bag','gamboost','ridge','gaussprLinear','lasso','bartMachine','foba','rlm','evtree','treebag','gaussprRadial','M5','gaussprPoly','cforest','glmStepAIC','blackboost','gbm','grnn','rbf','randomGLM','rqlasso','extraTrees','bstTree','bdk','bagEarth','partDSA','xgbLinear','BstLm','mlpWeightDecay','elm','dlkeras','Boruta','brnn','enpls.fs','cubist','bstSm','xgbTree','qrnn'};
nmodel=numel(model_list);
nf='pp';f=open_file(nf,'w');x=zeros(10,2);
nspc=7;fprintf(repmat(' ',1,nspc));str=repmat('\b',1,nspc);iexp=1;nexp=nmodel*ndata;
for j=1:nmodel
    model=model_list{j};
    if strcmp(model,'svr')
        implem='C';
    elseif strcmp(model,'grnn') || strcmp(model,'elm_kernel')
        implem='matlab';
    elseif strcmp(model,'dlkeras')
        implem='python';
    else
        implem='R';
    end

    for i=1:ndata
        data=dataset_list{i};
        if error_check(model,implem,data)
            continue
        end
        nf=sprintf('../results/%s/%s_%s/plot_%s_%s.dat',data,model,implem,...
            model,data);
        if exist(nf,'file')
            x=load(nf);
            if std(x(1:10,2))==0
                fprintf(f,'%s %s\n',model,data);
            end
        end
        fprintf(str);fprintf('%6.2f%%',100*iexp/nexp);iexp=iexp+1;
    end
end
fprintf('\n')