from sys import *
import os
from time import clock
from numpy import *
from numpy.random import *

seed(0) # starts the random number generation for experiment reproducibility

execfile('initialize.py')

f_model=model+'.py'
if npar>0:
  if 1==npar:
	nexp=n_val1*ntrials+ntrials
  else:
	if 2==npar:
		nexp=n_val1*n_val2*ntrials+ntrials
	else:
		nexp=n_val1*n_val2*n_val3*ntrials+ntrials
else:
	nexp=ntrials

rmse=zeros(ntrials);best_rmse=inf;iexp=0
fr.write('running model %s dataset %s file= %s ...\n' % (model,dataset,f_patterns))

# parameter tuning
if 1==npar:
	fr.write('#%20s\t%20s\t%20s\n' % (par1_name,'rmse','best_rmse'));fr.flush()
	for i in range(n_val1):
		val_par1 = val1[i]
		for l in range(ntrials):  #pe=training patterns; pv=validation patterns; de=desired output for training patterns
			pr = x[xr[l,],]; pv = x[xv[l,],];sd=x[xv[l,],i_output]
			execfile(f_model)
			rmse[l]=sqrt(sum((sd-sr)**2)/npv)
			if 1==interactive:
				print '%5.1f%%\r' % (100.*iexp/nexp),;stdout.flush();iexp=iexp+1
		avg_rmse=mean(rmse)
		if avg_rmse<best_rmse:
			best_rmse=avg_rmse;best_val1=val1[i]
		fr.write('%20g\t%20g\t%20g\n' % (val1[i],avg_rmse,best_rmse));fr.flush()
	
	fr.write('#best_%s= %g best_rmse=%g\n' % (par1_name,best_val1,best_rmse))
	val_par1 = best_val1;

if 2==npar:
	fr.write('#%20s\t%20s\t%20s\t%20s\n' % (par1_name,par2_name,'rmse','best_rmse'));fr.flush()
	for i in range(n_val1):
		val_par1 = val1[i]
		for j in range(n_val2):
			val_par2 = val2[j]
			for l in range(ntrials):
				pr = x[xr[l,],]; pv = x[xv[l,],];sd=x[xv[l,],i_output]
				execfile(f_model)
				rmse[l]=sqrt(sum((sd-sr)**2)/npv)
				if 1==interactive:
					print '%5.1f%%\r' % (100.*iexp/nexp),;stdout.flush();iexp=iexp+1
			avg_rmse=mean(rmse)
			if avg_rmse < best_rmse:
				best_rmse=avg_rmse;best_val1=val1[i];best_val2=val2[j]
			fr.write('%20g\t%20g\t%20g\t%20g\n' % (val1[i],val2[j],avg_rmse,best_rmse))
	fr.write('#best_%s= %g best_%s= %g best_rmse=%g\n' % (par1_name,best_val1,par2_name,best_val2,best_rmse));fr.flush()
	val_par1 = best_val1; val_par2 = best_val2

if 3==npar:
	fr.write('#%20s\t%20s\t%20s\t%20s\t%20s\n' % (par1_name,par2_name,par3_name,'rmse','best_rmse'));fr.flush()
	for i in range(n_val1):
		val_par1 = val1[i]
		for j in range(n_val2):
			val_par2 = val2[j]
			for m in range(n_val3):
				val_par3=val3[j]
				for l in range(ntrials):
					pr = x[xr[l,],]; pv = x[xv[l,],];sd=x[xv[l,],i_output]
					execfile(f_model)
					rmse[l]=sqrt(sum((sd-sr)**2)/npv)
					if 1==interactive:
						print '%5.1f%%\r' % (100.*iexp/nexp),;stdout.flush();iexp=iexp+1
				avg_rmse=mean(rmse)
				if avg_rmse<best_rmse:
					best_rmse=avg_rmse;best_val1=val1[i];best_val2=val2[j];best_val3=val3[m]
				fr.write('%20g\t%20g\t%20g\t%20g\t%20g\n' % (val1[i],val2[j],val3[m],avg_rmse,best_rmse));fr.flush()
				
	fr.write('#best_%s= %g best_%s= %g best_rmse=%g\n' % (par1_name,best_val1,par2_name,best_val2,best_rmse))
	val_par1 = best_val1; val_par2 = best_val2; val_par3 = best_val3


def evaluate_test(sd,sr):
	n=len(sd);dif=sd-sr
	t=corrcoef(sd,sr);r2=t[0,1]**2
	rmse=sqrt(sum(dif**2)/n)
	mae=sum(abs(dif))/n
	return [r2,rmse,mae]

# test
r2=zeros(ntrials);mae=zeros(ntrials);rqrmse=zeros(ntrials)
nf=resultsdir+'/trials_'+model+'_'+dataset+'.dat'
try:
	ft=open(nf,'w')
except IOError:
	print('error opening %s' % nf);exit

fr.write('#test stage\n%20s\t%20s\n' % ('partition','rmse'));t0=clock()
for i in range(ntrials):
	ind=xr[i,];pr=x[ind,];ind=xt[i,];pv=x[ind,];sd=x[ind,i_output]
 	execfile(f_model)
	for j in range(npt):
		fg.write('%f %f\n' % (sd[j],sr[j]))		
	r2[i],rmse[i],mae[i]=evaluate_test(sd,sr);
	fr.write('#%20i\t%20.6f\n' % (i+1,rmse[i]));fr.flush()
	ft.write('%10i %10g %10g %10g\n' % (i,r2[i],rmse[i],mae[i]))
	if 1==interactive:
		print '%5.1f%%\r' % (100.*iexp/nexp),
		stdout.flush()
		iexp=iexp+1

avg_rmse=mean(rmse);elapsed_time=(clock()-t0)/ntrials;
fr.write('avg_r2= %g std= %g\n' % (mean(r2),std(r2)))
fr.write('avg_rmse= %g std= %g\n' % (mean(rmse),std(rmse)))
fr.write('avg_mae= %g std= %g\n' % (mean(mae),std(mae)))
fr.write('time= %g s.\n' % elapsed_time)
fr.close();fg.close()
ft.close()
f_res=resultsdir+'/'+model+'_'+dataset+'.csv';
try:
	fr=open(f_res,'w')
except IOError:
	print 'error opening %s' % f_res; exit
fr.write('%g %g %g %g\n' % (mean(r2),mean(rmse),mean(mae),elapsed_time));fr.close()