function [r2 rmse mae]=evaluate_test(sd,sr)
    t=corrcoef(sd,sr);r2=t(1,2)^2;
	n=numel(sd);dif=sd-sr;
    rmse=sqrt(sum(dif.^2)/n);mae=sum(abs(dif))/n;
end