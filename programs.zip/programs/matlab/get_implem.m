function implem=get_implem(model)
implem='R';
if strcmp(model,'svr')
    implem='C';
elseif strcmp(model,'grnn')
    implem='matlab';
elseif strcmp(model,'elm_kernel')
    implem='matlab';
elseif strcmp(model,'dlkeras')
    implem='python';
end
end