function [val error_flag]=read_result_table(nf,model_list,dataset_list)
nmodel=numel(model_list);ndata=numel(dataset_list);
error_flag=zeros(nmodel,ndata);val=zeros(nmodel,ndata);
f=open_file(nf,'r');fscanf(f,'%s ',ndata);
for i=1:nmodel
    fscanf(f,'%s ',1);
    for j=1:ndata
        val(i,j)=fscanf(f,'%f',1);
        if isnan(val(i,j))
            error_flag(i,j)=1;
        end
    end
end
fclose(f);
end