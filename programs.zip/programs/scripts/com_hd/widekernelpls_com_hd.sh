#!/bin/bash
# consultar taboa en: https://wiki.citius.usc.es/es:centro:servizos:hpc
#PBS -l nodes=1:ppn=1,walltime=48:00:00
#PBS -N widekernelpls_com_hd
#PBS -e outputs/com_hd/widekernelpls_R_com_hd.err
#PBS -o outputs/com_hd/widekernelpls_R_com_hd.out
#PBS -m n

basedir=$HOME/artigos/comparacion_regresores/experiments
datadir=$basedir/data
programsdir=$basedir/programs
resultsdir=$basedir/results
cd $programsdir

interactive=0
dataset=com_hd
model=widekernelpls
implem=R
args_model=''

export PATH=$PATH:.
export TERM=xterm

mkdir ${resultsdir}/${dataset} 2> /dev/null
mkdir ${programsdir}/scripts/${dataset} 2> /dev/null
mkdir ${programsdir}/outputs/${dataset} 2> /dev/null
mkdir ${resultsdir}/${dataset}/${model}_${implem} 2> /dev/null

f_res=${resultsdir}/${dataset}/${model}_${implem}/results_${model}_${implem}_${dataset}.dat; rm -f $f_res 2> /dev/null
f_log=${resultsdir}/${dataset}/${model}_${implem}/output_${model}_${implem}_${dataset}.dat; rm -f $f_log 2> /dev/null
f_mse=${resultsdir}/${dataset}/${model}_${implem}/mse_${model}_${dataset}.dat; rm -f $f_mse 2> /dev/null


## C ########################################################
if [ $implem = "C" ]; then
	cd C; make -B $model; $model $basedir $dataset $f_res $args_model $interactive
## MATLAB ###################################################
elif [ $implem = "matlab" ]; then
	module load matlab; cd matlab
	matlab -nodisplay -nosplash -nojvm -singleCompThread -r "regression $basedir $dataset $model $f_res $args_model $interactive" -logfile $f_log > /dev/null
## R ########################################################
elif [ $implem = "R" ]; then
	module load R; module load jdk;cd R; export R_LIBS_SITE="~/libR"
	R -q --no-save --slave --file="regression.R" --args $basedir $dataset $model $f_res $args_model $interactive $R_LIBS_SITE > $f_log 2>&1
## WEKA #####################################################
elif [ $implem = "weka" ]; then
	export WEKAINSTALL=$HOME/weka-3-6-8; export _JAVA_OPTIONS=-Xmx2097152K
	export CLASSPATH=$WEKAINSTALL/weka.jar:$WEKAINSTALL/libsvm.jar:$WEKAINSTALL/liblinear-1.7-with-deps.jar:.
	module load jdk; cd weka; javac Regression.java
	java -Xmx2048m Regression $basedir $dataset $model $f_res $interactive $args_model > ${f_log}
	unset CLASSPATH
elif [ $implem = "python" ]; then
	cd python;python regression.py $basedir $dataset $model $f_res $interactive $args_model #> ${f_log}
fi

cd $programsdir

#  	module load matlab
#  	matlab -nodisplay -nodesktop -nosplash -r "makeplot $basedir $dataset $model $implem" > /dev/null 2>&1
