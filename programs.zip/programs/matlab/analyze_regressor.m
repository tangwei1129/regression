clear all
