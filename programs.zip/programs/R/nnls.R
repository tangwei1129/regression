# https://www.r-bloggers.com/positive-coefficient-regression-in-r/
require(nnls,quietly=T)
lm.model=lm(output~.,pr);indices=which(is.na(lm.model$coefficients))
nnls.model=nnls(as.matrix(pr[,-c(indices,i_output)]),pr[,i_output])
sr=t(as.matrix(pv[,-c(indices,i_output)]) %*% nnls.model$x);sr=as.numeric(sr)
if(sd(sr)==0) stop('constant predicted output')
rm(lm.model,indices,nnls.model)
