require(caret,quietly=TRUE)
bag.model=bag(pr[,-i_output],pr[,i_output],bagControl=bagControl(fit=ctreeBag$fit,predict=ctreeBag$pred,aggregate=ctreeBag$aggregate))
sr=predict(bag.model,pv[,-i_output])
rm(bag.model)