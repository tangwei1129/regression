if(dataset=='auto_mpg') { indv=T;idi=c(1:3,7) } 
if(dataset=='automobile') { indv=T;idi=c(1:10,24) } #idi=index of discrete inputs
# if(dataset=='com_crime_unnorm') { indv=T;idi=c(122,71) }
if(dataset=='bike_day') { indv=T;idi=c(1:7) } 
if(dataset=='bike_hour') { indv=T;idi=c(1:8) }
if(dataset=='blog_feedback') { x=x[,-c(63:276)] }  #not use inputs 63:276 because lm works much worse with them
if(dataset=='electricity_hourly') { indv=T;idi=4 }
if(dataset=='fertility') { 
	indv=T;idi=c(1,3:8);names(x)=c('season','age','diseases','accident','surgical','fever','alcohol','smoking','hours_sitting','diagnosis')
}
if(dataset=='gas_flow_mod') { indv=T;idi=c(2,5:7) }
if(dataset=='forestfires') { indv=T;x$area=log(1+x$area);idi=1:4 } 
if(dataset=='gps_trajectory') { indv=T;idi=1:4; x$id_android=NULL;x$track_id=NULL } 
if(dataset=='insurance_coil') { indv=T;idi=1:86;idi=idi[-c(2,3,4)] } 
if(dataset=='servo') { indv=T;idi=1:4 } 
if(dataset=='student_mat') { indv=T;idi=1:16 } 
if(dataset=='student_por') { indv=T;idi=1:10 }
if(dataset=='UJ_floor' | dataset=='UJ_long' | dataset=='UJ_lat') { 
        indv=T;idi=523:525;x$USERID=NULL;x$PHONEID=NULL;x$TIMESTAMP=NULL;x=x[-which(x$FLOOR==0),]
}
if(dataset=='wbc') { indv=T;idi=1:9 } 
if(dataset=='wiki4HE') { 	indv=T;idi=2:52;idi=idi[-4] }
if(dataset=='facebook_metrics') { indv=T;idi=1 }
if(dataset=='solar_flare_1' || dataset=='solar_flare_2C' || dataset=='solar_flare_2M' || dataset=='solar_flare_2X') { indv=T;idi=1:10 }
