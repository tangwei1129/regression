set.seed(0,kind="default",normal.kind="default")  # starts the random number generation for experiment reproducibility

source("initialize.R")

f_model = sprintf("%s.R", model)
if(npar>0) {
	if(1 == npar) {
		nexp = n_val1*ntrials + ntrials
	} else {
        if(2==npar) {
			nexp = n_val1*n_val2*ntrials + ntrials
        } else {
            if(3==npar) {
				nexp = n_val1*n_val2*n_val3*ntrials + ntrials
			} else {
                nexp = n_val1*n_val2*n_val3*n_val4*ntrials + ntrials
            }
        }
	}
} else {
    nexp=ntrials
}
perf_measure='rmse';perf=double(ntrials);best_perf=Inf;iexp=0

calculate_rmse=function(sd,sr) {
	n=length(sd);rmse=sqrt(sum((sd-sr)^2)/n);
	return(rmse)
}

calculate_mae=function(sd,sr) {
	n=length(sd);mae=sum(abs(sd-sr))/n
	return(mae)
}

calculate_qerror=function(sd,sr) {
	qerror=sum(check(sd-sr,0.5))
	return(qerror)
}

evaluate=function(sd,sr) {
	switch(perf_measure,
		rmse=calculate_rmse(sd,sr),
		qerror=calculate_qerror(sd,sr))
}

evaluate_test=function(sd,sr) {
	r2=cor(sd,as.numeric(sr))^2;n=length(sd);dif=sd-sr;rmse=sqrt(sum(dif^2)/n);mae=sum(abs(dif))/n
	if(is.na(r2)) r2=0
	return(c(r2,rmse,mae))
}

# parameter tuning
if(1==npar) {
	write(sprintf("%20s\t%20s\t%20s\t%20s", 'progress',par1_name,perf_measure,'best'),file=f_res,append=T)
	best_val1=NA
	for (i in 1:n_val1) {
		val_par1 = val1[i];error_flag[]=F
		for(l in 1:ntrials) { #pr=training patterns; pv=validation patterns; sd=desired output for training patterns
			pr=x[xr[l,],];pv=x[xv[l,],];sd=x[xv[l,],i_output]
 			tryCatch({
				source(f_model)
			},error=function(cond) {
				write(sprintf('%s=%g partition %i: error: %s',par1_name,val_par1,l,cond$message),file=ferr,append=T)
				error_flag[l]<<-T  # <<- required to modify error_flag due to variable scope
			})
			if(error_flag[l]==F) { perf[l]=evaluate(sd,sr);rm(sr) }
			iexp = iexp + 1;rm(sd,pr,pv)
  			cat(sprintf("%5.1f%%\r", 100.*iexp/nexp))
		}
		if(any(error_flag==F)) {
			avg_perf=mean(perf[error_flag==F])
			if (avg_perf < best_perf) { best_perf=avg_perf;best_val1 = val1[i] }
			write(sprintf("%20.2f\t%20g\t%20g\t%20g",100.*iexp/nexp,val1[i],avg_perf,best_perf), file=f_res, append=T)
		}
	}
	if(is.na(best_val1)) {
		write(sprintf("Regressor failed for all the hyper-parameter values"), file=f_res,append=TRUE)
		stop('Regressor failed for all the hyper-parameter values')
	}
	write(sprintf("best_%s= %g best_%s=%g",par1_name,best_val1,perf_measure,best_perf),file=f_res, append=T)
	val_par1 = best_val1;
}
if(2==npar) {
	best_val1=NA;best_val2=NA
	write(sprintf("%20s\t%20s\t%20s\t%20s\t%20s", 'progress',par1_name,par2_name,perf_measure,'best'),file=f_res,append=T)
	for (i in 1:n_val1) {
		val_par1 = val1[i]
		for (j in 1:n_val2) {
			val_par2 = val2[j];error_flag[]=F
			for(l in 1:ntrials) {
				pr=x[xr[l,],];pv=x[xv[l,],];sd=x[xv[l,],i_output]
 				tryCatch({
					source(f_model)
 				},error=function(cond) {
 					write(sprintf('%s=%g %s=%g partition %i: error: %s',par1_name,val_par1,par2_name,val_par2,l,cond$message), file=ferr,append=T)
 					error_flag[l]<<-T  # <<- required to modify error_flag due to variable scope
 				})
				if(error_flag[l]==F) { perf[l]=evaluate(sd,sr);rm(sr) }
				iexp = iexp + 1;rm(sd,pr,pv)
 				cat(sprintf("%5.1f%%\r", 100.*iexp/nexp))
			}
			if(any(error_flag==F)) {
				avg_perf=mean(perf[error_flag==F])
				if (avg_perf < best_perf) {
					best_perf=avg_perf;best_val1=val1[i];;best_val2=val2[j]
				}
				write(sprintf("%20.2f\t%20g\t%20g\t%20g\t%20g",100.*iexp/nexp,val1[i],val2[j],avg_perf,best_perf), file=f_res, append=T)
			}
		}
	}
	if(is.na(best_val1)) {
		write(sprintf("Regressor failed for all the hyper-parameter values"), file=f_res,append=TRUE)
		stop('Regressor failed for all the hyper-parameter values')
	}
	write(sprintf("best_%s= %g best_%s= %g best_%s=%g",par1_name,best_val1,par2_name,best_val2,perf_measure,best_perf),file=f_res, append=T)
	val_par1 = best_val1; val_par2 = best_val2
}
if(3==npar) {
	best_val1=NA;best_val2=NA;best_val3=NA
	write(sprintf("%20s\t%20s\t%20s\t%20s\t%20s\t%20s",'progress',par1_name,par2_name,par3_name,perf_measure,'best'),file=f_res,append=T)
	for (i in 1:n_val1) {
		val_par1 = val1[i]
		for (j in 1:n_val2) {
			val_par2=val2[j]
			for(n in 1:n_val3) {
				val_par3=val3[n];error_flag[]=F
				for(l in 1:ntrials) {
					pr = x[xr[l,],]; pv = x[xv[l,],];sd=x[xv[l,],i_output]
					tryCatch({
						source(f_model)
					},error=function(cond) {
						write(sprintf('%s=%g %s=%g %s=%g partition %i: error: %s', par1_name,val_par1,par2_name,val_par2,par3_name, val_par3,l,cond$message), file=ferr,append=T)
						error_flag[l]<<-T  # <<- required to modify error_flag due to variable scope
					})
					if(error_flag[l]==F) { perf[l]=evaluate(sd,sr);rm(sr) }
					iexp = iexp + 1;rm(sd,pr,pv)
					cat(sprintf("%5.1f%%\r", 100.*iexp/nexp))
				}
				if(any(error_flag==F)) {
					avg_perf=mean(perf[error_flag==F])
					if (avg_perf < best_perf) {
						best_perf=avg_perf;best_val1=val1[i];best_val2=val2[j];best_val3=val3[n]
					}
					write(sprintf("%20.2f\t%20g\t%20g\t%20g\t%20g\t%20g",100.*iexp/nexp,val1[i],val2[j],val3[n],avg_perf,best_perf), file=f_res, append=T)
				}
			}
		}
	}
	if(is.na(best_val1)) {
		write(sprintf("Regressor failed for all the hyper-parameter values"), file=f_res,append=TRUE)
		stop('Regressor failed for all the hyper-parameter values')
	}
	write(sprintf("best_%s= %g best_%s= %g best_%s= %g best_%s=%g",par1_name,best_val1,par2_name,best_val2,par3_name,best_val3, perf_measure,best_perf),file=f_res, append=T)
	val_par1=best_val1;val_par2=best_val2;val_par3=best_val3
}
if(4==npar) {
	best_val1=NA;best_val2=NA;best_val3=NA;best_val4=NA
	write(sprintf("%20s\t%20s\t%20s\t%20s\t%20s\t%20s\t%20s",'progress',par1_name,par2_name,par3_name,par4_name,perf_measure,'best'), file=f_res,append=T)
	for (i in 1:n_val1) {
		val_par1 = val1[i]
		for (j in 1:n_val2) {
			val_par2=val2[j]
			for(n in 1:n_val3) {
				val_par3=val3[n]
				for(m in 1:n_val4) {
					val_par4=val4[m];error_flag[]=F
					for(l in 1:ntrials) {
						pr = x[xr[l,],]; pv = x[xv[l,],];sd=x[xv[l,],i_output]
						tryCatch({
							source(f_model)
						},error=function(cond) {
							write(sprintf('%s=%g %s=%g %s=%g %s=%g partition %i: error: %s',par1_name,val_par1,par2_name,val_par2, par3_name,val_par3,par4_name,val_par4,l,cond$message), file=ferr,append=T)
							error_flag[l]<<-T  # <<- required to modify error_flag due to variable scope
						})
						if(error_flag[l]==F) { perf[l]=evaluate(sd,sr);rm(sr) }
						iexp = iexp + 1;rm(sd,pr,pv)
						cat(sprintf("%5.1f%%\r",100.*iexp/nexp))
					}
					if(any(error_flag==F)) {
						avg_perf=mean(perf[error_flag==F])
						if (avg_perf < best_perf) { 
							best_perf=avg_perf;best_val1=val1[i];best_val2=val2[j];best_val3=val3[n];best_val4=val4[m]
						}
						write(sprintf("%20.2f\t%20g\t%20f\t%20g\t%20g\t%20g\t%20g",100.*iexp/nexp,val1[i],val2[j],val3[n],val4[m],avg_perf, best_perf), file=f_res, append=T)
					}
				}
			}
		}
	}
	if(is.na(best_val1)) {
		write(sprintf("Regressor failed for all the hyper-parameter values"), file=f_res,append=TRUE)
		stop('Regressor failed for all the hyper-parameter values')
	}
	write(sprintf("best_%s= %g best_%s= %g best_%s=%g",par1_name,best_val1,par2_name,best_val2,perf_measure,best_perf),file=f_res, append=T)
	val_par1=best_val1;val_par2=best_val2;val_par3=best_val3;val_par4=best_val4
}


# test
r2=double(ntrials);rmse=double(ntrials);mae=double(ntrials);t0=Sys.time();error_flag[]=F
# file trials_model_dataset.csv
fm=sprintf('%s/trials_%s_%s.dat',resultsdir,model,dataset)
write(sprintf("%10s %10s %10s %10s",'trial','R^2','RMSE','MAE'),file=fm)
write("test stage",file=f_res,append=TRUE)
write(sprintf("%20s\t%20s\t%20s",'progress(%)','partition','RMSE'),file=f_res,append=T)
for (i in 1:ntrials) {
 	ind=xr[i,];pr=x[ind,];ind=xt[i,];pv=x[ind,];sd=x[ind,i_output]
 	tryCatch({
		source(f_model)
	},error=function(cond) {
		write(sprintf('test partition %i: error: %s',i,cond$message),file=ferr,append=T)
		error_flag[i]<<-T  # <<- required to modify error_flag due to variable scope
	})
	if(error_flag[i]==F) {
		for(j in 1:npt) write(sprintf('%f %f',sd[j],sr[j]),file=f_plot,append=TRUE)
		res=evaluate_test(sd,sr);r2[i]=res[1];rmse[i]=res[2];mae[i]=res[3];rm(sr)
		write(sprintf("%10i %10g %10g %10g",i,r2[i],rmse[i],mae[i]),file=fm,append=T)
		write(sprintf('%20.2f\t%20i\t%20g',100.*iexp/nexp,i,rmse[i]),file=f_res,append=T)
	} else {
		write(sprintf("%10i error",i),file=fm,append=T)
	}
 	iexp=iexp+1;rm(sd,pr,pv)
	cat(sprintf("%5.1f%%\r", 100.*iexp/nexp))
}
if(any(error_flag==F)) {
	dt=difftime(Sys.time(),t0,units='sec')/ntrials;ind=which(error_flag==F)
	write(sprintf("avg_r2= %g std= %g",mean(r2[ind]),sd(r2[ind])), file=f_res,append=TRUE)
	write(sprintf("avg_rmse= %g std= %g",mean(rmse[ind]),sd(rmse[ind])), file=f_res,append=TRUE)
	write(sprintf("avg_mae= %g std= %g",mean(mae[ind]),sd(mae[ind])), file=f_res,append=TRUE)
	write(sprintf("time= %f s.",dt), file=f_res,append=TRUE)
	# file model_dataset.csv
	fm=sprintf('%s/%s_%s.csv',resultsdir,model,dataset)
	write(sprintf("%g %g %g %g",mean(r2),mean(rmse),mean(mae),dt), file=fm)
} else {
	write(sprintf("error in all test partitions"), file=f_res,append=TRUE)
}
cat('\n')
if(!is.null(warnings())) {
	print('warnings:');print(warnings())
}