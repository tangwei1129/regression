require(frbs,quietly=T)
if(val_par1==0) val_par1=0.1
lm.model=lm(output~.,data=pr);indices=which(is.finite(lm.model$coefficients[-1]))
range.data=matrix(apply(as.matrix(pr[,c(indices,i_output)]),2,range),nrow=2)
sink('/dev/null')
SBC.model=frbs.learn(data.train=pr[,c(indices,i_output)],range.data=range.data,method.type='SBC',control=list(r.a=val_par1))
while(sink.number()>0) { sink(NULL) }
sr=predict(SBC.model,pv[,indices]);sr[is.nan(sr)]=0
rm(lm.model,indices,SBC.model)
