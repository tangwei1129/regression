require(deepnet,quietly=TRUE)
Xr=as.matrix(pr[,-i_output]);Yr=as.matrix(pr[,i_output])
if(val_par2>0) {
	if(val_par3>0) {
		hid=c(val_par1,val_par2,val_par3)
	} else {
		hid=c(val_par1,val_par2)
	}
} else {
	hid=val_par1
}
dnn.model=sae.dnn.train(Xr,Yr,hidden=hid,activationfun='tanh',output='linear') 
Xt=as.matrix(pv[,-i_output]);sr=nn.predict(dnn.model,Xt);sr[is.na(sr)]=0
if(any(is.na(sr))) error('NA in sr')
if(sd(sr)==0) stop('constant predicted output')
rm(Xr,Yr,dnn.model,Xt)
