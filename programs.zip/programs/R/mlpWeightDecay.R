require(RSNNS,quietly=T)
mlpWeightDecay.model=mlp(pr[,-i_output],pr[,i_output],size=val_par1,learnFunc='BackpropWeightDecay',updateFuncParams=val_par2, outputActFunc='Act_Identity')
sr=predict(mlpWeightDecay.model,pv[,-i_output])
rm(mlpWeightDecay.model)
