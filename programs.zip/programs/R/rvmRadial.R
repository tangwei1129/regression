require(kernlab,quietly=T)
rvm.model=rvm(output ~ . ,data=pr,kernel='rbfdot',kpar=list(sigma=val_par1))
sr=predict(rvm.model,pv[,-i_output])
rm(rvm.model)