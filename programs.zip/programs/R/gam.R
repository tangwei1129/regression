require(mgcv,quietly=T)
t=names(pr);fr=paste('output ~ ',t[1]);
for (k in 2:ni) { fr=paste(fr,t[k],sep=' + ') }
if(val_par1==0) { s=FALSE } else { s=TRUE }
gam.model=gam(formula(fr),data=pr,select=s)
sr=predict(gam.model, pv)
rm(gam.model)
