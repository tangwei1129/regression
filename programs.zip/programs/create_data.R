library(MASS)  #for boxcox()

# list_dataset=c('3Droad','airfoil','air_quality_CO','air_quality_NMHC','air_quality_NO2','air_quality_NOx','air_quality_O3','appliances_energy','automobile','auto_mpg','beijing_pm25','bike_day','bike_hour','blog_feedback','buzz_twitter','combined_cycle','com_crime','com_crime_unnorm','com_hd','compress_stren','cond_turbine','csm1415','CT_slices','cuff_less','daily_demand','dynamic_features','energy_cool','energy_heat','facebook_comment','facebook_metrics','forestfires','gas_drift','gas_dynamic_CO','gas_dynamic_methane','geo_lat','geo_long','geo_music_lat','geo_music_long','gps_trajectory','greenhouse_net','household_consume','housing','KEGG_reaction','KEGG_relation','online_news','park_motor_UPDRS','park_speech','park_total_UPDRS','physico_protein','pm25_beijing_dongsi','pm25_beijing_dongsihuan','pm25_beijing_nongzhanguan','pm25_beijing_us_post','pm25_chengdu_caotangsi','pm25_chengdu_shahepu','pm25_chengdu_us_post','pm25_guangzhou_5th_middle_school','pm25_guangzhou_city_station','pm25_guangzhou_us_post','pm25_shanghai_jingan','pm25_shanghai_us_post','pm25_shanghai_xuhui','pm25_shenyang_taiyuanji','pm25_shenyang_us_post','pm25_shenyang_xiaoheyan','servo','slump','slump_comp','slump_flow','SML2010','stock_abs','stock_annual','stock_excess','stock_exchange','stock_rel','stock_systematic','stock_total','student_mat','student_por','UJ_lat','UJ_long','video_transcode','yacht_hydro','year_prediction')

list_dataset=c('com_crime_unnorm')
ndata=length(list_dataset);idata=1

for(dataset in list_dataset) {
	set.seed(0,kind="default",normal.kind="default")  # starts the random number generation for experiment reproducibility

	tryCatch({ dir.create(sprintf('../data/%s',dataset)) },warning=function(cond) { })
	
	
	# datasets with discrete inputs: auto_mpg, automobile, com_crime_unnorm, bike_day, bike_hour, forestfires, gps_trajectory, servo, student_mat, student_por, wbc
	cat(sprintf('CREATING DATASET %s (%i/%i-%6.2f%%) ...\n',dataset,idata,ndata,100.*idata/ndata));idata=idata+1

	#default dataset configuration; indv=F means that there is no dummy variable (nor discrete input)
	nf=sprintf('../../original_data/%s/%s.data',dataset,dataset);indv=F

	# data reading
	x=read.table(nf,header=T)
	
	#specific dataset configuration
	source('datasets.R')
	
	np=nrow(x);n=ncol(x);ni=n-1;names(x)[n]='output';di=logical(ni)  #di[i]=T for a discrete input
	if(indv==T) di[idi]=T
	
	#----------------------------------------------------------------
	# data filtering
	cat('filtering data ...\n');fl=sprintf('../data/%s/%s.log',dataset,dataset);
	tryCatch({ file.remove(fl) },warning=function(cond) { })
	#  remove constant inputs
	ci=c()
	for(i in 1:ni) {
		if(length(unique(x[,i]))==1) {
			ci=c(ci,i);
			t=sprintf('constant input %i %s removed',i,names(x)[i])
			cat(t,'\n');write(t,file=fl,append=T)
		}
	}
	nci=length(ci)
	if(nci>0) {
		x=x[,-ci];di=di[-ci];ni=ni-length(ci);
	}
	# remove repeated inputs
	ri=c()
	for(i in 1:(ni-1)) {
		for(j in (i+1):ni) {
			if(all(x[,i]==x[,j]) & all(j!=ri)) {
				ri=c(ri,j);t=sprintf('input %i %s (repeated with %i %s) removed',j,names(x)[j],i,names(x)[i])
				cat(t,'\n');write(t,file=fl,append=T)
			}
		}
	}
	ri=unique(ri);nri=length(ri)
	if(nri>0) {
		x=x[,-ri];di=di[-ri];ni=ni-length(ri);
	}
	for(i in 1:dim(x)[2]) {
		if(any(is.infinite(x[,i]))) print(i)
	}
	#remove inputs which are linearly dependent
	lm.model=lm(output~.,data=x);indices=which(is.na(lm.model$coefficients[-1]));nin=length(indices)
	if(nin>0) {
		for(i in indices) {
			t=sprintf('dependent input %i %s removed',i,names(x)[i]);cat(t,'\n');write(t,file=fl,append=T)
		}
		x=x[,-indices];di=di[-indices];ni=ni-nin
	}
	
	#----------------------------------------------------------------
	# data preprocessing
	cat('preprocessing data ...\n')
	for(i in 1:ni) {
		if(di[i]==F) {  #discrete inputs are not pre-processed
			t=x[,i];m=mean(t);d=sd(t)
			if(d!=0) x[,i]=(t-m)/d
		}
	}
	n=ncol(x);t=x[,n];med=mean(t);desv=sd(t)
	if(desv==0) stop('output with zero std!')
	x[,n]=(t-med)/desv
	
	#----------------------------------------------------------------
	# generation of dummy variables
	if(indv==T) {
		cat('creating dummy variables ...\n')  #when indv==F, idi must be set in datasets.R
		ndi=sum(di);val=vector('list',ni);nval=integer(ni)  #ndi=no. discrete inputs
		for(i in 1:ni) {
			if(di[i]==T) {
				x[,i]=as.factor(x[,i]);t=sort(unique(x[,i]));val[[i]]=t[2:length(t)];nval[i]=length(val[[i]])
			}
		}
		niv2=sum(nval) #niv2=no. indicator (dummy) variables in x2
		ni2=niv2+ni-ndi;np2=np  #ni2=no. inputs in x2;np2=no. patterns in x2
		di2=logical(ni2)  #di2=indicator (dummy) input
		x2=data.frame(matrix(0,np2,ni2),x$output);k=1
		for(i in 1:ni) {  # names of dummy inputs
			s=names(x)[i]
			if(di[i]==T) {
				for(j in 1:nval[i]) {
					names(x2)[k]=sprintf('%s_%i',s,val[[i]][j]);
					di2[k]=T;k=k+1
				}
			} else {
				names(x2)[k]=s;k=k+1
			}
		}
		names(x2)[ni2+1]='output'  #add output column
		for(i in 1:np2) { 
			cat(sprintf('%6.2f%%\r',100*i/np2))
			k=1
			for(j in 1:ni) {  # values of dummy inputs
				if(di[j]==F) { #continuous input
					x2[i,k]=x[i,j];k=k+1
				} else {   # discrete input
					t=x[i,j];l=which(t==val[[j]])
					if(length(l)==1) x2[i,k+l-1]=1
					k=k+nval[j]
				}
			}
		}
		
		# remove dummy inputs with NA coefficient in lm.model
		lm.model=lm(output~.,data=x2);indices=which(is.na(lm.model$coefficients[-1]));nin=length(indices)
		if(nin>0){	#exists some dummy variable with lm.model$coefficients==NA
			for(i in indices) {
				cat('dependent dummy input ');cat(sprintf('%s',names(x2)[i]));cat(' removed\n')
				write(sprintf('dependent dummy input %s removed',names(x2)[i]),file=fl,append=T)
			}
			x2=x2[,-indices];di2=di2[-indices];ni2=ni2-nin
		}
		
		# preprocessing of data frame x2 with dummy variables
		for(i in 1:ni2) {
			if(di2[i]==F) { #discrete inputs are not pre-processed
				t=x2[,i];med=mean(t);desv=sd(t)
				if(desv!=0) x2[,i]=(t-med)/desv
			}
		}
		n=ncol(x2);t=x2[,n];med=mean(t);desv=sd(t)
		if(desv==0) stop('x2: output with zero std!')
		x2[,n]=(t-med)/desv
		t=x2  #x2 with dummy variables
	} else {
		t=x  #original dataset x
	}

	#----------------------------------------------------------------
	# datas set info dataset/dataset.txt
	cat(sprintf('writing %s.txt ...\n',dataset))
	nf2=sprintf('../data/%s/%s.txt',dataset,dataset)
	write(sprintf('np= %i',np),file=nf2)
	if(indv==T) {
		write(sprintf('ni= %i',ni2),file=nf2,append=T)
	} else {
		write(sprintf('ni= %i',ni),file=nf2,append=T)
	}

	#----------------------------------------------------------------
	# boxcox transformation
	y=t$output;vmin=min(y)
	if(vmin<=0) { m=-vmin+1;y=y+m }
	r=boxcox(y ~ 1,lambda=seq(-2,2,1/8),plotit=F)
	lambda=r$x[which.max(r$y)]
	if(lambda!=0) t$output=(y^lambda-1)/lambda   # plot(density(x$output))
	write(sprintf('%s: lambda= %f',dataset,lambda),file=sprintf('../data/%s/lambda_%s.txt',dataset,dataset))
	
	#----------------------------------------------------------------
	# writing data 
	cat('writing data ...\n')
	write.table(format(t,digits=6),file=sprintf('../data/%s/%s_R.dat', dataset, dataset),quote=F,sep='\t')  
	
	#----------------------------------------------------------------
	# writing partitions
	cat('writing partitions ...\n')
	nf2=sprintf('../data/%s/%s_partitions.dat',dataset,dataset)
	tryCatch({ file.remove(nf2) },warning=function(cond) { })
	
	if(np<=10000) {  # for datasets with <=10000 patterns, 500 trials
		ntrials=500
		p=t(replicate(ntrials,sample(np)))
		for(i in 1:ntrials) {
			cat(p[i,],file=nf2,append=T);cat('\n',file=nf2,append=T)
			cat(sprintf('%6.2f%%\r',100*i/ntrials))
		}
	} else {  # for datasets with >=10000 patterns, 10-fold
		ntrials=10;p=sample(np)
		n=floor(np/10);nptr=n+double(ntrials)  #nptr=no. patterns/trial
		nptr[ntrials]=np-n*(ntrials-1)
		start=double(ntrials);end=double(ntrials);j=1
		for(i in 1:ntrials) {
			start[i]=j;j=j+nptr[i];end[i]=j-1
		}
		j=1;iexp=0;nexp=ntrials*ntrials;
		for(i in 1:ntrials) {
			l=j;k=0
			while(k<ntrials) {
				a=start[l];b=end[l];k=k+1
				cat(c(p[a:b],''),file=nf2,append=T) #the '' is to avoid adding numbers without separating space
				l=l+1;if(l>ntrials) l=1
				cat(sprintf('%3.0f%%\r',100*iexp/nexp));iexp=iexp+1
			}
			j=j+1;cat('\n',file=nf2,append=T)
		}
	}	

	cat(sprintf('dataset %s finished\n--------------------------\n', dataset))
}