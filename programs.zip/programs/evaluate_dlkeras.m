clear all
f=fopen('../results/REPORTS/dlkeras_tuning_report.txt','r');
if -1==f
    error('error en fopen')
end
ndata=83;dataset=cell(1,ndata);val=zeros(1,ndata);
for i=1:ndata
    dataset{i}=fscanf(f,'%s',1);
    val(i)=str2double(fscanf(f,'%s',1));
end
fclose(f);
nlevel=8;
for i=1:nlevel
    fprintf('%i - %i\n',i,sum(val==i))
end