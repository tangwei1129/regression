require(MASS,quietly=T)
indices=which(is.finite(lm(output ~ .,data=pr)$coefficients[-1]))
lm.model=lm(output ~ . ,data=pr[,c(indices,i_output)]);
sr=predict(lm.model,pv[,indices])
rm(indices,lm.model)
