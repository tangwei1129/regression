nspc=7;fprintf(repmat(' ',1,nspc));str=repmat('\b',1,nspc);
