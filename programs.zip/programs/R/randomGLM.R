require(randomGLM,quietly=T)
tx=as.matrix(pr[,-i_output]);ty=as.matrix(pr[,i_output])
sink('/dev/null')
randomGLM.model=randomGLM(tx,ty,maxInteractionOrder=val_par1)
while(sink.number()>0) { sink(NULL) }
rm(tx,ty);tx=as.matrix(pv[,-i_output]);sr=predict(randomGLM.model,tx)
rm(tx,randomGLM.model)
