require(lars,quietly=T)
tx=as.matrix(pr[,-i_output]);ty=pr[,i_output]
lars.model=lars(tx,ty,type='lasso')
sr=predict(lars.model,newx=pv[,-i_output],s=val_par1,type='fit',mode='fraction')$fit
if(sd(sr)==0) stop('constant predicted output')
rm(tx,ty,lars.model,t)