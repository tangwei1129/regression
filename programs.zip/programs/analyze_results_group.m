clear all
clc

addpath('matlab')

group=4;

fprintf('reading regressor results for dataset group %i  ...\n',group);

read_results=1;

if group==1    % 20 datasets in group 1
    dataset_list={'slump','slump_flow','gps_trajectory','csm1415','stock_abs',...
        'stock_annual','stock_excess','stock_rel','stock_systematic','stock_total',...
        'student_mat','forestfires','student_por','park_speech','geo_lat','geo_long',...
        'geo_music_lat','geo_music_long','airfoil','com_crime_unnorm'};
    best_model='penalized';
elseif group==2   % 23 datasets in group 2
    dataset_list={'daily_demand','slump_comp','servo','automobile','com_hd',...
        'yacht_hydro','auto_mpg','housing','facebook_metrics','stock_exchange',...
        'bike_day','energy_cool','energy_heat','compress_stren','air_quality_CO',...
        'air_quality_NMHC','air_quality_NO2','air_quality_NOx','air_quality_O3',...
        'com_crime','gas_dynamic_CO','gas_dynamic_methane','SML2010'};
    best_model='cubist';
elseif group==3   % 33 datasets in group 3
    dataset_list={'park_motor_UPDRS','park_total_UPDRS','appliances_energy',...
        'pm25_beijing_dongsihuan','pm25_shenyang_us_post','pm25_guangzhou_5th_middle_school',...
        'pm25_shanghai_jingan','pm25_shenyang_taiyuanji','pm25_chengdu_caotangsi',...
        'pm25_shanghai_xuhui','pm25_chengdu_shahepu','pm25_shenyang_xiaoheyan',...
        'pm25_beijing_nongzhanguan','pm25_beijing_dongsi','pm25_chengdu_us_post',...
        'pm25_shanghai_us_post','pm25_guangzhou_city_station','pm25_guangzhou_us_post',...
        'online_news','facebook_comment','beijing_pm25','physico_protein',...
        'pm25_beijing_us_post','KEGG_relation','blog_feedback','cuff_less',...
        'video_transcode','dynamic_features','3Droad','year_prediction',...
        'buzz_twitter','greenhouse_net','household_consume'};
    best_model='M5';
elseif group==4   % 7 datasets in group 4
    dataset_list={'combined_cycle','cond_turbine','UJ_lat','UJ_long',...
        'bike_hour','CT_slices','KEGG_reaction'};
    best_model='M5';
else
    error('group %i unknown',group)
end

dataset_list2=strrep(dataset_list,'_','-');
ndata=numel(dataset_list);

model_list={'elm_kernel','svr','elm','nnls','svmRadial','rpart','lm','gbm','bdk','avNNet','ctree2','widekernelpls','enet','plsRglm','extraTrees','glmboost','pcaNNet','icr','rqnc','relaxo','foba','penalized','spls','ppr','superpc','dnn','gaussprPoly','gaussprLinear','rqlasso','pcr','kknn','RRF','krlsRadial','kernelpls','gam','lars','glmnet','simpls','earth','M5','mlpWeightDecay','ridge','gaussprRadial','lasso','evtree','rf','rlm','BstLm','bayesglm','rvmRadial','rbf','cforest','cubist','glmStepAIC','blackboost','qrf','grnn','SBC','partDSA','treebag','bag','mlpWeightDecayML','brnn','bagEarth','bartMachine','gamboost','bstTree','randomGLM','spikeslab','dlkeras','Boruta','xgbLinear','enpls.fs','nodeHarvest','bstSm','xgbTree','qrnn'};
model_list2={'kelm','svr','elm','nnls','svmRad','rpart','lm','gbm','bdk','avNNet','ctree2','wkpls','enet','plsRglm','extraTrees','glmboost','pcaNNet','icr','rqnc','relaxo','foba','penalized','spls','ppr','superpc','dnn','gprPol','gprLin','rqlasso','pcr','kknn','RRF','krlsRad','kpls','gam','lars','glmnet','simpls','earth','M5','mlpWD','ridge','gprRad','lasso','evtree','rf','rlm','BstLm','bayesglm','rvmRad','rbf','cforest','cubist','glmSAIC','blackboost','qrf','grnn','SBC','partDSA','treebag','bag','mlpWDml','brnn','bagEarth','bMachine','gamboost','bstTree','rndGLM','spikeslab','dlkeras','Boruta','xgbLinear','enpls.fs','nodeHarvest','bstSm','xgbTree','qrnn'};

nmodel=numel(model_list);
implem_list=cell(1,nmodel);
for i=1:nmodel
    implem_list{i}=get_implem(model_list{i});
end

% reads desired test output to calculate the rmse and mae in case of error
def_rmse=zeros(1,ndata);def_mae=zeros(1,ndata);
max_npart=500;train_perc=70;valid_perc=20;iexp=1;nexp=ndata;
fprintf('calculating training means ...\n');init_progress
for i=1:ndata
    dataset=dataset_list{i};[x ~]=read_data_table(dataset);
    [np ni]=size(x);npr=floor(train_perc*np/100);
    npv=floor(valid_perc*np/100);npt=np-npr-npv;
    nf=sprintf('../results/%s/lm_R/plot_lm_%s.dat',dataset,dataset);y=load(nf);d=y(:,1);
    nf=sprintf('../data/%s/%s_partitions.dat',dataset,dataset);part=load(nf);npart=size(part,1);
    if npt~=numel(d)/npart
        error('%s: npt=%i /= numel(d)=%i\n',dataset,npt,numel(d))
    end
    ini=1;fin=ini+npt-1;dif=zeros(1,npt);
    for j=1:npart
        ind=part(j,1:npr);t=ini:fin;
        dif(t)=bsxfun(@minus,d(t),mean(x(ind,ni)));
        ini=ini+npt;fin=ini+npt-1;
    end
    def_rmse(i)=sqrt(sum(dif.^2)/npt);def_mae(i)=sum(abs(dif))/npt;
    print_progress
end
end_progress

% reads regressor results
if read_results==1
    error_flag=zeros(nmodel,ndata); % error flag for model and dataset
    r2=zeros(nmodel,ndata); % R^2 for model and dataset
    rmse=zeros(nmodel,ndata); % RMSE for model and dataset
    mae=zeros(nmodel,ndata); % MAE for model and dataset
    time=inf*ones(nmodel,ndata); % time spent by model and dataset
    mem=inf*ones(nmodel,ndata); % memory spent by  model and dataset
    fprintf('reading results ...\n');
    init_progress;iexp=1;nexp=ndata*nmodel;
    for i=1:ndata
        data=dataset_list{i};
        for j=1:nmodel
            model=model_list{j};implem=implem_list{j};
            if error_check(model,implem,data)
                error_flag(j,i)=1;
            else
                nf=sprintf('../results/%s/%s_%s/plot_%s_%s.dat',data,model,...
                    implem,model,data);x=load(nf);
                to=x(:,1);ro=x(:,2);n=numel(to);t=corrcoef(to,ro);u=t(1,2);
                if ~isnan(u)
                    r2(j,i)=u^2;
                end
                dif=to-ro;rmse(j,i)=sqrt(sum(dif.^2)/n);mae(j,i)=sum(abs(dif))/n;
                nf=sprintf('../results/%s/%s_%s/%s_%s.csv',data,model,...
                    implem,model,data);x=load(nf);
                time(j,i)=x(4);
                nf=sprintf('scripts/%s/%s_%s.sh',data,model,data);
                cmd=sprintf('grep ppn %s | cut -d= -f3|cut -d, -f1',nf);
                [~,output]=system(cmd);output(output=='''')=' ';
                mem(j,i)=2*str2double(output);
            end
            print_progress
        end        
        ind1=find(~error_flag(:,i));ind2=find(error_flag(:,i));
        if numel(ind1)==0
            error('dataset %s: error in all models',data)
        end
        max_rmse=max(rmse(ind1,i));rmse(ind2,i)=max(max_rmse,def_rmse(i));
        max_mae=max(mae(ind1,i));mae(ind2,i)=max(max_mae,def_mae(i));
    end
    end_progress
    nf=sprintf('../results/REPORTS/dataset_group%i/table_r2_group%i.dat',group,group);
    write_result_table(r2,nf,error_flag,model_list,dataset_list);
    nf=sprintf('../results/REPORTS/dataset_group%i/table_rmse_group%i.dat',group,group);
    write_result_table(rmse,nf,error_flag,model_list,dataset_list);
    nf=sprintf('../results/REPORTS/dataset_group%i/table_mae_group%i.dat',group,group);
    write_result_table(mae,nf,error_flag,model_list,dataset_list);
    nf=sprintf('../results/REPORTS/dataset_group%i/table_time_group%i.dat',group,group);
    write_result_table(time,nf,error_flag,model_list,dataset_list);
    nf=sprintf('../results/REPORTS/dataset_group%i/table_mem_group%i.dat',group,group);
    write_result_table(mem,nf,error_flag,model_list,dataset_list);
else
    nf=sprintf('../results/REPORTS/dataset_group%i/table_r2_group%i.dat',group,group);
    [r2 error_flag]=read_result_table(nf,model_list,dataset_list);r2(isnan(r2))=0;
    nf=sprintf('../results/REPORTS/dataset_group%i/table_rmse_group%i.dat',group,group);
    [rmse ~]=read_result_table(nf,model_list,dataset_list);rmse(isnan(rmse))=inf;
    nf=sprintf('../results/REPORTS/dataset_group%i/table_mae_group%i.dat',group,group);
    [mae ~]=read_result_table(nf,model_list,dataset_list);mae(isnan(mae))=inf;
end

%---------------------------------------------------
% best R^2 for each dataset
[r2_max i_max]=max(r2);[~,ind]=sort(r2_max,'descend');
nf=sprintf('../results/REPORTS/dataset_group%i/best_r2_dataset.dat',group);f=open_file(nf,'w');
for i=1:ndata
    j=ind(i);
    fprintf(f,'%3i: %35s %20s: %f\n',i,dataset_list{j},model_list{i_max(j)},r2_max(j));
end
fclose(f);
% maximum R2 and R2 achieved by penalized for datasets of group 1
clf;plot(r2_max(ind),'og-','markerfacecolor','g');hold on
r2_best=r2(strcmp(model_list,best_model),ind);plot(r2_best,'bs-','markerfacecolor','b');
r2_lm=r2(strcmp(model_list,'lm'),ind);plot(r2_lm,'r^-','markerfacecolor','r');
if group==4
    legend({'Best',best_model,'lm'},'location','southeast')
else
    legend({'Best',best_model,'lm'},'location','northeast')
end
ylabel('R^2','fontsize',18);grid on
if group==3
    xlabel('Data set');axis([1 ndata 0 1])
else
    xlabel_inclin(dataset_list2(ind),0,1.1,25,8)
end
nf=sprintf('../results/REPORTS/dataset_group%i/best_r2_group%i.eps',group,group);
print('-depsc',nf)
% number of datasets where each regressor achieves the best R^2
nf=sprintf('../results/REPORTS/dataset_group%i/number_best_r2_model.dat',group);f=open_file(nf,'w');
nbest=zeros(1,nmodel);
for i=1:ndata
    j=i_max(i);nbest(j)=nbest(j)+1;
end
[~,nbest_ind]=sort(nbest,'descend');n=sum(nbest>0);
for i=1:n
    j=nbest_ind(i);
    fprintf(f,'%3i: %20s %i\n',i,model_list{j},nbest(j));
end
fprintf(f,'total datasets= %i\n',sum(nbest));
fclose(f);
% model list according to R^2 Friedman rank
r2_rank=friedman_rank(r2,'descend');[~,r2_ind]=sort(r2_rank);
nf=sprintf('../results/REPORTS/dataset_group%i/friedman_rank_r2_group%i.dat',...
    group,group);f=open_file(nf,'w');
for i=1:nmodel
    j=r2_ind(i);fprintf(f,'%3i: %20s: %5.1f\n',i,model_list{j},r2_rank(j));
end
fclose(f);
% model list according RMSE Friedman ranking
nf=sprintf('../results/REPORTS/dataset_group%i/friedman_rank_rmse_group%i.dat',...
    group,group);f=open_file(nf,'w');
rmse_rank=friedman_rank(rmse,'ascend');[~,rmse_ind]=sort(rmse_rank);
fprintf(f,'Friedman rank RMSE:\n');
for i=1:nmodel
    j=rmse_ind(i);fprintf(f,'%3i: %20s: %5.1f\n',i,model_list{j},rmse_rank(j));
end
fclose(f);
% model list according MAE Friedman ranking
nf=sprintf('../results/REPORTS/dataset_group%i/friedman_rank_mae_group%i.dat',...
    group,group);f=open_file(nf,'w');
mae_rank=friedman_rank(mae,'ascend');[~,mae_ind]=sort(mae_rank);fprintf(f,'Friedman rank MAE:\n');
for i=1:nmodel
    j=mae_ind(i);fprintf(f,'%3i: %20s: %5.1f\n',i,model_list{j},mae_rank(j));
end
fclose(f);
% model list by increasing number of datasets with errors
errors_model=sum(error_flag,2);[~,i]=sort(errors_model);
nf=sprintf('../results/REPORTS/dataset_group%i/models_by_errors.dat',group);f=open_file(nf,'w');
fprintf(f,'%10s %20s %10s\n','No.','Model','Errors');
for j=1:nmodel
    k=i(j);fprintf(f,'%10i: %20s %10i ',j,model_list{k},errors_model(k));
    ind=find(error_flag(k,:));
    for l=1:errors_model(k)
        fprintf(f,'%s ',dataset_list{ind(l)});
    end
    fprintf(f,'\n');
end
fclose(f);
% TEX table with Friedman ranks
nf=sprintf('../results/REPORTS/dataset_group%i/table_group%i.tex',...
    group,group);f=open_file(nf,'w');
err_perc=100*errors_model/ndata;best_perc=100*nbest/ndata;
fprintf(f,'\\begin{tabular}{|c||c|c|c||c|c||c|c||c|c|}\n');fprintf(f,'\\hline\n');
fprintf(f,'& \\multicolumn{3}{c||}{$R^2$} & \\multicolumn{2}{c||}{RMSE} & \\multicolumn{2}{c||}{MAE} & \\multicolumn{2}{c|}{Best $R^2$} \\\\ \\hline \n');
fprintf(f,'Pos. & Model & Rank & \\%%Error & Model & Rank & Model & Rank & Model & \\%%Best\\\\ \\hline \\hline \n');
for i=1:20
    r2i=r2_ind(i);rmsei=rmse_ind(i);maei=mae_ind(i);nbesti=nbest_ind(i);
    if best_perc(nbesti)>0
        fprintf(f,'%i & %s & %.2f & %.1f & %s & %.2f & %s & %.2f & %s & %.1f \\\\ ',i,...
            model_list2{r2i},r2_rank(r2i),err_perc(r2i),model_list2{rmsei},...
            rmse_rank(rmsei),model_list2{maei},mae_rank(maei),...
            model_list2{nbesti},best_perc(nbesti));
    else
        fprintf(f,'%i & %s & %.2f & %.1f & %s & %.2f & %s & %.2f & --- & --- \\\\ ',i,...
            model_list2{r2i},r2_rank(r2i),err_perc(r2i),model_list2{rmsei},...
            rmse_rank(rmsei),model_list2{maei},mae_rank(maei));
    end
    if i==10
        fprintf(f,'\\cline{1-8} \n');
    else
        fprintf(f,'\n');
    end
end
fprintf(f,'\\hline \n');fprintf(f,'\\end{tabular}\n');
fclose(f);

% Friedman rank excluding PM2.5 datasets
if  group==3
    ind=[4:18 23];r2_pm25=r2;r2_pm25(:,ind)=[];  % ind=indices of pm25 datasets
    r2_rank=friedman_rank(r2_pm25,'descend');[~,r2_ind]=sort(r2_rank);
    nf='../results/REPORTS/dataset_group3/table_friedman_rank_r2_group3_without_pm25.tex';
    f=open_file(nf,'w');nrows=5;j=zeros(1,4);
    for i=1:4
        j(i)=1+(i-1)*nrows;
    end
    fprintf(f,'\\begin{tabular}{|c|c|c||c|c|c||c|c|c||c|c|c|}\n');fprintf(f,'\\hline\n');
    fprintf(f,'Pos. & Model & Rank & Pos. & Model & Rank & Pos. & Model & Rank & Pos. & Model & Rank \\\\ \\hline \n \\hline \n');
    for i=1:nrows
        for k=1:4
            m=j(k);l=r2_ind(m);
            if k<4
                fprintf(f,'%3i & %s & %5.1f & ',m,model_list2{l},r2_rank(l));
            else
                fprintf(f,'%3i & %s & %5.1f \\\\ \\hline \n',m,model_list2{l},r2_rank(l));
            end
        end
        j=j+1;
    end
    fprintf(f,'\\end{tabular}\n');
    fclose(f);
%     for i=1:20
%         m=r2_ind(i);fprintf('%i %20s %5.1f\n',i,model_list2{m},r2_rank(m))
%     end
end

%plays a sound
% load gong.mat;sound(y, Fs);