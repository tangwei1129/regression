clf;
r2_max=max(tr2);[~,ind]=sort(r2_max,'descend');
plot(r2_max(ind),'bs-','markerfacecolor','b');hold on
r2_ref=r2(strcmp(model_list,model_ref),:);
plot(r2_ref(ind),'ro-','markerfacecolor','r');grid on
legend({'Best R^2',model_ref},'location','northeast')
xlabel_inclin(dataset_list2(ind),0,1,25,10)
nf='pp.eps';print('-depsc',nf);