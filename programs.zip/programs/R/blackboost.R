require(mboost,quietly=TRUE)
# blackboost.model=blackboost(output ~ ., data=pr,control=boost_control(mstop=val_par1))  # alternativa 1
blackboost.model=blackboost(output ~ ., data=pr,tree_controls=party::ctree_control(maxdepth=val_par1)) #alternativa 2
sr=predict(blackboost.model,pv[,-i_output])
rm(blackboost.model)
