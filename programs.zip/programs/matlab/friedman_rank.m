% calculation of Friedman rank results 
% perf: matrix with performance measure with models by rows and datasets by columns
% order: 'descend' for performance measurements, 'ascend' for error measurements
function rank=friedman_rank(perf,order)
[nmodel ndata]=size(perf);pos=zeros(nmodel,ndata);
for i=1:ndata
    [~,ind]=sort(perf(:,i),order);
    for j=1:nmodel
        pos(ind(j),i)=j;
    end
end
rank=mean(pos,2);
end
