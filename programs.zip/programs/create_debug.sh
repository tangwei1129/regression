#!/bin/bash

dir=../../debug
model=relaxo_R
dataset=stock_systematic

echo 'creating debug for' $model $dataset '...'

mkdir -p ${dir}/data ${dir}/programs ${dir}/results
cp -r R ${dir}/programs
cp -r matlab ${dir}/programs
cp -r python ${dir}/programs
cp -r C ${dir}/programs
cp run_model_dataset.sh ${dir}/programs
cp -r ../data/${dataset} ${dir}/data
mkdir -p ${dir}/results/${dataset}/${model}

echo 'finished'