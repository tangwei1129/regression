require(enpls,quietly=T)
#there is no threshold parameter, as opposite to http://topepo.github.io/caret/train-models-by-tag.html
#da erro ncomp inválido nalgúns datasets, non se debe a entradas constantes
enpls.fs.model=enpls.fit(pr[,-i_output],pr[,i_output],maxcomp=val_par1)  
sr=predict(enpls.fs.model,pv[,-i_output])
if(sd(sr)==0) stop('constant predicted output')
rm(enpls.fs.model)
