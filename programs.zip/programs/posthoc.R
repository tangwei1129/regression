library(PMCMR,quietly=T)

r2_whole=read.table('../results/REPORTS/global/table_r2_global.dat')
# sel_model=c('cubist','gbm','bstTree','M5','avNNet','extraTrees','pcaNNet','rf','ppr','svr')
sel_model=c('cubist','gbm','bstTree','M5','avNNet','extraTrees','pcaNNet','rf','ppr','svr','bagEarth','qrf','blackboost','earth','kknn','penalized','dlkeras','svmRadial','grnn','bag')
r2=t(r2_whole[sel_model,])

#Friedman test
ft=friedman.test(r2)
cat(sprintf('Friedman test: p=%e\n',ft$p.value))

#Post-Hoc Friedman-Nemenyi test
pval=posthoc.friedman.nemenyi.test(r2)$p.value
nf='../results/REPORTS/global/post-hoc-friedman-nemenyi-test.dat'
file.remove(nf)
for(i in 1:nrow(pval)) {
	write(sprintf('%.3g',pval[i,1]),file=nf,append=T)
 	cat(sprintf('%i %10s %.3g\n',i,rownames(pval)[i],pval[i,1]))
}


# #dendrograma
# setEPS()
# postscript("../results/REPORTS/global/dendrogram.eps")
# pval=posthoc.friedman.nemenyi.test(y=r2)$p.value
# pval[is.na(pval)]=1e-13;pval=pval+t(pval);pval=abs(log(pval))
# h=hclust(as.dist(pval)) #method=complete (default) ward.D ward.D2 single average mcquitty median centroid
# plot(h,cex=0.5,xlab='',ylab='|log p| distance',main='',sub='')
# # text(x=20.5,y=31,'A',cex=1,srt=90,col='red')
# # rect(21.5,-8,31.5,31,border='red',lty='dashed')  #,lty='dashed',density=70,col='yellow'
# # text(x=43,y=31,'B',cex=1,srt=90,col='blue')
# # rect(32,-8,41.5,31,border='blue',lty='dashed')
# # text(x=36,y=12,'B',cex=1,srt=90)
# dev.off()
