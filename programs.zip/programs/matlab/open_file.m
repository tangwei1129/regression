function fd=open_file(nf,mode)
	fd=fopen(nf,mode);
	if -1==fd
		error('fopen %s',nf);
    end
end
