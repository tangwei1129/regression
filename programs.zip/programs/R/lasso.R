require(elasticnet,quietly=T)
lm.model=lm(output~.,pr);indices=which(is.na(lm.model$coefficients[-1]))
tx=as.matrix(pr[,-c(indices,i_output)]);ty=as.matrix(pr[,i_output])
lasso.model=enet(tx,ty,lambda=0)  #enet con lambda=0 performs Lasso fit (different to ridge)
rm(tx);tx=as.matrix(pv[,-c(indices,i_output)])
t=predict(lasso.model,tx,type='fit')$fit;sr=t[,ncol(t)];
rm(lm.model,tx,ty,indices,lasso.model,t,u)
