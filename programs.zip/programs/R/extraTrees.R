# options(java.parameters = "-Xmx16g")  #replaced by "export _JAVA_OPTIONS=-Xmx16G"
require(extraTrees,quietly=T)
extraTrees.model=extraTrees(pr[,-i_output],pr[,i_output],mtry=val_par1,numRandomCuts=val_par2)
sr=predict(extraTrees.model,pv[,-i_output])
if(sd(sr)==0) stop('constant predicted output')
rm(extraTrees.model)