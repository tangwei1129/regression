require(arm,quietly=T)
bayesglm.model=bayesglm(output ~ ., data=pr)
sr=as.numeric(predict(bayesglm.model,pv))
rm(bayesglm.model)
