fprintf(str);fprintf('%6.2f%%',100*iexp/nexp);iexp=iexp+1;
