function [x input_name]=read_data_table(data)
nf=sprintf('../data/%s/%s.txt',data,data);f=open_file(nf,'r');
fscanf(f,'%s',1);np=fscanf(f,'%i',1);
fscanf(f,'%s',1);ni=fscanf(f,'%i',1);
fclose(f);x=zeros(np,ni+1);input_name=cell(1,ni);
nf=sprintf('../data/%s/%s_R.dat',data,data);
f=open_file(nf,'r');
for i=1:ni
    input_name{i}=fscanf(f,'%s ',1);
end
fscanf(f,'%s',1);
for i=1:np
    fscanf(f,'%s ',1);x(i,:)=fscanf(f,'%g',ni+1);
end
fclose(f);
end