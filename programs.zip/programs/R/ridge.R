require(elasticnet,quietly=TRUE)
tx=as.matrix(pr[,-i_output]);ty=as.matrix(pr[,i_output])
lm.model=lm(output~.,data=pr);indices=which(is.finite(lm.model$coefficients[-1]))
ridge.model=enet(tx[,indices],ty,lambda=val_par1)
rm(tx,ty);tx=as.matrix(pv[,-i_output])
y=predict(ridge.model,newx=tx[,indices],type='fit')
sr=y$fit[,max(y$s)]
rm(lm.model,indices,ridge.model,tx,y)
