# options(java.parameters="-Xmx32g")  #replaced by "export _JAVA_OPTIONS=-Xmx32G"
require(bartMachine,quietly=T)
bartMachine.model=bartMachine(pr[,-i_output],pr[,i_output],num_trees=val_par1,k=val_par2,alpha=val_par3,verbose=F,mem_cache_for_speed
=F)
sr=predict(bartMachine.model,pv[,-i_output])
if(sd(sr)==0) stop('constant predicted output')
rm(bartMachine.model)
