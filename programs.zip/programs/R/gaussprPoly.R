require(kernlab,quietly=TRUE)
sink('/dev/null')
gaussprPoly.model=gausspr(output ~ . ,data=pr,kernel='polydot',kpar=list(degree=val_par1,scale=val_par2))
sr=predict(gaussprPoly.model,pv)
while(sink.number()>0) { sink(NULL) }
rm(gaussprPoly.model)
