#!/bin/bash

# complete list of 84 datasets
dataset_list=(daily_demand slump slump_comp slump_flow gps_trajectory servo automobile com_hd csm1415 stock_abs stock_annual stock_excess stock_rel stock_systematic stock_total yacht_hydro student_mat auto_mpg housing facebook_metrics forestfires stock_exchange student_por bike_day energy_cool energy_heat compress_stren park_speech geo_lat geo_long geo_music_lat geo_music_long air_quality_CO air_quality_NMHC air_quality_NO2 air_quality_NOx air_quality_O3 airfoil com_crime gas_drift gas_dynamic_CO gas_dynamic_methane com_crime_unnorm SML2010 park_motor_UPDRS park_total_UPDRS combined_cycle cond_turbine UJ_lat UJ_long bike_hour appliances_energy pm25_beijing_dongsihuan pm25_shenyang_us_post pm25_guangzhou_5th_middle_school pm25_shanghai_jingan pm25_shenyang_taiyuanji pm25_chengdu_caotangsi pm25_shanghai_xuhui pm25_chengdu_shahepu pm25_shenyang_xiaoheyan pm25_beijing_nongzhanguan pm25_beijing_dongsi pm25_chengdu_us_post pm25_shanghai_us_post pm25_guangzhou_city_station pm25_guangzhou_us_post online_news facebook_comment beijing_pm25 physico_protein pm25_beijing_us_post KEGG_relation CT_slices blog_feedback cuff_less KEGG_reaction video_transcode dynamic_features 3Droad year_prediction buzz_twitter greenhouse_net household_consume)

dataset_list=(slump slump_comp slump_flow gps_trajectory servo automobile com_hd csm1415 stock_abs stock_annual stock_excess stock_rel stock_systematic stock_total yacht_hydro student_mat auto_mpg housing facebook_metrics forestfires stock_exchange student_por bike_day energy_cool energy_heat compress_stren park_speech geo_lat geo_long geo_music_lat geo_music_long air_quality_CO air_quality_NMHC air_quality_NO2 air_quality_NOx air_quality_O3 airfoil com_crime gas_drift gas_dynamic_CO gas_dynamic_methane com_crime_unnorm SML2010 park_motor_UPDRS park_total_UPDRS combined_cycle cond_turbine UJ_lat UJ_long bike_hour appliances_energy pm25_beijing_dongsihuan pm25_shenyang_us_post pm25_guangzhou_5th_middle_school pm25_shanghai_jingan pm25_shenyang_taiyuanji pm25_chengdu_caotangsi pm25_shanghai_xuhui pm25_chengdu_shahepu pm25_shenyang_xiaoheyan pm25_beijing_nongzhanguan pm25_beijing_dongsi pm25_chengdu_us_post pm25_shanghai_us_post pm25_guangzhou_city_station pm25_guangzhou_us_post online_news facebook_comment beijing_pm25 physico_protein pm25_beijing_us_post KEGG_relation CT_slices blog_feedback cuff_less KEGG_reaction video_transcode dynamic_features buzz_twitter greenhouse_net)
n_dataset=${#dataset_list[@]}

# complete list of 78 models
# model_list=(lm glm lm dnn Boruta dlkeras elm_kernel enpls.fs bstSm grnn blackboost glmnet earth rpart bagEarth kernelpls simpls rlm ridge nnls lars pcr avNNet lasso ppr glmStepAIC krlsRadial xgbTree foba rf superpc gam gaussprLinear gaussprRadial rvmRadial svr kknn rqlasso treebag bayesglm spls gaussprPoly cforest cubist nodeHarvest gbm qrf rqnc RRF penalized icr relaxo extraTrees bag M5 rbf SBC glmboost elm spikeslab svmRadial pcaNNet ctree2 plsRglm bdk brnn xgbLinear gamboost mlpWeightDecay randomGLM partDSA bartMachine evtree BstLm bstTree mlpWeightDecayML qrnn widekernelpls)
model_list=(lm)
n_model=${#model_list[@]}

n_exp=`expr $n_dataset \* $n_model`
i_exp=0

for model in ${model_list[*]}; do
	for dataset in  ${dataset_list[*]}; do
		implem='R'
		if [ $model == 'svr' ]; then
			implem='C'
		elif [ $model == 'grnn' ]; then
			implem='matlab'
		elif [ $model == 'elm_kernel' ]; then
			implem='matlab'
		elif [ $model == 'dlkeras' ]; then
			implem='python'
		fi

		let i_exp=i_exp+1
		dir=../results/${dataset}/${model}_${implem}
		mkdir ${dir}/copy 2> /dev/null
		rm -rf ${dir}/copy/* 2> /dev/null
		cp ${dir}/* ${dir}/copy 2> /dev/null

		qsub scripts/${dataset}/${model}_${dataset}.sh
		echo 'submitted' $model $dataset $i_exp '/' $n_exp
 		exit
		sleep 5		
	done
done