require(stats,quietly=T)
ppr.model=ppr(output ~. ,data=pr,nterms=val_par1)
sr=predict(ppr.model,pv)
rm(ppr.model)