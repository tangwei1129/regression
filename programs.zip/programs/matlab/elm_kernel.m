function sr = elm_kernel(pe, de, pv, dv, C, sigma, ~, ~)
% escala as entradas en [-1,1]: se non, da resultados moi malos
u = [pe pv]; umin=min(u'); umax=max(u'); rango=umax - umin; clear u
n_entradas=size(pe,1);
for i=1:n_entradas
	if rango(i)~=0
		pe(i,:)=(pe(i,:) - umin(i))/rango(i);
		pv(i,:)=(pv(i,:) - umin(i))/rango(i);
	end
end
clear umin max rango
sr = codigo_elm_kernel([de; pe]', [dv; pv]', 0, C, 'RBF_kernel', sigma);
end
