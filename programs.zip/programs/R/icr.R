require(caret,quietly=T)
# cr=c(apply(pr[,-i_output],MARGIN=2,function(x) max(x,na.rm=TRUE)==min(x,na.rm=TRUE)),i_output)
# icr.model=icr(pr[,!cr],pr[,i_output],n.comp=val_par1)
# sr=predict(icr.model,pv[,!cr])
lm.model=lm(output~.,pr);indices=which(is.na(lm.model$coefficients[-1]))
npred=ncol(pr[,-c(indices,i_output)]);if(val_par1>npred-1) val_par1=npred-1
icr.model=icr(pr[,-c(indices,i_output)],pr[,i_output],n.comp=val_par1)
sr=predict(icr.model,pv[,-c(indices,i_output)])
rm(lm.model,indices,icr.model)

