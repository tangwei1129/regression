require(spikeslab,quietly=T)
spikeslab.model=spikeslab(output ~ ., data=pr,max.var=val_par1)
sr=predict(spikeslab.model,pv)$yhat.bma  #tamén hai yhat.gne (generalized elastic net)
rm(spikeslab.model)
