function write_result_table(val,nf,error_flag,model_list,dataset_list)
nmodel=numel(model_list);ndata=numel(dataset_list);vmax=1;
for i=1:ndata
    vmax=max(vmax,numel(dataset_list{i}));
end
if vmax>35
    error('write_result_table: dataset name longer than 35: change the column width')
end
f=open_file(nf,'w');fprintf(f,'%30s ','');
fprintf(f,'%35s ',dataset_list{:});fprintf(f,'\n');
for i=1:nmodel
    fprintf(f,'%35s ',model_list{i});
    for j=1:ndata
        if error_flag(i,j)==1
            fprintf(f,'%35s ','NaN');
        else
            fprintf(f,'%35f ',val(i,j));
        end
    end
    fprintf(f,'\n');
end
fclose(f);
end