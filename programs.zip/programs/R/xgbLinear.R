require(xgboost,quietly=T)
p=list(booster='gblinear',lambda=val_par1,alpha=val_par2,silent=1,objective='reg:linear',eval_metric='rmse')
u=as.matrix(pr);t=xgb.DMatrix(u[,-i_output],label=u[,i_output])
xgb.model=xgb.train(params=p,data=t,nrounds=val_par3);rm(p,u,t)
# u=as.matrix(apply(pv[,-i_output],c(1,2),as.numeric))  #required for some datasets
u=as.matrix(pv)   # for most datasets
t=xgb.DMatrix(u[,-i_output]);sr=predict(xgb.model,t)
if(any(is.nan(sr))) stop(sprintf('partition %i: NaN values in sr',l))
if(any(is.na(sr))) stop(sprintf('partition %i: NA values in sr',l))
if(sd(sr)==0) stop('constant predicted output')
rm(u,xgb.model)
