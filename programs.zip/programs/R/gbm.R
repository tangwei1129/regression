require(gbm)
gbm.model=gbm(output~.,data=pr,distribution='gaussian',interaction.depth=val_par1,n.trees=val_par2,shrinkage=val_par3,n.minobsinnode = 5)
sr=predict(gbm.model,pv,n.trees=val_par2)
rm(gbm.model)
