# dataset_list=c('slump_comp', 'slump_flow', 'com_hd', 'slump', 'yacht_hydro', 'servo', 'gps_trajectory', 'housing', 'wpbc', 'energy_heat', 'stock_exchange', 'auto_mpg', 'forestfires', 'energy_cool', 'compress_stren', 'air_quality_NO2', 'air_quality_NMHC', 'air_quality_O3', 'automobile', 'air_quality_NOx', 'air_quality_CO', 'park_speech', 'student_mat', 'UJ_MagLine_long', 'UJ_MagLine_lat', 'household_consume', 'bike_day', 'student_por', 'park_motor_UPDRS', 'cond_turbine', 'SML2010', 'park_total_UPDRS', 'KEGG_reaction', 'KEGG_relation', 'video_transcode', 'geo_music_long', 'physico_protein', 'online_news', 'geo_music_lat', 'bike_hour', 'geo_lat', 'geo_long', 'buzz_twitter', 'com_crime', 'com_crime_unnorm', 'greenhouse_net', 'CT_slices', 'blog_feedback', 'UJ_long', 'UJ_lat', '3Droad', 'airfoil', 'appliances_energy', 'combined_cycle', 'cuff_less', 'facebook_comment', 'facebook_metrics', 'gas_dynamic_CO', 'gas_dynamic_methane', 'year_prediction')

dataset_list=c('com_crime_unnorm')
ndata=length(dataset_list);j=1

for(data in dataset_list) {
	cat(sprintf('dataset %s %i/%i\n',data,j,ndata))
	x=read.table(sprintf('../../original_data/%s/%s.data',data,data))
	n=ncol(x)-1
	for(i in 1:n) {
		plot(x[,i]);title(sprintf('%s: input %s %i/%i',data,names(x)[i],i,n));readline()
	}
	j=j+1
}