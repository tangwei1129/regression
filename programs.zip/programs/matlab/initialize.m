RandStream.setGlobalStream(RandStream('mcg16807','Seed',0));  % inicializa o xerador de números aleatorios
global dataset

% read command-line args------------------------------------------------

% fprintf('nargin= %i\n', nargin);
% for j=1:nargin
%     disp(varargin{j})
% end

j=1;
basedir= varargin{j}; j=j+1;
resultsdir= varargin{j}; j=j+1;
dataset= varargin{j}; j=j+1;
model= varargin{j}; j=j+1;
f_res=sprintf('%s/results_%s_matlab_%s.dat',resultsdir,model,dataset);
n_par= str2double(varargin{j}); j=j+1;
%  fprintf('basedir= %s dataset= %s model= %s n_par= %g\n', basedir, dataset, model, n_par);exit
if n_par > 0
    par1_name = varargin{j}; j=j+1;
    n_val1 = str2double(varargin{j}); j=j+1;
    val1 = zeros(1,n_val1);
    for i=1:n_val1
        val1(i) = str2double(varargin{j}); j=j+1;
    end
%     fprintf('par1_name= %s: %i values: ', par1_name, n_val1);
%     fprintf('%g ', val1);
%     fprintf('\n');
    if n_par > 1
        par2_name = varargin{j}; j=j+1;
        n_val2 = str2double(varargin{j});  j=j+1;
        val2 = zeros(1,n_val2);
        for k=1:n_val2
            val2(k) = str2double(varargin{j}); j=j+1;
        end
%         fprintf('par2_name= %s: %i values: ', par2_name, n_val2);
%         fprintf('%g ', val2);
%         fprintf('\n');
    end
    if n_par > 2
        par3_name = varargin{j}; j=j+1;
        n_val3 = str2double(varargin{j});  j=j+1;
        val3 = zeros(1,n_val3);
        for k=1:n_val3
            val3(k) = str2double(varargin{j}); j=j+1;
        end
%         fprintf('par3_name= %s: %i valores: ', par3_name, n_val3);
%         fprintf('%g ', val3);
%         fprintf('\n');
    end
end
interactive= str2double(varargin{j});


% read dataset info------------------------------------------------
fich=sprintf('%s/data/%s/%s.txt', basedir, dataset, dataset);
fp=open_file(fich,'r');
fscanf(fp, '%s', 1); np= fscanf(fp, '%i', 1);
fscanf(fp, '%s', 1); ni= fscanf(fp, '%i', 1);
f_data=sprintf('%s_R.dat', dataset);
fclose(fp);

if np<=10000
    ntrials=500;
else
    ntrials=10;
end

% read patterns------------------------------------------------
nf=sprintf('%s/data/%s/%s', basedir, dataset, f_data);
fp=open_file(nf, 'r');
x=zeros(ni,np); d=zeros(1,np);
fscanf(fp,'\t');fscanf(fp,'%s\t',ni);fscanf(fp,'%s\n',1);
for i=1:np
    fscanf(fp,'%i\t',1);
    x(1:ni,i)=fscanf(fp,'%f\t',ni)';d(i)=fscanf(fp,'%f\n',1);
end
fclose(fp);


% read partitions------------------------------------------------
train_perc=70;
valid_perc=20;

npr=floor(train_perc*np/100);
npv=floor(valid_perc*np/100);
npt=np-npr-npv;

f_partitions=sprintf('%s/data/%s/%s_partitions.dat', basedir, dataset, dataset);
fp=open_file(f_partitions, 'r');
xr=zeros(ntrials,npr);xv=zeros(ntrials,npv);xt=zeros(ntrials,npt);
for i = 1:ntrials
    xr(i,:)=fscanf(fp, '%i',npr);
    xv(i,:)=fscanf(fp, '%i',npv);
    xt(i,:)=fscanf(fp, '%i',npt);
end
fclose(fp);


% misc operations------------------------------------------------
f = open_file(f_res, 'w');
fprintf(f, '#processing %s with model %s file= %s ...\n', dataset, model, f_data);

nexp_teste= ntrials;

switch n_par
    case 0
        nexp = nexp_teste;
    case 1
        nexp = n_val1*ntrials + nexp_teste;
    case 2
        nexp = n_val1*n_val2*ntrials + nexp_teste;
    case 3
        nexp = n_val1*n_val2*n_val3*ntrials + nexp_teste;
end
iexp = 0;
best_par1 = 0; best_par2 = 0; best_par3 = 0;

rmse=zeros(1,ntrials);
