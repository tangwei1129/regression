require(kknn,quietly=T)
kknn.model=kknn(output ~ . ,train=pr,test=pv,k=val_par1)
sr=fitted(kknn.model)
rm(kknn.model)
