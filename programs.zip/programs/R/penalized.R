require(penalized,quietly=T)
#data=x debe ser substituido por data=pr
penalized.model=penalized(output ~ . ,data=x,lambda1=val_par1,lambda2=val_par2,trace=F)
sr=predict(penalized.model,pv[,-i_output])[,1]
rm(penalized.model)