clear all
clc
addpath('matlab')

model_list={'elm_kernel','svr','elm','nnls','svmRadial','rpart','lm','gbm','bdk','avNNet','ctree2','widekernelpls','enet','plsRglm','extraTrees','glmboost','pcaNNet','icr','rqnc','relaxo','foba','penalized','spls','ppr','superpc','dnn','gaussprPoly','gaussprLinear','rqlasso','pcr','kknn','RRF','krlsRadial','kernelpls','gam','lars','glmnet','simpls','earth','M5','mlpWeightDecay','ridge','gaussprRadial','lasso','evtree','rf','rlm','BstLm','bayesglm','rvmRadial','rbf','cforest','cubist','glmStepAIC','blackboost','qrf','grnn','SBC','partDSA','treebag','bag','mlpWeightDecayML','brnn','bagEarth','bartMachine','gamboost','bstTree','randomGLM','spikeslab','dlkeras','Boruta','xgbLinear','enpls.fs','nodeHarvest','bstSm','xgbTree','qrnn'};
model_list2={'kelm','svr','elm','nnls','svmRad','rpart','lm','gbm','bdk','avNNet','ctree2','wkpls','enet','plsRglm','extraTrees','glmboost','pcaNNet','icr','rqnc','relaxo','foba','penalized','spls','ppr','superpc','dnn','gprPol','gprLin','rqlasso','pcr','kknn','RRF','krlsRad','kpls','gam','lars','glmnet','simpls','earth','M5','mlpWD','ridge','gprRad','lasso','evtree','rf','rlm','BstLm','bayesglm','rvmRad','rbf','cforest','cubist','glmSAIC','blackboost','qrf','grnn','SBC','partDSA','treebag','bag','mlpWDml','brnn','bagEarth','bMachine','gamboost','bstTree','rndGLM','spikeslab','dlkeras','Boruta','xgbLinear','enpls.fs','nodeHarvest','bstSm','xgbTree','qrnn'};
nmodel=numel(model_list);

implem_list=cell(1,nmodel);
for i=1:nmodel
    implem_list{i}=get_implem(model_list{i});
end

global_dataset_list={};global_dataset_list2={};
ndata=0;
r2=[];rmse=[];mae=[];error_flag=[];

mem=[];time=[];nspc=7;
fprintf(repmat(' ',1,nspc));str=repmat('\b',1,nspc);
ndata=84;iexp=1;nexp=ndata*nmodel;ndata=0;
maxtime=48*3600;  %maxtime=maximum allowed time (48 hours, 172800 sec.)
max_npart=500;train_perc=70;valid_perc=20;
ngroup=4;n_time_errors=zeros(1,nmodel);n_mem_errors=zeros(1,nmodel);

for group=1:ngroup
    if group==1    % 20 datasets in group 1
        dataset_list={'slump','slump_flow','gps_trajectory','csm1415','stock_abs',...
            'stock_annual','stock_excess','stock_rel','stock_systematic','stock_total',...
            'student_mat','forestfires','student_por','park_speech','geo_lat','geo_long',...
            'geo_music_lat','geo_music_long','airfoil','com_crime_unnorm'};
        dataset_list2={'slump','slump-flow','gps-trajectory','csm1415','stock-abs',...
            'stock-annual','stock-excess','stock-rel','stock-syst','stock-total',...
            'student-mat','forestfires','student-por','park-speech','geo-lat','geo-long',...
            'geo-music-lat','geo-music-long','airfoil','com-crime-un'};
    elseif group==2   % 23 datasets in group 2
        dataset_list={'daily_demand','slump_comp','servo','automobile','com_hd',...
            'yacht_hydro','auto_mpg','housing','facebook_metrics','stock_exchange',...
            'bike_day','energy_cool','energy_heat','compress_stren','air_quality_CO',...
            'air_quality_NMHC','air_quality_NO2','air_quality_NOx','air_quality_O3',...
            'com_crime','gas_dynamic_CO','gas_dynamic_methane','SML2010'};
        dataset_list2={'daily-demand','slump-comp','servo','automobile','com-hd',...
            'yacht-hydro','auto-mpg','housing','fb-metrics','stock-exchange',...
            'bike-day','energy-cool','energy-heat','compress-stren','air-CO',...
            'air-NMHC','air-NO2','air-NOx','air-O3','com-crime','gas-CO','gas-methane','SML2010'};
    elseif group==3   % 33 datasets in group 3
        dataset_list={'park_motor_UPDRS','park_total_UPDRS','appliances_energy',...
            'pm25_beijing_dongsihuan','pm25_shenyang_us_post','pm25_guangzhou_5th_middle_school',...
            'pm25_shanghai_jingan','pm25_shenyang_taiyuanji','pm25_chengdu_caotangsi',...
            'pm25_shanghai_xuhui','pm25_chengdu_shahepu','pm25_shenyang_xiaoheyan',...
            'pm25_beijing_nongzhanguan','pm25_beijing_dongsi','pm25_chengdu_us_post',...
            'pm25_shanghai_us_post','pm25_guangzhou_city_station','pm25_guangzhou_us_post',...
            'online_news','facebook_comment','beijing_pm25','physico_protein',...
            'pm25_beijing_us_post','KEGG_relation','blog_feedback','cuff_less',...
            'video_transcode','dynamic_features','3Droad','year_prediction',...
            'buzz_twitter','greenhouse_net','household_consume'};
        dataset_list2={'pm-UPDRS','pt-UPDRS','app-energy',...
            'beijing-dongsihuan','shenyang-us','guangzhou-5ms',...
            'shanghai-jingan','shenyang-taiyuanji','chengdu-caotangsi',...
            'shanghai-xuhui','chengdu-shahepu','shenyang-xiaoheyan',...
            'beijing-nongzhanguan','beijing-dongsi','chengdu-us',...
            'shanghai-us','guangzhou-city','guangzhou-us',...
            'online-news','fb-comment','beijing-pm25','physico-protein',...
            'pm25-beijing-us-post','KEGG-relation','blog-feedback','cuff-less',...
            'video-transcode','dynamic-features','3Droad','year-prediction',...
            'buzz-twitter','greenhouse-net','household-consume'};
    elseif group==4  % 7 datasets in group 4
        dataset_list={'combined_cycle','cond_turbine','UJ_lat','UJ_long',...
            'bike_hour','CT_slices','KEGG_reaction'};
        dataset_list2={'combined_cycle','cond-turbine','UJ-lat','UJ-long',...
            'bike-hour','CT-slices','KEGG-reaction'};
    end

    nf=sprintf('../results/REPORTS/dataset_group%i/table_r2_group%i.dat',group,group);
    [r2_group error_group]=read_result_table(nf,model_list,dataset_list);
    nf=sprintf('../results/REPORTS/dataset_group%i/table_rmse_group%i.dat',group,group);
    [rmse_group ~]=read_result_table(nf,model_list,dataset_list);
    nf=sprintf('../results/REPORTS/dataset_group%i/table_mae_group%i.dat',group,group);
    [mae_group ~]=read_result_table(nf,model_list,dataset_list);
    nf=sprintf('../results/REPORTS/dataset_group%i/table_time_group%i.dat',group,group);
    [time_group ~]=read_result_table(nf,model_list,dataset_list);
    
    ndata_group=numel(dataset_list);
    for i=1:ndata_group
        ndata=ndata+1;global_dataset_list{ndata}=dataset_list{i};
        global_dataset_list2{ndata}=dataset_list2{i};
        dataset=dataset_list{i};[x ~]=read_data_table(dataset);[np ni]=size(x);
        npr=floor(train_perc*np/100);npv=floor(valid_perc*np/100);npt=np-npr-npv;
        nf=sprintf('../results/%s/lm_R/plot_lm_%s.dat',dataset,dataset);y=load(nf);d=y(:,1);
        nf=sprintf('../data/%s/%s_partitions.dat',dataset,dataset);part=load(nf);npart=size(part,1);
        if npt~=numel(d)/npart
            error('%s: npt=%i /= numel(d)=%i\n',dataset,npt,numel(d))
        end
        ini=1;fin=ini+npt-1;dif=zeros(1,npt);
        for j=1:npart
            ind=part(j,1:npr);t=ini:fin;
            dif(t)=bsxfun(@minus,d(t),mean(x(ind,ni)));
            ini=ini+npt;fin=ini+npt-1;
        end
        def_rmse=sqrt(sum(dif.^2)/npt);def_mae=sum(abs(dif))/npt;
        ind1=find(~error_group(:,i));ind2=find(error_group(:,i));
        if numel(ind1)==0
            error('dataset %s: error in all models',dataset)
        end
        r2_group(ind2,i)=0;
        max_rmse=max(rmse_group(ind1,i));rmse_group(ind2,i)=max(max_rmse,def_rmse);
        max_mae=max(mae_group(ind1,i));mae_group(ind2,i)=max(max_mae,def_mae);
    end
    r2=[r2 r2_group];rmse=[rmse rmse_group];mae=[mae mae_group];
    error_flag=[error_flag error_group];time=[time time_group];
    
    mem_group=zeros(nmodel,ndata_group);
    for i=1:nmodel
        model=model_list{i};implem=implem_list{i};
        for j=1:ndata_group
            dataset=dataset_list{j};
            cmd=sprintf('grep ppn scripts/%s/%s_%s.sh |cut -d= -f3|cut -d, -f1',...
                dataset,model,dataset);
            [~,output]=system(cmd);output(output=='''')='';
            mem_group(i,j)=2*str2double(output);
            fprintf(str);fprintf('%6.2f%%',100*iexp/nexp);iexp=iexp+1;
        end
        % read number of time errors
        cmd=sprintf('grep '' %s '' ../results/REPORTS/dataset_group%i/errors_group%i.txt | grep walltime | wc -l',...
            model,group,group);
        [~,output]=system(cmd);nerr=str2double(output);
        n_time_errors(i)=n_time_errors(i)+nerr;
        % read number of memory errors
        cmd=sprintf('grep '' %s '' ../results/REPORTS/dataset_group%i/errors_group%i.txt | grep memory | wc -l',...
            model,group,group);
        [~,output]=system(cmd);nerr=str2double(output);
        n_mem_errors(i)=n_mem_errors(i)+nerr;
    end
    mem=[mem mem_group];
end
fprintf('\n')

nf='../results/REPORTS/global/table_r2_global.dat';
write_result_table(r2,nf,zeros(nmodel,ndata),model_list,global_dataset_list);

time(isnan(time))=maxtime;

% model list according to R^2 Friedman rank
r2_rank=friedman_rank(r2,'descend');[~,r2_ind]=sort(r2_rank);
nf='../results/REPORTS/global/friedman_rank_r2.dat';f=open_file(nf,'w');
for i=1:nmodel
    j=r2_ind(i);fprintf(f,'%3i: %20s: %5.1f\n',i,model_list{j},r2_rank(j));
end
fclose(f);
% model list according RMSE Friedman ranking
nf='../results/REPORTS/global/friedman_rank_rmse.dat';f=open_file(nf,'w');
rmse_rank=friedman_rank(rmse,'ascend');[~,rmse_ind]=sort(rmse_rank);
fprintf(f,'Friedman rank RMSE:\n');
for i=1:nmodel
    j=rmse_ind(i);fprintf(f,'%3i: %20s: %5.1f\n',i,model_list{j},rmse_rank(j));
end
fclose(f);
% model list according MAE Friedman ranking
nf='../results/REPORTS/global/friedman_rank_mae.dat';f=open_file(nf,'w');
mae_rank=friedman_rank(mae,'ascend');[~,mae_ind]=sort(mae_rank);fprintf(f,'Friedman rank MAE:\n');
for i=1:nmodel
    j=mae_ind(i);fprintf(f,'%3i: %20s: %5.1f\n',i,model_list{j},mae_rank(j));
end
fclose(f);
% model list by increasing number of datasets with errors
errors_model=sum(error_flag,2);[~,i]=sort(errors_model);
nf='../results/REPORTS/global/models_by_errors.dat';f=open_file(nf,'w');
fprintf(f,'%10s %20s %10s\n','No.','Model','Errors');
for j=1:nmodel
    k=i(j);fprintf(f,'%10i: %20s %10i\n',j,model_list{k},errors_model(k));
end
fclose(f);
% number of datasets where each regressor achieves the best R^2
nf='../results/REPORTS/global/number_best_r2_model.dat';f=open_file(nf,'w');
[r2_max i_max]=max(r2);nbest=zeros(1,nmodel);
for i=1:ndata
    j=i_max(i);nbest(j)=nbest(j)+1;
end
[~,nbest_ind]=sort(nbest,'descend');n=sum(nbest>0);
for i=1:n
    j=nbest_ind(i);
    fprintf(f,'%3i: %20s %i\n',i,model_list{j},nbest(j));
end
fprintf(f,'total datasets= %i\n',sum(nbest));
fclose(f);

% TEX table with R^2 Friedman ranks
nf='../results/REPORTS/global/table_global.tex';f=open_file(nf,'w');
err_perc=100*errors_model/ndata;best_perc=100*nbest/ndata;
fprintf(f,'\\begin{tabular}{|c||c|c|c||c|c||c|c||c|c|}\n');fprintf(f,'\\hline\n');
fprintf(f,'& \\multicolumn{3}{c||}{$R^2$} & \\multicolumn{2}{c||}{RMSE} & \\multicolumn{2}{c||}{MAE} & \\multicolumn{2}{c|}{Best $R^2$} \\\\ \\hline \n');
fprintf(f,'Pos. & Model & Rank & \\%%Error & Model & Rank & Model & Rank & Model & \\%%Best\\\\ \\hline \\hline \n');
for i=1:20
    r2i=r2_ind(i);rmsei=rmse_ind(i);maei=mae_ind(i);nbesti=nbest_ind(i);
    if best_perc(nbesti)>0
        fprintf(f,'%i & %s & %.2f & %.1f & %s & %.2f & %s & %.2f & %s & %.1f \\\\ ',i,...
            model_list2{r2i},r2_rank(r2i),err_perc(r2i),model_list2{rmsei},...
            rmse_rank(rmsei),model_list2{maei},mae_rank(maei),...
            model_list2{nbesti},best_perc(nbesti));
    else
        fprintf(f,'%i & %s & %.2f & %.1f & %s & %.2f & %s & %.2f & --- & --- \\\\ ',i,...
            model_list2{r2i},r2_rank(r2i),err_perc(r2i),model_list2{rmsei},...
            rmse_rank(rmsei),model_list2{maei},mae_rank(maei));
    end
    if i==10
        fprintf(f,'\\cline{1-8} \n');
    else
        fprintf(f,'\n');
    end
end
fprintf(f,'\\hline \n');fprintf(f,'\\end{tabular}\n');
fclose(f);

% Wilcoxon/T-student-T test comparing the best and the remaining 19 regressors in
% top-20
nf='../results/REPORTS/global/table_tests.tex';f=open_file(nf,'w');
fprintf(f,'\\begin{tabular}{|c|c|c|c|c|c|c|c|}\n');fprintf(f,'\\hline\n');
k=r2_ind(1);x=r2(k,:);p5=load('../results/REPORTS/global/post-hoc-friedman-nemenyi-test.dat');
fprintf(f,'%5s & %20s & %10s & %10s & %10s & %10s & %10s & %10s \\\\ \\hline \\hline \n',...
    'Pos.','Model','Paired T','Dunnett','2-Sample T','Wilcoxon','Sign','Post-Hoc');
%------------------------------------------------------
% n_test_model=20;z=zeros(ndata,n_test_model);
% for i=1:n_test_model
%     j=r2_ind(i);z(:,i)=r2(j,:)';
% end
%------------------------------------------------------
n_test_model=20;z=[];group={};  %Dunnett teste
for i=1:n_test_model
    j=r2_ind(i);z=[z r2(j,:)];group=[group repmat({model_list{j}},1,ndata)];
end
[p,~,stats]=anova1(z,group,'off');p6=dunnett(stats);
%------------------------------------------------------
for i=2:n_test_model
    j=r2_ind(i);y=r2(j,:);
    [~,p1]=ttest(x,y);h1=asterisk(p1);
    [~,p2]=ttest2(x,y);h2=asterisk(p2);
    p3=ranksum(x,y);h3=asterisk(p3);
    p4=signtest(x,y);h4=asterisk(p4);h5=asterisk(p5(i-1));h6=asterisk(p6(i));
    fprintf(f,'%5i & %20s & %6.3f%s & %6.3f%s & %6.3f%s & %6.3f%s & %6.3f%s & %6.3f%s \\\\ \\hline \n',...
        i,model_list2{j},p1,h1,p6(i),h6,p2,h2,p3,h3,p4,h4,p5(i-1),h5);
end
fprintf(f,'\\end{tabular}\n');fclose(f);

% Figure with boxplot or R^2 for the 10 best regressors
nreg=10;t=r2_ind(1:nreg);data=zeros(nreg,ndata);
for i=1:nreg
    data(i,:)=r2_max-r2(t(i),:);
end
clf;boxplot(data','symbol','b.');
xlabel_inclin(model_list2(t),-0.02,1.02,25,18)
ylabel('\Delta=R^2_{best}-R^2','fontsize',18);grid on
print('-depsc','../results/REPORTS/global/boxplot_r2_10best.eps')

%Figure with R^2 of gbm and M5
clf;hold on
r2_gbm=r2(strcmp(model_list,'gbm'),:);
r2_M5=r2(strcmp(model_list,'M5'),:);
[~,i]=sort(r2_max,'descend');
plot(r2_gbm(i),'b-','markerfacecolor','b')
plot(r2_M5(i),'r-','markerfacecolor','r')
plot(r2_max(i),'g-','markerfacecolor','g')
legend({'gbm','M5','Best'},'location','southwest','fontsize',18)
xlabel('Dataset','fontsize',18);ylabel('R^2','fontsize',18);grid on
axis([0 ndata+1 -0.02 1.02])
print('-depsc','../results/REPORTS/global/r2_gbm_M5.eps')

%Histogram of differences M5-gbm
clf;dif=r2_M5-r2_gbm;
nval=20;hist(dif,nval);grid on
axis([min(dif)-0.05 max(dif)+0.05 0 26])
ipos=dif>0;npos=sum(ipos);sumpos=sum(dif(ipos));
ineg=dif<0;nneg=sum(ineg);sumneg=sum(dif(ineg));
xlabel('\delta = R^2_{M5} - R^2_{gbm}','fontsize',18);ylabel('#Datasets','fontsize',18);
text(0.1,15,sprintf('\\delta > 0 for %3.0f%% of datasets',100*npos/ndata),'fontsize',18)
text(0.1,12,sprintf('\\Sigma_{\\delta > 0} \\delta = %5.1f',sumpos),'fontsize',18)
text(0.1,10,sprintf('\\Sigma_{\\delta \\leq 0} \\delta = %5.1f',sumneg),'fontsize',18)
print('-depsc','../results/REPORTS/global/histogram_gbm_M5.eps')

% plot of R^2_max - R^2_M5 vs. R^2_max
clf;dif=r2_max-r2_M5;
plot(r2_max,dif,'bs','markerfacecolor','b');grid on
xlabel('R^2_{best}','fontsize',18);ylabel('R^2_{best} - R^2_{M5}','fontsize',18);
axis([0 1.02 -0.02 0.4])
print('-depsc','../results/REPORTS/global/dif_r2_best_r2_M5.eps')

% scatter plot of M5 and penalized (best R^2) for dataset student_mat,
% where R^2_max - R^2_M5 is maximum
x=load('../results/student_mat/M5_R/plot_M5_student_mat.dat');
y=load('../results/student_mat/penalized_R/plot_penalized_student_mat.dat');
clf;plot(x(:,2),x(:,1),'.b');hold on
plot(y(:,2),y(:,1),'.g');
plot([0 9],[0 9],'r-')
axis([0 9 0 9]);grid on
xlabel('Predicted output','fontsize',18);ylabel('True output','fontsize',18);
legend({'M5','penalized'},'location','East','fontsize',18)
i_penalized=22;i_M5=find(strcmp(model_list,'M5'));i_student_mat=11;
text(5.5,1,sprintf('R^2_{best}=%.4f (penalized)',r2(i_penalized,i_student_mat)),'fontsize',18)
text(5.5,2,sprintf('R^2_{M5}=%.4f',r2(i_M5,i_student_mat)),'fontsize',18)
print('-depsc','../results/REPORTS/global/scatterplot_M5_penalized_student_mat.eps')

% Figure with R^2 and time Friedman rank
time_rank=friedman_rank(time,'ascend');
t=1:20;u=r2_ind(t);name=model_list2(u);
clf;plot(r2_rank(u),time_rank(u),'sb','MarkerFaceColor','b');hold on
dx=zeros(1,20);dy=2*ones(1,20);
dx(1)=-4;dy(1)=-1; %cubist
dx(3)=-2;dy(3)=-3; %bstTree
dy(5)=-1; %avNNet
dx(6)=-3; %extraTrees
dx(7)=-1; %qrf
dx(10)=-2; %rf
dx(12)=-2;dy(12)=3; %svr
dy(13)=-2;  %ppr
dx(15)=0;dy(15)=3;dy(17)=2; %blackboost
dx(16)=-1;%kknn
dx(17)=0;dy(17)=-1; %penalized
dy(20)=-2;  %grnn
for i=t
    j=u(i);text(r2_rank(j)+dx(i),time_rank(j)+dy(i),name{i},'fontsize',18)
end
grid on
axis([0 35 0 70])
xlabel('R^2 Friedman rank','fontsize',18);ylabel('Time Friedman rank','fontsize',18);
print('-depsc','../results/REPORTS/global/r2_time_ranking.eps')

% file with average times
pte=100*n_time_errors/ndata;
nf='../results/REPORTS/global/standard_time.dat';f=open_file(nf,'w');
i_standard=find(strcmp(global_dataset_list,'compress_stren'));  %because np=1030 and ni=8
[~,time_ind]=sort(time(:,i_standard));
for i=1:nmodel
    j=time_ind(i);
    fprintf(f,'%5i %25s %10.2f %10.2f\n',i,model_list2{j},time(j,i_standard),pte(j));
end
fclose(f);
% Friedman rank of memory consumption
avg_mem=mean(mem,2);mem_rank=friedman_rank(mem,'ascend');[~,mem_ind]=sort(mem_rank);
nf='../results/REPORTS/global/friedman_rank_mem.dat';f=open_file(nf,'w');
for i=1:nmodel
    j=mem_ind(i);
    fprintf(f,'%5i %25s %10.2f %10.2f\n',i,model_list{j},mem_rank(j),avg_mem(j));
end
fclose(f);
% Global table with FR, errors, times and memory
nf='../results/REPORTS/global/table_complete.tex';f=open_file(nf,'w');
err_perc=100*errors_model/ndata;best_perc=100*nbest/ndata;
pme=100*n_mem_errors/ndata;
fprintf(f,'\\begin{tabular}{|c|c|c|c|c|c|c|c|c|}\n');fprintf(f,'\\hline\n');
fprintf(f,'%5s & %10s & %5s & %5s & %10s & %10s & %20s & %10s & %10s \\\\ \\hline\n',...
    '','','','','','','\#Datasets/mem(GB)','','');
fprintf(f,'%5s & %10s & %5s & %5s & %10s & %10s & %20s & %10s & %10s \\\\ \\hline \\hline \n',...
    'Pos.','Model','Rank','\%Best','\%Error','\%ME','2-4-8-16-32-64-128','\%TE','Time');
add_models={'lars','qrnn','randomGLM'};
ind=r2_ind(1:20)';
for i=1:3
    ind=[ind find(strcmp(model_list,add_models{i}))]; %#ok<AGROW>
end
for i=1:23
    j=ind(i);k=i;
    if best_perc(j)==0
        str_best='';
    else
        str_best=sprintf('%5.1f',best_perc(j));
    end
    if err_perc(j)==0
        str_err='';
    else
        str_err=sprintf('%10.1f',err_perc(j));
    end
    if pme(j)==0
        str_mem='';
    else
        str_mem=sprintf('%10.1f',pme(j));
    end
    t=mem(j,:);str_mem2=sprintf('%i-%i-%i-%i-%i-%i-%i',sum(t==2),sum(t==4),sum(t==8),sum(t==16),...
        sum(t==32),sum(t==64),max(0,sum(t==128)-n_mem_errors(j)));
    if strcmp(model_list{j},'extraTrees') || strcmp(model_list{j},'bartMachine')
        str_mem2=sprintf('%i-%i-%i-0-0-0-0',sum(t<16),sum(t==16),sum(t>16));
    end
    if pte(j)==0
        str_time='';
    else
        str_time=sprintf('%10.1f',pte(j));
    end
    if i>20
        k=find(r2_ind==j);
    end
    if floor(time(j,i_standard))==time(j,i_standard)  % time is integer
        str_time2=sprintf('%10i',time(j,i_standard));
    else   % time is float
        str_time2=sprintf('%10.2f',time(j,i_standard));
    end
    fprintf(f,'%5i & %10s & %5.2f & %5s & %10s & %10s & %20s & %10s & %10s \\\\ \\hline \n',...
        k,model_list2{j},r2_rank(j),str_best,str_err,str_mem,str_mem2,str_time,str_time2);
    if i==20 || i==22
        fprintf(f,'\\hline\n');
    end
end
fprintf(f,'\\end{tabular}\n');
fclose(f);

% R^2 of cubist against r2_max
clf;plot(r2(strcmp(model_list,'cubist'),:),r2_max,'bs','markerfacecolor','b');hold on
plot([0 1],[0 1],'r-');grid on
xlabel('R^2_{cubist}','fontsize',18);ylabel('R^2_{best}','fontsize',18);
print('-depsc','../results/REPORTS/global/r2_cubist_best.eps')

% R^2 of gbm against r2_max
clf;plot(r2(strcmp(model_list,'gbm'),:),r2_max,'bs','markerfacecolor','b');hold on
plot([0 1],[0 1],'r-');grid on
xlabel('R^2 achieved by gbm');ylabel('R^2_{best}');
print('-depsc','../results/REPORTS/global/not_used/r2_gbm_best.eps')

% R^2 of M5 against r2_max
clf;plot(r2(strcmp(model_list,'M5'),:),r2_max,'bs','markerfacecolor','b');hold on
plot([0 1],[0 1],'r-');grid on
xlabel('R^2_{M5}','fontsize',18);ylabel('R^2_{best}','fontsize',18);
print('-depsc','../results/REPORTS/global/r2_M5_best.eps')

% R^2 of bstTree against r2_max
clf;plot(r2(strcmp(model_list,'bstTree'),:),r2_max,'bs','markerfacecolor','b');hold on
plot([0 1],[0 1],'r-');grid on
xlabel('R^2 achieved by bstTree','fontsize',15);ylabel('Best R^2 for each dataset','fontsize',15);
print('-depsc','../results/REPORTS/global/r2_bstTree_best.eps')

% figure global_percentage.eps
nval=50;theta=linspace(0,0.4,nval);
cubist_prob=zeros(1,nval);cubist_dif=r2_max-r2(strcmp(model_list,'cubist'),:);
M5_prob=zeros(1,nval);M5_dif=r2_max-r2(strcmp(model_list,'M5'),:);
gbm_prob=zeros(1,nval);gbm_dif=r2_max-r2(strcmp(model_list,'gbm'),:);
bstTree_prob=zeros(1,nval);bstTree_dif=r2_max-r2(strcmp(model_list,'bstTree'),:);
for l=1:nval
    cubist_prob(l)=100*sum(cubist_dif>theta(l))/ndata;
    gbm_prob(l)=100*sum(gbm_dif>theta(l))/ndata;
    M5_prob(l)=100*sum(M5_dif>theta(l))/ndata;
    bstTree_prob(l)=100*sum(bstTree_dif>theta(l))/ndata;
end
clf;plot(theta,cubist_prob,'b-','markerfacecolor','b');hold on
plot(theta,gbm_prob,'g-','markerfacecolor','g');
plot(theta,bstTree_prob,'k-','markerfacecolor','k');
plot(theta,M5_prob,'r-','markerfacecolor','r');
xlabel('Threshold (\theta) for \Delta','fontsize',18)
ylabel('Percentage of datasets where \Delta = R^2_{best} - R^2 > \theta','fontsize',18)
grid on;legend({'cubist (7 errors)','gbm (1 error)','bstTree (5 errors)','M5 (0 errors)'},...
    'location','northeast','fontsize',18)
print('-depsc','../results/REPORTS/global/global_percentage.eps')

% R2 ranking discarding the 16 pm25 datasets
ind=[4:18 23];r2_pm25=r2;r2_pm25(:,ind)=[];  % ind=indices of pm25 datasets
r2_rank_pm25=friedman_rank(r2_pm25,'descend');[~,r2_ind_pm25]=sort(r2_rank_pm25);
nf='../results/REPORTS/global/table_friedman_rank_r2_global_without_pm25.tex';
f=open_file(nf,'w');nrows=5;j=zeros(1,4);
for i=1:4
    j(i)=1+(i-1)*nrows;
end
fprintf(f,'\\begin{tabular}{|c|c|c||c|c|c||c|c|c||c|c|c|}\n');fprintf(f,'\\hline\n');
fprintf(f,'Pos. & Model & Rank & Pos. & Model & Rank & Pos. & Model & Rank & Pos. & Model & Rank \\\\ \\hline \n \\hline \n');
for i=1:nrows
    for k=1:4
        m=j(k);l=r2_ind_pm25(m);
        if k<4
            fprintf(f,'%3i & %s & %5.1f & ',m,model_list2{l},r2_rank_pm25(l));
        else
            fprintf(f,'%3i & %s & %5.1f \\\\ \\hline \n',m,model_list2{l},r2_rank_pm25(l));
        end
    end
    j=j+1;
end
fprintf(f,'\\end{tabular}\n');
fclose(f);

% figure comparing lm, rlm and R^2_max
i_lm=find(strcmp(model_list,'lm'));i_rlm=find(strcmp(model_list,'rlm'));
r2_lm=r2(i_lm,:);r2_rlm=r2(i_rlm,:);
clf;[~,i]=sort(r2_lm,'descend');
plot(r2_lm(i),'bs-','markerfacecolor','b');hold on
plot(r2_rlm(i),'ro-','markerfacecolor','r')
plot(r2_max(i),'g-');grid on
xlabel('Dataset','fontsize',18);ylabel('R^2','fontsize',18)
legend({'lm','rlm','R^2_{best}'},'location','northeast','fontsize',18)
axis([1 ndata -0.05 1.05])
print('-depsc','../results/REPORTS/global/comparison_lm_rlm.eps')

% r2_M5 against R^2_lm
clf;t=1-r2_lm(i);
plot(t,r2_M5(i),'bs-','markerfacecolor','b','markersize',3);hold on
plot(t,r2_max(i),'r-');grid on
xlabel('1-R^2_{lm}','fontsize',18);ylabel('R^2_{M5}','fontsize',18)
legend({'R^2_{M5}','R^2_{best}'},'location','southwest','fontsize',18)
axis([-0.05 1.05 -0.05 1.05])
print('-depsc','../results/REPORTS/global/r2_M5_vs_lm.eps')

% regressors with errors different to memory and time errors
n_errors=sum(error_flag,2)';
noe=n_errors-n_mem_errors-n_time_errors;
nf='../results/REPORTS/global/regressors_with_errors_not_memory_time.dat';
f=open_file(nf,'w');[~,j]=sort(noe,'descend');
for i=1:nmodel
    k=j(i);
    if noe(k)==0
        break
    end
    fprintf(f,'%i %s %i\n',i,model_list{k},noe(k));
end
fclose(f);

% figura comparando R^2 de M5 e cubist
i=find(strcmp(model_list,'M5'));j=find(strcmp(model_list,'cubist'));
[~,ind]=sort(r2(i,:));clf
plot(r2(i,ind),'b.-');hold on
plot(r2(j,ind),'r.-');grid on
legend({'M5','cubist'},'location','northwest')
xlabel('Dataset');ylabel('R^2')
axis([0 ndata+1 -0.05 1.05])
print('-depsc','../results/REPORTS/global/not_used/r2_M5_cubist.eps')
 
% diagrama de dispersión comparando R^2 de M5 e cubist
clf;plot(r2(i,ind),r2(j,ind),'b.');hold on
plot([0 1],[0 1],'r-');grid on;
xlabel('R^2 achieved by M5');ylabel('R^2 achieved by cubist')
axis([-0.05 1.05 -0.05 1.05])
print('-depsc','../results/REPORTS/global/not_used/scatterplot_r2_M5_cubist.eps')


% TEX table with R^2_max
nf='../results/REPORTS/global/best_r2.tex';f=open_file(nf,'w');
[~,ind]=sort(r2_max,'descend');best_model=cell(1,ndata);
for i=1:ndata
    [~,j]=max(r2(:,i));best_model{i}=model_list2{j};
end
nrow=ceil(ndata/3);i=1;j=i+nrow;k=j+nrow;
fprintf(f,'\\begin{tabular}{|c|c|c||c|c|c||c|c|c|}\n');fprintf(f,'\\hline\n');
fprintf(f,'%40s & %10s & %10s & %40s & %10s & %10s & %40s & %10s & %10s \\\\ \\hline \\hline \n',...
    'Dataset','$R^2_{best}$','Regressor','Dataset','$R^2_{best}$','Regressor','Dataset','$R^2_{best}$','Regressor');
for l=1:nrow
    i1=ind(i);j1=ind(j);
    if k<=ndata
        k1=ind(k);
        fprintf(f,'%40s & %10.3f & %10s & %40s & %10.3f & %10s & %40s & %10.3f & %10s \\\\\\hline \n',...
            global_dataset_list2{i1},r2_max(i1),best_model{i1},global_dataset_list2{j1},r2_max(j1),...
            best_model{j1},global_dataset_list2{k1},r2_max(k1),best_model{k1});
    else
        fprintf(f,'%40s & %10.3f & %10s & %40s & %10.3f & %10s & %40s & %10s & %10s \\\\\\hline \n',...
            global_dataset_list2{i1},r2_max(i1),best_model{i1},global_dataset_list2{j1},r2_max(j1),best_model{j1},'','','');
    end
    i=i+1;j=j+1;k=k+1;
end
fprintf(f,'\\end{tabular}\n');fclose(f);

%percentage of datasets where the best regressor is in the top-10
top={'cubist','gbm','bstTree','M5','avNNet','extraTrees','qrf','pcaNNet','bartMachine','rf',...
    'bagEarth','svr','ppr','earth','blackboost','kknn','penalized','dlkeras','svmRadial','grnn'};
nreg=10;ind=zeros(1,nreg);threshold=0.1;
for i=1:nreg
    ind(i)=find(strcmp(model_list,top{i}));
end
n=0;n2=0;
for i=1:ndata
    j=find(r2_max(i)==r2(:,i));
    for j=1:nreg
        k=ind(j);
        if r2_max(i)-r2(k,i)<threshold
%             fprintf('%s: %s: %f %f\n',global_dataset_list{i},model_list{k},r2_max(i),r2(k,i));
            n=n+1;break
        end
    end
    for j=1:nreg
        k=ind(j);name=model_list{k};
        if r2_max(i)==r2(k,i)
            n2=n2+1;break
        end
    end
end
fprintf('for %.1f%% of datasets some regressor in top-%i achieves R^2_best-%g\n',100*n/ndata,nreg,threshold);
fprintf('for %.1f%% of datasets some regressor in top-%i achieves R^2_best\n',100*n2/ndata,nreg);


% comparison between r2_max, M5 and dlkeras
clf;[~,i]=sort(r2_max,'descend');
i_dlkeras=find(strcmp(model_list,'dlkeras'));r2_dlkeras=r2(i_dlkeras,:);
i_cubist=find(strcmp(model_list,'cubist'));r2_cubist=r2(i_cubist,:);
plot(r2_dlkeras(i),'b');hold on
plot(r2_M5(i),'r')
plot(r2_cubist(i),'g');grid on
xlabel('Dataset','fontsize',18);ylabel('R^2','fontsize',18)
legend({'dlkeras','M5','cubist'},'location','northeast','fontsize',18)
axis([1 ndata -0.05 1.05])
print('-depsc','../results/REPORTS/global/comparison_M5_cubist_dlkeras.eps')

% Boxplot with R^2 of r2_max, cubist, M5 and dlkeras
clf;boxplot([r2_max' r2_cubist' r2_M5' r2_dlkeras'],'symbol','b.');
xlabel_inclin({'R^2_{max}','cubist','M5','dlkeras'},-0.02,1.02,25,18)
ylabel('R^2','fontsize',18);grid on
print('-depsc','../results/REPORTS/global/boxplot_r2_best_cubist_M5_dlkeras.eps')
