#http://machinelearningmastery.com/regression-tutorial-keras-deep-learning-library-python/
from keras.models import Sequential
from keras.layers import Dense, Activation
from keras.wrappers.scikit_learn import KerasRegressor

keras_model=Sequential()
keras_model.add(Dense(val_par1,input_dim=ni,init='normal',activation='relu'))
keras_model.add(Dense(val_par2, init='normal', activation='relu'))
keras_model.add(Dense(val_par3, init='normal', activation='relu'))
keras_model.add(Dense(1,init='normal'))
keras_model.compile(optimizer='rmsprop',loss='mse')
keras_model.fit(pr[:,:ni],pr[:,-1],nb_epoch=100,batch_size=32,verbose=0)
sr=keras_model.predict(pv[:,:ni],batch_size=32,verbose=0).T[0]

#m.compile(optimizer='adam',loss='mean_squared_error')
#estimator = KerasRegressor(build_fn=m,nb_epoch=100,batch_size=5,verbose=0)
#loss_and_metrics=m.evaluate(pv[:,:ni], Y_test, batch_size=32)
#@misc{chollet2015keras,
  #title={Keras},
  #author={Chollet, Fran\c{c}ois},
  #year={2015},
  #publisher={GitHub},
  #howpublished={\url{https://github.com/fchollet/keras}},
#}