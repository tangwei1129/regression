#!/bin/bash
# consultar taboa en: https://wiki.citius.usc.es/es:centro:servizos:hpc
#PBS -l nodes=1:ppn=64,walltime=48:00:00
#PBS -N widekernelpls_video_transcode
#PBS -e outputs/video_transcode/widekernelpls_R_video_transcode.err
#PBS -o outputs/video_transcode/widekernelpls_R_video_transcode.out
#PBS -m n -M manuel.fernandez.delgado@usc.es

basedir=$HOME/artigos/comparacion_regresores/experiments
datadir=$basedir/data
programsdir=$basedir/programs
resultsdir=$basedir/results
cd $programsdir

interactive=0
dataset=video_transcode
model=widekernelpls
implem=R
args_model='2 C 20 16384 8192 4096 2048 1024 512 256 128 64 32 16 8 4 2 1 0.5 0.25 0.125 0.0625 0.0312 gamma 25 256 128 64 32 16 8 4 2 1 0.5 0.25 0.125 0.0625 0.03125 0.01562 0.00781 0.00391 0.00195  0.00098 0.00049 0.00024 0.00012 0.00006 0.00003 1.5e-5'

resultsdir=/scratch/manuel.fernandez.delgado/comparacion_regresores/results/${dataset}/${model}_${implem}
mkdir -p $resultsdir

export PATH=$PATH:.
export TERM=xterm
memory=`expr 2 \* 64`
export _JAVA_OPTIONS=-Xmx${memory}G  #required for Weka and R (bartMachine/extraTrees)

mkdir ${programsdir}/scripts/${dataset} 2> /dev/null
mkdir ${programsdir}/outputs/${dataset} 2> /dev/null

f_log=${resultsdir}/output_${model}_${implem}_${dataset}.dat; rm -f $f_log 2> /dev/null


## C ########################################################
if [ $implem = "C" ]; then
	cd C; make -B $model; $model $basedir $resultsdir $dataset $args_model $interactive
## MATLAB ###################################################
elif [ $implem = "matlab" ]; then
	module load matlab; cd matlab
	matlab -nodisplay -nosplash -nojvm -singleCompThread -r "regression $basedir $resultsdir $dataset $model $args_model $interactive" -logfile $f_log > /dev/null
## R ########################################################
elif [ $implem = "R" ]; then
	module load R; module load jdk;cd R; export R_LIBS_SITE="~/libR"
	R -q --no-save --slave --file="regression.R" --args $basedir $resultsdir $dataset $model $args_model $interactive $R_LIBS_SITE > $f_log 2>&1
## WEKA #####################################################
elif [ $implem = "weka" ]; then
	export WEKAINSTALL=$HOME/weka-3-6-8
	export CLASSPATH=$WEKAINSTALL/weka.jar:$WEKAINSTALL/libsvm.jar:$WEKAINSTALL/liblinear-1.7-with-deps.jar:.
	module load jdk; cd weka; javac Regression.java
	java -Xmx2048m Regression $basedir $resultsdir $dataset $model $interactive $args_model > ${f_log}
	unset CLASSPATH
elif [ $implem = "python" ]; then
	cd python;python regression.py $basedir $resultsdir $dataset $model $interactive $args_model > ${f_log}
fi

cd $programsdir

#  	module load matlab
#  	matlab -nodisplay -nodesktop -nosplash -r "makeplot $basedir $dataset $model $implem" > /dev/null 2>&1

cp $resultsdir/* ${basedir}/results/${dataset}/${model}_${implem}