#!/bin/bash

# dataset_list=(3Droad airfoil air_quality_CO air_quality_NMHC air_quality_NO2 air_quality_NOx air_quality_O3 appliances_energy automobile auto_mpg beijing_pm25 bike_day bike_hour blog_feedback buzz_twitter combined_cycle com_crime com_crime_unnorm com_hd compress_stren cond_turbine csm1415 CT_slices cuff_less daily_demand dynamic_features energy_cool energy_heat facebook_comment facebook_metrics forestfires gas_drift gas_dynamic_CO gas_dynamic_methane geo_lat geo_long geo_music_lat geo_music_long gps_trajectory greenhouse_net household_consume housing KEGG_reaction KEGG_relation online_news park_motor_UPDRS park_speech park_total_UPDRS physico_protein pm25_beijing_dongsi pm25_beijing_dongsihuan pm25_beijing_nongzhanguan pm25_beijing_us_post pm25_chengdu_caotangsi pm25_chengdu_shahepu pm25_chengdu_us_post pm25_guangzhou_5th_middle_school pm25_guangzhou_city_station pm25_guangzhou_us_post pm25_shanghai_jingan pm25_shanghai_us_post pm25_shanghai_xuhui pm25_shenyang_taiyuanji pm25_shenyang_us_post pm25_shenyang_xiaoheyan servo slump slump_comp slump_flow SML2010 stock_abs stock_annual stock_excess stock_exchange stock_rel stock_systematic stock_total student_mat student_por UJ_lat UJ_long video_transcode yacht_hydro year_prediction)

dataset_list=(park_motor_UPDRS park_total_UPDRS appliances_energy pm25_beijing_dongsihuan pm25_shenyang_us_post pm25_guangzhou_5th_middle_school pm25_shanghai_jingan pm25_shenyang_taiyuanji pm25_chengdu_caotangsi pm25_shanghai_xuhui pm25_chengdu_shahepu pm25_shenyang_xiaoheyan pm25_beijing_nongzhanguan pm25_beijing_dongsi pm25_chengdu_us_post pm25_shanghai_us_post pm25_guangzhou_city_station pm25_guangzhou_us_post online_news facebook_comment beijing_pm25 physico_protein pm25_beijing_us_post KEGG_relation blog_feedback cuff_less video_transcode dynamic_features 3Droad year_prediction buzz_twitter greenhouse_net household_consume)

n_dataset=${#dataset_list[@]}

# model_list=(lm glm dnn Boruta dlkeras elm_kernel enpls.fs bstSm grnn blackboost glmnet earth rpart bagEarth kernelpls simpls rlm ridge nnls lars pcr avNNet lasso ppr glmStepAIC krlsRadial xgbTree foba rf superpc gam gaussprLinear gaussprRadial rvmRadial svr kknn rqlasso treebag bayesglm spls gaussprPoly cforest cubist nodeHarvest gbm qrf rqnc RRF penalized icr relaxo extraTrees bag M5 rbf SBC glmboost elm spikeslab svmRadial pcaNNet ctree2 plsRglm bdk brnn xgbLinear gamboost mlpWeightDecay randomGLM partDSA bartMachine evtree BstLm bstTree mlpWeightDecayML qrnn widekernelpls enet)

model_list=(dlkeras)

n_model=${#model_list[@]}

echo $n_dataset 'datasets, ' $n_model 'models'

n_exp=`expr $n_dataset \* $n_model`
i_exp=0

file1='listing_process_memory.txt'
> $file1

for model in ${model_list[*]}; do
	for dataset in  ${dataset_list[*]}; do
		implem='R'
		if [ $model == 'svr' ]; then
			implem='C'
		elif [ $model == 'grnn' ]; then
			implem='matlab'
		elif [ $model == 'elm_kernel' ]; then
			implem='matlab'
		elif [ $model == 'dlkeras' ]; then
			implem='python'
		fi

		file2=scripts/${dataset}/${model}_${dataset}.sh
		ppn=`grep ppn $file2 2> /dev/null | cut -d= -f3|cut -d, -f1`
		if [ -z "${ppn}" ]; then
			echo $model $dataset': erro' >> $file1
			continue
		fi
		mem=`expr 2 \* ${ppn}`
		echo $dataset $model 'ppn=' $ppn 'mem=' $mem 'GB' >> $file1
		echo $model $dataset $i_exp '/' $n_exp
		let i_exp=i_exp+1
	done
done