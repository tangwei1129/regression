require(caret,quietly=TRUE)
bagEarth.model=bagEarth(output ~. ,data=pr,degree=1,nprune=val_par1,Scale.y=FALSE)
sr=predict(bagEarth.model,pv[,-i_output])
rm(bagEarth.model)
